.class public Lcom/kingxw/qsbridge/QsMusicPlaybackInfo;
.super Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
.source "QsMusicPlaybackInfo.smali"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public getAppName()Ljava/lang/String;
    .locals 1

    const-string v0, "\u6c7d\u6c34\u97f3\u4e50"

    return-object v0
.end method

.method public getDuration()J
    .locals 2

    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getPackageName()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->pkg()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getPlaybackStatus()I
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->playbackStatus()I

    move-result v0

    return v0
.end method

.method public getSourceType()I
    .locals 1

    const/16 v0, 0xa

    return v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->title()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
