.class Lcom/kingxw/qsbridge/EcarxBridge$6;
.super Ljava/lang/Object;
.source "EcarxBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/kingxw/qsbridge/EcarxBridge;->updateFromMetadata(Landroid/media/MediaMetadata;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 235
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    .line 236
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushMediaContent()V

    return-void
.end method
