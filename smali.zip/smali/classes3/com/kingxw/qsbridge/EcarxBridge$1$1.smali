.class Lcom/kingxw/qsbridge/EcarxBridge$1$1;
.super Ljava/lang/Object;
.source "EcarxBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/kingxw/qsbridge/EcarxBridge$1;->invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/kingxw/qsbridge/EcarxBridge$1;


# direct methods
.method constructor <init>(Lcom/kingxw/qsbridge/EcarxBridge$1;)V
    .locals 0
    .param p1, "this$0"    # Lcom/kingxw/qsbridge/EcarxBridge$1;

    .line 47
    iput-object p1, p0, Lcom/kingxw/qsbridge/EcarxBridge$1$1;->this$0:Lcom/kingxw/qsbridge/EcarxBridge$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 0

    .line 47
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->onReady()V

    return-void
.end method
