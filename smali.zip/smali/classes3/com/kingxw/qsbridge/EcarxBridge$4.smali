.class Lcom/kingxw/qsbridge/EcarxBridge$4;
.super Landroid/media/session/MediaController$Callback;
.source "EcarxBridge.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/kingxw/qsbridge/EcarxBridge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 187
    invoke-direct {p0}, Landroid/media/session/MediaController$Callback;-><init>()V

    return-void
.end method


# virtual methods
.method public onMetadataChanged(Landroid/media/MediaMetadata;)V
    .locals 0
    .param p1, "m"    # Landroid/media/MediaMetadata;

    .line 188
    invoke-static {p1}, Lcom/kingxw/qsbridge/EcarxBridge;->updateFromMetadata(Landroid/media/MediaMetadata;)V

    return-void
.end method

.method public onPlaybackStateChanged(Landroid/media/session/PlaybackState;)V
    .locals 0
    .param p1, "s"    # Landroid/media/session/PlaybackState;

    .line 189
    invoke-static {p1}, Lcom/kingxw/qsbridge/EcarxBridge;->updateFromState(Landroid/media/session/PlaybackState;)V

    return-void
.end method
