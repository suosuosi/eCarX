.class Lcom/kingxw/qsbridge/EcarxBridge$2;
.super Ljava/lang/Object;
.source "EcarxBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/kingxw/qsbridge/EcarxBridge;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 113
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 116
    :try_start_0
    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->ready:Z

    if-eqz v0, :cond_0

    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    if-eqz v0, :cond_0

    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->controller:Landroid/media/session/MediaController;

    if-eqz v0, :cond_0

    .line 117
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->controller:Landroid/media/session/MediaController;

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    .line 118
    .local v0, "ps":Landroid/media/session/PlaybackState;
    if-eqz v0, :cond_0

    .line 119
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v1

    .line 120
    .local v1, "pos":J
    sput-wide v1, Lcom/kingxw/qsbridge/EcarxState;->sPositionMs:J

    .line 121
    invoke-static {v1, v2}, Lcom/kingxw/qsbridge/EcarxBridge;->updateProgress(J)V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 124
    .end local v0
    .end local v1
    :catchall_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 125
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->main:Landroid/os/Handler;

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 126
    return-void
.end method
