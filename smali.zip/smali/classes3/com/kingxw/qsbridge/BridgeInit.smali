.class public Lcom/kingxw/qsbridge/BridgeInit;
.super Landroid/content/ContentProvider;
.source "BridgeInit.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 12
    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    return-void
.end method


# virtual methods
.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 1
    .param p1, "u"    # Landroid/net/Uri;
    .param p2, "s"    # Ljava/lang/String;
    .param p3, "sa"    # [Ljava/lang/String;

    .line 26
    const/4 v0, 0x0

    return v0
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .locals 1
    .param p1, "u"    # Landroid/net/Uri;

    .line 24
    const/4 v0, 0x0

    return-object v0
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .locals 1
    .param p1, "u"    # Landroid/net/Uri;
    .param p2, "v"    # Landroid/content/ContentValues;

    .line 25
    const/4 v0, 0x0

    return-object v0
.end method

.method public onCreate()Z
    .locals 2

    .line 15
    :try_start_0
    invoke-virtual {p0}, Lcom/kingxw/qsbridge/BridgeInit;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 16
    invoke-virtual {p0}, Lcom/kingxw/qsbridge/BridgeInit;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/kingxw/qsbridge/EcarxBridge;->init(Landroid/content/Context;)V

    .line 17
    invoke-virtual {p0}, Lcom/kingxw/qsbridge/BridgeInit;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 18
    .local v0, "ac":Landroid/content/Context;
    instance-of v1, v0, Landroid/app/Application;

    if-eqz v1, :cond_0

    move-object v1, v0

    check-cast v1, Landroid/app/Application;

    invoke-static {v1}, Lcom/kingxw/qsbridge/Announce;->install(Landroid/app/Application;)V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 20
    .end local v0
    :catchall_0
    move-exception v0

    :cond_0
    :goto_0
    nop

    .line 21
    const/4 v0, 0x1

    return v0
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .locals 1
    .param p1, "u"    # Landroid/net/Uri;
    .param p2, "p"    # [Ljava/lang/String;
    .param p3, "s"    # Ljava/lang/String;
    .param p4, "sa"    # [Ljava/lang/String;
    .param p5, "so"    # Ljava/lang/String;

    .line 23
    const/4 v0, 0x0

    return-object v0
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 1
    .param p1, "u"    # Landroid/net/Uri;
    .param p2, "v"    # Landroid/content/ContentValues;
    .param p3, "s"    # Ljava/lang/String;
    .param p4, "sa"    # [Ljava/lang/String;

    .line 27
    const/4 v0, 0x0

    return v0
.end method
