.class Lcom/kingxw/qsbridge/Announce$1;
.super Ljava/lang/Object;
.source "Announce.java"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/kingxw/qsbridge/Announce;->install(Landroid/app/Application;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    .param p1, "a"    # Landroid/app/Activity;
    .param p2, "b"    # Landroid/os/Bundle;

    .line 33
    invoke-static {p1}, Lcom/kingxw/qsbridge/Announce;->fullscreen(Landroid/app/Activity;)V

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 0
    .param p1, "a"    # Landroid/app/Activity;

    .line 39
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 0
    .param p1, "a"    # Landroid/app/Activity;

    .line 36
    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 0
    .param p1, "a"    # Landroid/app/Activity;

    .line 35
    invoke-static {p1}, Lcom/kingxw/qsbridge/Announce;->fullscreen(Landroid/app/Activity;)V

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0
    .param p1, "a"    # Landroid/app/Activity;
    .param p2, "b"    # Landroid/os/Bundle;

    .line 38
    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 1
    .param p1, "a"    # Landroid/app/Activity;

    .line 34
    sget v0, Lcom/kingxw/qsbridge/Announce;->started:I

    if-nez v0, :cond_0

    invoke-static {p1}, Lcom/kingxw/qsbridge/Announce;->show(Landroid/app/Activity;)V

    :cond_0
    sget v0, Lcom/kingxw/qsbridge/Announce;->started:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lcom/kingxw/qsbridge/Announce;->started:I

    invoke-static {p1}, Lcom/kingxw/qsbridge/Announce;->fullscreen(Landroid/app/Activity;)V

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 1
    .param p1, "a"    # Landroid/app/Activity;

    .line 37
    sget v0, Lcom/kingxw/qsbridge/Announce;->started:I

    add-int/lit8 v0, v0, -0x1

    sput v0, Lcom/kingxw/qsbridge/Announce;->started:I

    sget v0, Lcom/kingxw/qsbridge/Announce;->started:I

    if-gez v0, :cond_0

    const/4 v0, 0x0

    sput v0, Lcom/kingxw/qsbridge/Announce;->started:I

    :cond_0
    return-void
.end method
