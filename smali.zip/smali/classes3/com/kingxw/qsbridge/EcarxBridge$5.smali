.class Lcom/kingxw/qsbridge/EcarxBridge$5;
.super Landroid/media/browse/MediaBrowser$ConnectionCallback;
.source "EcarxBridge.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/kingxw/qsbridge/EcarxBridge;->connectMediaBrowser()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    .line 197
    invoke-direct {p0}, Landroid/media/browse/MediaBrowser$ConnectionCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onConnected()V
    .locals 5

    .line 200
    const-string v0, "QsBridge"

    :try_start_0
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->browser:Landroid/media/browse/MediaBrowser;

    invoke-virtual {v1}, Landroid/media/browse/MediaBrowser;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v1

    .line 201
    .local v1, "tk":Landroid/media/session/MediaSession$Token;
    new-instance v2, Landroid/media/session/MediaController;

    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-direct {v2, v3, v1}, Landroid/media/session/MediaController;-><init>(Landroid/content/Context;Landroid/media/session/MediaSession$Token;)V

    sput-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->controller:Landroid/media/session/MediaController;

    .line 202
    sget-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->controller:Landroid/media/session/MediaController;

    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->ctrlCb:Landroid/media/session/MediaController$Callback;

    sget-object v4, Lcom/kingxw/qsbridge/EcarxBridge;->main:Landroid/os/Handler;

    invoke-virtual {v2, v3, v4}, Landroid/media/session/MediaController;->registerCallback(Landroid/media/session/MediaController$Callback;Landroid/os/Handler;)V

    .line 203
    const-string v2, "MediaBrowser onConnected, \u62ff\u5230\u6c7d\u6c34 controller"

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 204
    sget-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->controller:Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v2

    invoke-static {v2}, Lcom/kingxw/qsbridge/EcarxBridge;->updateFromMetadata(Landroid/media/MediaMetadata;)V

    .line 205
    sget-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->controller:Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v2

    invoke-static {v2}, Lcom/kingxw/qsbridge/EcarxBridge;->updateFromState(Landroid/media/session/PlaybackState;)V

    .line 206
    .end local v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    .local v1, "e":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onConnected fail: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 207
    .end local v1
    :goto_0
    return-void
.end method

.method public onConnectionFailed()V
    .locals 2

    .line 208
    const-string v0, "QsBridge"

    const-string v1, "MediaBrowser onConnectionFailed (\u6c7d\u6c34\u62d2\u7edd\u540c\u8fdb\u7a0b\u8fde\u63a5?\u9700\u8d70\u901a\u77e5\u6743\u56de\u9000)"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public onConnectionSuspended()V
    .locals 2

    .line 209
    const-string v0, "QsBridge"

    const-string v1, "MediaBrowser onConnectionSuspended"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
