.class public Lcom/kingxw/qsbridge/EcarxState;
.super Ljava/lang/Object;
.source "EcarxState.java"


# static fields
.field public static volatile playing:Z

.field public static volatile sAlbum:Ljava/lang/String;

.field public static volatile sAppIconUri:Ljava/lang/String;

.field public static volatile sArtist:Ljava/lang/String;

.field public static volatile sArtworkUri:Ljava/lang/String;

.field public static volatile sDurationMs:J

.field public static volatile sLaunchIntent:Landroid/app/PendingIntent;

.field public static volatile sLyric:Ljava/lang/String;

.field public static volatile sPositionMs:J

.field public static volatile sTitle:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 10
    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    .line 13
    const-string v0, "\u6c7d\u6c34\u97f3\u4e50"

    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sTitle:Ljava/lang/String;

    .line 14
    const-string v0, ""

    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sArtist:Ljava/lang/String;

    .line 15
    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sAlbum:Ljava/lang/String;

    .line 16
    const/4 v0, 0x0

    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sArtworkUri:Ljava/lang/String;

    .line 17
    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sLyric:Ljava/lang/String;

    .line 18
    const-wide/16 v1, 0x0

    sput-wide v1, Lcom/kingxw/qsbridge/EcarxState;->sDurationMs:J

    .line 19
    sput-wide v1, Lcom/kingxw/qsbridge/EcarxState;->sPositionMs:J

    .line 20
    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sAppIconUri:Ljava/lang/String;

    .line 21
    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sLaunchIntent:Landroid/app/PendingIntent;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static album()Ljava/lang/String;
    .locals 1

    .line 26
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sAlbum:Ljava/lang/String;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sAlbum:Ljava/lang/String;

    goto :goto_0

    :cond_0
    const-string v0, ""

    :goto_0
    return-object v0
.end method

.method public static appIconUri()Ljava/lang/String;
    .locals 1

    .line 33
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sAppIconUri:Ljava/lang/String;

    return-object v0
.end method

.method public static artist()Ljava/lang/String;
    .locals 1

    .line 25
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sArtist:Ljava/lang/String;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sArtist:Ljava/lang/String;

    goto :goto_0

    :cond_0
    const-string v0, ""

    :goto_0
    return-object v0
.end method

.method public static artworkUri()Ljava/lang/String;
    .locals 1

    .line 28
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sArtworkUri:Ljava/lang/String;

    return-object v0
.end method

.method public static durationMs()J
    .locals 2

    .line 29
    sget-wide v0, Lcom/kingxw/qsbridge/EcarxState;->sDurationMs:J

    return-wide v0
.end method

.method public static launchIntent()Landroid/app/PendingIntent;
    .locals 1

    .line 34
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sLaunchIntent:Landroid/app/PendingIntent;

    return-object v0
.end method

.method public static lyric()Ljava/lang/String;
    .locals 1

    .line 27
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sLyric:Ljava/lang/String;

    return-object v0
.end method

.method public static pkg()Ljava/lang/String;
    .locals 1

    .line 36
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const-string v0, "com.tencent.wemeet.app"

    :goto_0
    return-object v0
.end method

.method public static playbackStatus()I
    .locals 1

    .line 23
    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    return v0
.end method

.method public static positionMs()J
    .locals 2

    .line 30
    sget-wide v0, Lcom/kingxw/qsbridge/EcarxState;->sPositionMs:J

    return-wide v0
.end method

.method public static title()Ljava/lang/String;
    .locals 1

    .line 24
    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sTitle:Ljava/lang/String;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/kingxw/qsbridge/EcarxState;->sTitle:Ljava/lang/String;

    goto :goto_0

    :cond_0
    const-string v0, "\u6c7d\u6c34\u97f3\u4e50"

    :goto_0
    return-object v0
.end method

.method public static uuid()Ljava/lang/String;
    .locals 2

    .line 32
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->title()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "|"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->artist()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
