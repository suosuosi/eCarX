.class public Lcom/kingxw/qsbridge/EcarxState;
.super Ljava/lang/Object;
.source "EcarxState.java"


# static fields
.field public static volatile playing:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 7
    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static pkg()Ljava/lang/String;
    .locals 1

    .line 12
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const-string v0, "com.tencent.wemeet.app"

    :goto_0
    return-object v0
.end method

.method public static playbackStatus()I
    .locals 1

    .line 9
    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    return v0
.end method

.method public static title()Ljava/lang/String;
    .locals 1

    .line 10
    const-string v0, "\u6c7d\u6c34\u97f3\u4e50"

    return-object v0
.end method
