.class public Lcom/kingxw/qsbridge/EcarxBridge;
.super Ljava/lang/Object;
.source "EcarxBridge.java"


# static fields
.field static final TAG:Ljava/lang/String; = "QsBridge"

.field static api:Ljava/lang/Object;

.field public static appCtx:Landroid/content/Context;

.field static browser:Landroid/media/browse/MediaBrowser;

.field static controller:Landroid/media/session/MediaController;

.field static final ctrlCb:Landroid/media/session/MediaController$Callback;

.field static volatile inited:Z

.field static final main:Landroid/os/Handler;

.field static final progressTick:Ljava/lang/Runnable;

.field static volatile ready:Z

.field static tickerStarted:Z

.field static token:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 27
    const/4 v0, 0x0

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->inited:Z

    .line 28
    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->ready:Z

    .line 29
    const/4 v1, 0x0

    sput-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .line 30
    sput-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 31
    sput-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    .line 32
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->main:Landroid/os/Handler;

    .line 112
    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->tickerStarted:Z

    .line 113
    new-instance v0, Lcom/kingxw/qsbridge/EcarxBridge$2;

    invoke-direct {v0}, Lcom/kingxw/qsbridge/EcarxBridge$2;-><init>()V

    sput-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->progressTick:Ljava/lang/Runnable;

    .line 187
    new-instance v0, Lcom/kingxw/qsbridge/EcarxBridge$4;

    invoke-direct {v0}, Lcom/kingxw/qsbridge/EcarxBridge$4;-><init>()V

    sput-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->ctrlCb:Landroid/media/session/MediaController$Callback;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static connectMediaBrowser()V
    .locals 6

    .line 193
    const-string v0, "QsBridge"

    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    if-nez v1, :cond_0

    return-void

    .line 195
    :cond_0
    :try_start_0
    new-instance v1, Landroid/content/ComponentName;

    sget-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "com.luna.player.impl.playerservice.MediaBrowserPlayerService"

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 197
    .local v1, "cn":Landroid/content/ComponentName;
    new-instance v2, Landroid/media/browse/MediaBrowser;

    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    new-instance v4, Lcom/kingxw/qsbridge/EcarxBridge$5;

    invoke-direct {v4}, Lcom/kingxw/qsbridge/EcarxBridge$5;-><init>()V

    const/4 v5, 0x0

    invoke-direct {v2, v3, v1, v4, v5}, Landroid/media/browse/MediaBrowser;-><init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/media/browse/MediaBrowser$ConnectionCallback;Landroid/os/Bundle;)V

    sput-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->browser:Landroid/media/browse/MediaBrowser;

    .line 211
    sget-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->browser:Landroid/media/browse/MediaBrowser;

    invoke-virtual {v2}, Landroid/media/browse/MediaBrowser;->connect()V

    .line 212
    const-string v2, "MediaBrowser connecting \u6c7d\u6c34 MediaBrowserPlayerService\u2026"

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 213
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    nop

    .end local v1
    goto :goto_0

    :catchall_0
    move-exception v1

    .local v1, "e":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "connectMediaBrowser fail: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 214
    .end local v1
    :goto_0
    return-void
.end method

.method public static init(Landroid/content/Context;)V
    .locals 13
    .param p0, "ctx"    # Landroid/content/Context;

    .line 35
    const-string v0, "QsBridge"

    sget-boolean v1, Lcom/kingxw/qsbridge/EcarxBridge;->inited:Z

    if-eqz v1, :cond_0

    return-void

    .line 36
    :cond_0
    const/4 v1, 0x1

    sput-boolean v1, Lcom/kingxw/qsbridge/EcarxBridge;->inited:Z

    .line 37
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    sput-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    .line 39
    const/4 v2, 0x0

    :try_start_0
    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    iget v3, v3, Landroid/content/pm/ApplicationInfo;->icon:I

    .line 40
    .local v3, "icon":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "android.resource://"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    sget-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    sput-object v4, Lcom/kingxw/qsbridge/EcarxState;->sAppIconUri:Ljava/lang/String;

    .line 41
    sget-object v4, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    sget-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 42
    .local v4, "li":Landroid/content/Intent;
    if-eqz v4, :cond_1

    sget-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    const/high16 v6, 0xc000000

    invoke-static {v5, v2, v4, v6}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v5

    sput-object v5, Lcom/kingxw/qsbridge/EcarxState;->sLaunchIntent:Landroid/app/PendingIntent;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 44
    .end local v3
    .end local v4
    :catchall_0
    move-exception v3

    :cond_1
    :goto_0
    nop

    .line 46
    :try_start_1
    const-string v3, "com.ecarx.eas.sdk.mediacenter.MediaCenterAPI"

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    .line 47
    .local v3, "cls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-string v4, "get"

    new-array v5, v1, [Ljava/lang/Class;

    const-class v6, Landroid/content/Context;

    aput-object v6, v5, v2

    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    new-array v5, v1, [Ljava/lang/Object;

    sget-object v6, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    aput-object v6, v5, v2

    const/4 v6, 0x0

    invoke-virtual {v4, v6, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 48
    .local v4, "apiObj":Ljava/lang/Object;
    if-nez v4, :cond_2

    return-void

    .line 49
    :cond_2
    sput-object v4, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .line 50
    const/4 v5, 0x0

    .line 51
    .local v5, "initM":Ljava/lang/reflect/Method;
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v6

    array-length v7, v6

    move v8, v2

    :goto_1
    const/4 v9, 0x2

    if-ge v8, v7, :cond_4

    aget-object v10, v6, v8

    .line 52
    .local v10, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    const-string v12, "init"

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_3

    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    array-length v11, v11

    if-ne v11, v9, :cond_3

    move-object v5, v10

    goto :goto_2

    .line 51
    .end local v10
    :cond_3
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    .line 54
    :cond_4
    :goto_2
    if-nez v5, :cond_5

    return-void

    .line 55
    :cond_5
    invoke-virtual {v5}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v6

    aget-object v6, v6, v1

    .line 56
    .local v6, "cbCls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-virtual {v6}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v7

    new-array v8, v1, [Ljava/lang/Class;

    aput-object v6, v8, v2

    new-instance v10, Lcom/kingxw/qsbridge/EcarxBridge$1;

    invoke-direct {v10}, Lcom/kingxw/qsbridge/EcarxBridge$1;-><init>()V

    invoke-static {v7, v8, v10}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v7

    .line 75
    .local v7, "cb":Ljava/lang/Object;
    new-array v8, v9, [Ljava/lang/Object;

    sget-object v9, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    aput-object v9, v8, v2

    aput-object v7, v8, v1

    invoke-virtual {v5, v4, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    const-string v1, "eCarX init called"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 79
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    nop

    .end local v3
    .end local v4
    .end local v5
    .end local v6
    .end local v7
    goto :goto_3

    .line 77
    :catchall_1
    move-exception v1

    .line 78
    .local v1, "e":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "init fail: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 80
    .end local v1
    :goto_3
    return-void
.end method

.method static inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "n"    # Ljava/lang/String;
    .param p2, "a"    # [Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 176
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    .line 177
    .local v3, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v4

    array-length v4, v4

    array-length v5, p2

    if-ne v4, v5, :cond_0

    invoke-virtual {v3, p0, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 176
    .end local v3
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 179
    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method static onReady()V
    .locals 13

    .line 83
    const-string v0, "QsBridge"

    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .line 84
    .local v1, "apiObj":Ljava/lang/Object;
    if-nez v1, :cond_0

    return-void

    .line 86
    :cond_0
    :try_start_0
    const-string v2, "com.kingxw.qsbridge.QsMusicClient"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v4, v3, [Ljava/lang/Object;

    invoke-virtual {v2, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 87
    .local v2, "client":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 88
    .local v4, "regM":Ljava/lang/reflect/Method;
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v5

    array-length v6, v5

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move v7, v3

    :goto_0
    const/4 v8, 0x2

    const-string v9, "registerMusic"

    if-ge v7, v6, :cond_2

    :try_start_1
    aget-object v10, v5, v7

    .line 89
    .local v10, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_1

    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    array-length v11, v11

    if-ne v11, v8, :cond_1

    .line 90
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    aget-object v11, v11, v3

    const-class v12, Ljava/lang/String;

    if-ne v11, v12, :cond_1

    move-object v4, v10

    goto :goto_1

    .line 88
    .end local v10
    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 92
    :cond_2
    :goto_1
    if-nez v4, :cond_4

    .line 93
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v5

    array-length v6, v5

    :goto_2
    if-ge v3, v6, :cond_4

    aget-object v7, v5, v3

    .line 94
    .local v7, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v7}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_3

    move-object v4, v7

    goto :goto_3

    .line 93
    .end local v7
    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 97
    :cond_4
    :goto_3
    if-nez v4, :cond_5

    return-void

    .line 98
    :cond_5
    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    if-eqz v3, :cond_6

    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    goto :goto_4

    :cond_6
    const-string v3, ""

    .line 99
    .local v3, "pkg":Ljava/lang/String;
    :goto_4
    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v5

    array-length v5, v5

    if-ne v5, v8, :cond_7

    filled-new-array {v3, v2}, [Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    sput-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    goto :goto_5

    .line 100
    :cond_7
    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    sput-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 101
    :goto_5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "registered token="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    sget-object v6, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 102
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->takeFocus()V

    .line 103
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->connectMediaBrowser()V

    .line 104
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->setupRecovery()V

    .line 105
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->startProgressTicker()V

    .line 108
    .end local v2
    .end local v3
    .end local v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_6

    .line 106
    :catchall_0
    move-exception v2

    .line 107
    .local v2, "e":Ljava/lang/Throwable;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "register fail: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 109
    .end local v2
    :goto_6
    return-void
.end method

.method static pushMediaContent()V
    .locals 7

    .line 253
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v0, "apiObj":Ljava/lang/Object;
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 254
    .local v1, "tk":Ljava/lang/Object;
    if-eqz v0, :cond_2

    if-nez v1, :cond_0

    goto :goto_1

    .line 256
    :cond_0
    :try_start_0
    const-string v2, "com.kingxw.qsbridge.QsMediaInfo"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {v2, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 257
    .local v2, "info":Ljava/lang/Object;
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 258
    .local v3, "list":Ljava/util/List;, "Ljava/util/List<Ljava/lang/Object;>;"
    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 259
    const-string v4, "updateMediaContent"

    filled-new-array {v1, v3}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v0, v4, v5}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 260
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->lyric()Ljava/lang/String;

    move-result-object v4

    .line 261
    .local v4, "ly":Ljava/lang/String;
    if-eqz v4, :cond_1

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_1

    const-string v5, "updateCurrentLyric"

    filled-new-array {v1, v4}, [Ljava/lang/Object;

    move-result-object v6

    invoke-static {v0, v5, v6}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 262
    .end local v2
    .end local v3
    .end local v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    goto :goto_0

    :catchall_0
    move-exception v2

    .local v2, "e":Ljava/lang/Throwable;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "pushMediaContent: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "QsBridge"

    invoke-static {v4, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 263
    .end local v2
    :goto_0
    return-void

    .line 254
    :cond_2
    :goto_1
    return-void
.end method

.method public static pushState()V
    .locals 12

    .line 161
    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->ready:Z

    if-nez v0, :cond_0

    return-void

    .line 162
    :cond_0
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v0, "apiObj":Ljava/lang/Object;
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 163
    .local v1, "tk":Ljava/lang/Object;
    if-eqz v0, :cond_4

    if-nez v1, :cond_1

    goto :goto_2

    .line 165
    :cond_1
    :try_start_0
    const-string v2, "updateCurrentSourceType"

    const/4 v3, 0x2

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v1, v4, v5

    const/4 v6, 0x6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v7, 0x1

    aput-object v6, v4, v7

    invoke-static {v0, v2, v4}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 166
    const-string v2, "com.kingxw.qsbridge.QsMusicPlaybackInfo"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    new-array v4, v5, [Ljava/lang/Class;

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v4, v5, [Ljava/lang/Object;

    invoke-virtual {v2, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 167
    .local v2, "info":Ljava/lang/Object;
    const-string v4, "com.ecarx.eas.sdk.mediacenter.MusicPlaybackInfo"

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    .line 168
    .local v4, "mpi":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v6

    array-length v8, v6

    :goto_0
    if-ge v5, v8, :cond_3

    aget-object v9, v6, v5

    .line 169
    .local v9, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v10

    const-string v11, "updateMusicPlaybackState"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v10

    array-length v10, v10

    if-ne v10, v3, :cond_2

    .line 170
    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v10

    aget-object v10, v10, v7

    if-ne v10, v4, :cond_2

    filled-new-array {v1, v2}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v9, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    .line 168
    .end local v9
    :cond_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 172
    .end local v2
    .end local v4
    :catchall_0
    move-exception v2

    :cond_3
    :goto_1
    nop

    .line 173
    return-void

    .line 163
    :cond_4
    :goto_2
    return-void
.end method

.method static setupRecovery()V
    .locals 10

    .line 137
    const-string v0, "QsBridge"

    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v1, "apiObj":Ljava/lang/Object;
    sget-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 138
    .local v2, "tk":Ljava/lang/Object;
    if-eqz v1, :cond_1

    if-nez v2, :cond_0

    goto/16 :goto_1

    .line 140
    :cond_0
    :try_start_0
    const-string v3, "com.ecarx.eas.sdk.mediacenter.IMusicRecoveryCallback"

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    .line 141
    .local v3, "cbCls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-virtual {v3}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v5, 0x1

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v7, 0x0

    aput-object v3, v6, v7

    new-instance v8, Lcom/kingxw/qsbridge/EcarxBridge$3;

    invoke-direct {v8}, Lcom/kingxw/qsbridge/EcarxBridge$3;-><init>()V

    invoke-static {v4, v6, v8}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v4

    .line 144
    .local v4, "cb":Ljava/lang/Object;
    const-string v6, "setMusicRecoveryCallback"

    filled-new-array {v2, v4}, [Ljava/lang/Object;

    move-result-object v8

    invoke-static {v1, v6, v8}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 145
    new-instance v6, Landroid/content/Intent;

    const-string v8, "com.kingxw.qsbridge.RECOVER"

    invoke-direct {v6, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 146
    .local v6, "it":Landroid/content/Intent;
    sget-object v8, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 147
    const-string v8, "registerMusicRecoveryIntent"

    const/4 v9, 0x3

    new-array v9, v9, [Ljava/lang/Object;

    aput-object v2, v9, v7

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    aput-object v7, v9, v5

    const/4 v5, 0x2

    aput-object v6, v9, v5

    invoke-static {v1, v8, v9}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .line 148
    .local v5, "ret":Ljava/lang/Object;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "\u2605registerMusicRecoveryIntent ret="

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " (true=eCarX \u63a5\u53d7\u6062\u590d\u6ce8\u518c)"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v0, v7}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 149
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    nop

    .end local v3
    .end local v4
    .end local v5
    .end local v6
    goto :goto_0

    :catchall_0
    move-exception v3

    .local v3, "e":Ljava/lang/Throwable;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "setupRecovery fail: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v0, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 150
    .end local v3
    :goto_0
    return-void

    .line 138
    :cond_1
    :goto_1
    return-void
.end method

.method static startProgressTicker()V
    .locals 4

    .line 129
    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->tickerStarted:Z

    if-eqz v0, :cond_0

    return-void

    .line 130
    :cond_0
    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->tickerStarted:Z

    .line 131
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->main:Landroid/os/Handler;

    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->progressTick:Ljava/lang/Runnable;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 132
    return-void
.end method

.method public static takeFocus()V
    .locals 4

    .line 154
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v0, "apiObj":Ljava/lang/Object;
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 155
    .local v1, "tk":Ljava/lang/Object;
    if-eqz v0, :cond_1

    if-nez v1, :cond_0

    goto :goto_1

    .line 156
    :cond_0
    :try_start_0
    const-string v2, "requestPlay"

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v0, v2, v3}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    .line 157
    :goto_0
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushState()V

    .line 158
    return-void

    .line 155
    :cond_1
    :goto_1
    return-void
.end method

.method static updateFromMetadata(Landroid/media/MediaMetadata;)V
    .locals 9
    .param p0, "m"    # Landroid/media/MediaMetadata;

    .line 217
    if-nez p0, :cond_0

    return-void

    .line 218
    :cond_0
    const-string v0, "android.media.metadata.TITLE"

    invoke-virtual {p0, v0}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 219
    .local v0, "t":Ljava/lang/String;
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_1

    sput-object v0, Lcom/kingxw/qsbridge/EcarxState;->sTitle:Ljava/lang/String;

    .line 220
    :cond_1
    const-string v1, "android.media.metadata.ARTIST"

    invoke-virtual {p0, v1}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 221
    .local v1, "ar":Ljava/lang/String;
    if-eqz v1, :cond_2

    sput-object v1, Lcom/kingxw/qsbridge/EcarxState;->sArtist:Ljava/lang/String;

    .line 222
    :cond_2
    const-string v2, "android.media.metadata.ALBUM"

    invoke-virtual {p0, v2}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 223
    .local v2, "al":Ljava/lang/String;
    if-eqz v2, :cond_3

    sput-object v2, Lcom/kingxw/qsbridge/EcarxState;->sAlbum:Ljava/lang/String;

    .line 224
    :cond_3
    const-string v3, "android.media.metadata.DURATION"

    invoke-virtual {p0, v3}, Landroid/media/MediaMetadata;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    .line 225
    .local v3, "dur":J
    const-wide/16 v5, 0x0

    cmp-long v5, v3, v5

    if-lez v5, :cond_4

    sput-wide v3, Lcom/kingxw/qsbridge/EcarxState;->sDurationMs:J

    .line 226
    :cond_4
    const-string v5, "android.media.metadata.ALBUM_ART_URI"

    invoke-virtual {p0, v5}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 227
    .local v5, "art":Ljava/lang/String;
    if-nez v5, :cond_5

    const-string v6, "android.media.metadata.ART_URI"

    invoke-virtual {p0, v6}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 228
    :cond_5
    if-nez v5, :cond_6

    const-string v6, "android.media.metadata.DISPLAY_ICON_URI"

    invoke-virtual {p0, v6}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 229
    :cond_6
    if-eqz v5, :cond_7

    sput-object v5, Lcom/kingxw/qsbridge/EcarxState;->sArtworkUri:Ljava/lang/String;

    .line 230
    :cond_7
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "onMetadataChanged title="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    sget-object v7, Lcom/kingxw/qsbridge/EcarxState;->sTitle:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " artist="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    sget-object v7, Lcom/kingxw/qsbridge/EcarxState;->sArtist:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " dur="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    sget-wide v7, Lcom/kingxw/qsbridge/EcarxState;->sDurationMs:J

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " art="

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v7, "QsBridge"

    invoke-static {v7, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 232
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushMediaContent()V

    .line 233
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushState()V

    .line 235
    sget-object v6, Lcom/kingxw/qsbridge/EcarxState;->sTitle:Ljava/lang/String;

    sget-object v7, Lcom/kingxw/qsbridge/EcarxState;->sArtist:Ljava/lang/String;

    new-instance v8, Lcom/kingxw/qsbridge/EcarxBridge$6;

    invoke-direct {v8}, Lcom/kingxw/qsbridge/EcarxBridge$6;-><init>()V

    invoke-static {v6, v7, v8}, Lcom/kingxw/qsbridge/LyricFetcher;->fetch(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 238
    return-void
.end method

.method static updateFromState(Landroid/media/session/PlaybackState;)V
    .locals 3
    .param p0, "s"    # Landroid/media/session/PlaybackState;

    .line 241
    if-nez p0, :cond_0

    return-void

    .line 242
    :cond_0
    invoke-virtual {p0}, Landroid/media/session/PlaybackState;->getState()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    .line 243
    .local v0, "nowPlaying":Z
    :goto_0
    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    .line 244
    invoke-virtual {p0}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v1

    sput-wide v1, Lcom/kingxw/qsbridge/EcarxState;->sPositionMs:J

    .line 246
    if-eqz v0, :cond_2

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->takeFocus()V

    .line 247
    :cond_2
    sget-wide v1, Lcom/kingxw/qsbridge/EcarxState;->sPositionMs:J

    invoke-static {v1, v2}, Lcom/kingxw/qsbridge/EcarxBridge;->updateProgress(J)V

    .line 248
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushState()V

    .line 249
    return-void
.end method

.method static updateProgress(J)V
    .locals 6
    .param p0, "pos"    # J

    .line 266
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v0, "apiObj":Ljava/lang/Object;
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 267
    .local v1, "tk":Ljava/lang/Object;
    if-eqz v0, :cond_1

    if-nez v1, :cond_0

    goto :goto_1

    .line 268
    :cond_0
    :try_start_0
    const-string v2, "updateCurrentProgress"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    aput-object v1, v3, v4

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const/4 v5, 0x1

    aput-object v4, v3, v5

    invoke-static {v0, v2, v3}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    .line 269
    :goto_0
    return-void

    .line 267
    :cond_1
    :goto_1
    return-void
.end method
