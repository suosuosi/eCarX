.class public Lcom/kingxw/qsbridge/EcarxBridge;
.super Ljava/lang/Object;
.source "EcarxBridge.java"


# static fields
.field static final TAG:Ljava/lang/String; = "QsBridge"

.field static api:Ljava/lang/Object;

.field public static appCtx:Landroid/content/Context;

.field static volatile inited:Z

.field static final main:Landroid/os/Handler;

.field static volatile ready:Z

.field static token:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 19
    const/4 v0, 0x0

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->inited:Z

    .line 20
    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->ready:Z

    .line 21
    const/4 v0, 0x0

    sput-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .line 22
    sput-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 23
    sput-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    .line 24
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->main:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static init(Landroid/content/Context;)V
    .locals 13
    .param p0, "ctx"    # Landroid/content/Context;

    .line 27
    const-string v0, "QsBridge"

    sget-boolean v1, Lcom/kingxw/qsbridge/EcarxBridge;->inited:Z

    if-eqz v1, :cond_0

    return-void

    .line 28
    :cond_0
    const/4 v1, 0x1

    sput-boolean v1, Lcom/kingxw/qsbridge/EcarxBridge;->inited:Z

    .line 29
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    sput-object v2, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    .line 31
    :try_start_0
    const-string v2, "com.ecarx.eas.sdk.mediacenter.MediaCenterAPI"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    .line 32
    .local v2, "cls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    const-string v3, "get"

    new-array v4, v1, [Ljava/lang/Class;

    const-class v5, Landroid/content/Context;

    const/4 v6, 0x0

    aput-object v5, v4, v6

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    new-array v4, v1, [Ljava/lang/Object;

    sget-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    aput-object v5, v4, v6

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    .line 33
    .local v3, "apiObj":Ljava/lang/Object;
    if-nez v3, :cond_1

    return-void

    .line 34
    :cond_1
    sput-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .line 35
    const/4 v4, 0x0

    .line 36
    .local v4, "initM":Ljava/lang/reflect/Method;
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v5

    array-length v7, v5

    move v8, v6

    :goto_0
    const/4 v9, 0x2

    if-ge v8, v7, :cond_3

    aget-object v10, v5, v8

    .line 37
    .local v10, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    const-string v12, "init"

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_2

    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    array-length v11, v11

    if-ne v11, v9, :cond_2

    move-object v4, v10

    goto :goto_1

    .line 36
    .end local v10    # "m":Ljava/lang/reflect/Method;
    :cond_2
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 39
    :cond_3
    :goto_1
    if-nez v4, :cond_4

    return-void

    .line 40
    :cond_4
    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v5

    aget-object v5, v5, v1

    .line 41
    .local v5, "cbCls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-virtual {v5}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v7

    new-array v8, v1, [Ljava/lang/Class;

    aput-object v5, v8, v6

    new-instance v10, Lcom/kingxw/qsbridge/EcarxBridge$1;

    invoke-direct {v10}, Lcom/kingxw/qsbridge/EcarxBridge$1;-><init>()V

    invoke-static {v7, v8, v10}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v7

    .line 60
    .local v7, "cb":Ljava/lang/Object;
    new-array v8, v9, [Ljava/lang/Object;

    sget-object v9, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    aput-object v9, v8, v6

    aput-object v7, v8, v1

    invoke-virtual {v4, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    const-string v1, "eCarX init called"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 64
    nop

    .end local v2    # "cls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    .end local v3    # "apiObj":Ljava/lang/Object;
    .end local v4    # "initM":Ljava/lang/reflect/Method;
    .end local v5    # "cbCls":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    .end local v7    # "cb":Ljava/lang/Object;
    goto :goto_2

    .line 62
    :catchall_0
    move-exception v1

    .line 63
    .local v1, "e":Ljava/lang/Throwable;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "init fail: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 65
    .end local v1    # "e":Ljava/lang/Throwable;
    :goto_2
    return-void
.end method

.method static inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p0, "o"    # Ljava/lang/Object;
    .param p1, "n"    # Ljava/lang/String;
    .param p2, "a"    # [Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 117
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    .line 118
    .local v3, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v4

    array-length v4, v4

    array-length v5, p2

    if-ne v4, v5, :cond_0

    invoke-virtual {v3, p0, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    .line 117
    .end local v3    # "m":Ljava/lang/reflect/Method;
    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 120
    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method static onReady()V
    .locals 13

    .line 68
    const-string v0, "QsBridge"

    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .line 69
    .local v1, "apiObj":Ljava/lang/Object;
    if-nez v1, :cond_0

    return-void

    .line 71
    :cond_0
    :try_start_0
    const-string v2, "com.kingxw.qsbridge.QsMusicClient"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v4, v3, [Ljava/lang/Object;

    invoke-virtual {v2, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 72
    .local v2, "client":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 73
    .local v4, "regM":Ljava/lang/reflect/Method;
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v5

    array-length v6, v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move v7, v3

    :goto_0
    const/4 v8, 0x2

    const-string v9, "registerMusic"

    if-ge v7, v6, :cond_2

    :try_start_1
    aget-object v10, v5, v7

    .line 74
    .local v10, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_1

    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    array-length v11, v11

    if-ne v11, v8, :cond_1

    .line 75
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v11

    aget-object v11, v11, v3

    const-class v12, Ljava/lang/String;

    if-ne v11, v12, :cond_1

    move-object v4, v10

    goto :goto_1

    .line 73
    .end local v10    # "m":Ljava/lang/reflect/Method;
    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    .line 77
    :cond_2
    :goto_1
    if-nez v4, :cond_4

    .line 78
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v5

    array-length v6, v5

    :goto_2
    if-ge v3, v6, :cond_4

    aget-object v7, v5, v3

    .line 79
    .local v7, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v7}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_3

    move-object v4, v7

    goto :goto_3

    .line 78
    .end local v7    # "m":Ljava/lang/reflect/Method;
    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 82
    :cond_4
    :goto_3
    if-nez v4, :cond_5

    return-void

    .line 83
    :cond_5
    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    if-eqz v3, :cond_6

    sget-object v3, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    goto :goto_4

    :cond_6
    const-string v3, ""

    .line 84
    .local v3, "pkg":Ljava/lang/String;
    :goto_4
    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v5

    array-length v5, v5

    if-ne v5, v8, :cond_7

    filled-new-array {v3, v2}, [Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    sput-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    goto :goto_5

    .line 85
    :cond_7
    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    sput-object v5, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 86
    :goto_5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "registered token="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    sget-object v6, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 87
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->takeFocus()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 90
    .end local v2    # "client":Ljava/lang/Object;
    .end local v3    # "pkg":Ljava/lang/String;
    .end local v4    # "regM":Ljava/lang/reflect/Method;
    goto :goto_6

    .line 88
    :catchall_0
    move-exception v2

    .line 89
    .local v2, "e":Ljava/lang/Throwable;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "register fail: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 91
    .end local v2    # "e":Ljava/lang/Throwable;
    :goto_6
    return-void
.end method

.method public static pushState()V
    .locals 12

    .line 102
    sget-boolean v0, Lcom/kingxw/qsbridge/EcarxBridge;->ready:Z

    if-nez v0, :cond_0

    return-void

    .line 103
    :cond_0
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v0, "apiObj":Ljava/lang/Object;
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 104
    .local v1, "tk":Ljava/lang/Object;
    if-eqz v0, :cond_4

    if-nez v1, :cond_1

    goto :goto_2

    .line 106
    :cond_1
    :try_start_0
    const-string v2, "updateCurrentSourceType"

    const/4 v3, 0x2

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v5, 0x0

    aput-object v1, v4, v5

    const/16 v6, 0xa

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v7, 0x1

    aput-object v6, v4, v7

    invoke-static {v0, v2, v4}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    const-string v2, "com.kingxw.qsbridge.QsMusicPlaybackInfo"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    new-array v4, v5, [Ljava/lang/Class;

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    new-array v4, v5, [Ljava/lang/Object;

    invoke-virtual {v2, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 108
    .local v2, "info":Ljava/lang/Object;
    const-string v4, "com.ecarx.eas.sdk.mediacenter.MusicPlaybackInfo"

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    .line 109
    .local v4, "mpi":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v6

    array-length v8, v6

    :goto_0
    if-ge v5, v8, :cond_3

    aget-object v9, v6, v5

    .line 110
    .local v9, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v10

    const-string v11, "updateMusicPlaybackState"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v10

    array-length v10, v10

    if-ne v10, v3, :cond_2

    .line 111
    invoke-virtual {v9}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v10

    aget-object v10, v10, v7

    if-ne v10, v4, :cond_2

    filled-new-array {v1, v2}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v9, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    .line 109
    .end local v9    # "m":Ljava/lang/reflect/Method;
    :cond_2
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 113
    .end local v2    # "info":Ljava/lang/Object;
    .end local v4    # "mpi":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :catchall_0
    move-exception v2

    :cond_3
    :goto_1
    nop

    .line 114
    return-void

    .line 104
    :cond_4
    :goto_2
    return-void
.end method

.method public static takeFocus()V
    .locals 4

    .line 95
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->api:Ljava/lang/Object;

    .local v0, "apiObj":Ljava/lang/Object;
    sget-object v1, Lcom/kingxw/qsbridge/EcarxBridge;->token:Ljava/lang/Object;

    .line 96
    .local v1, "tk":Ljava/lang/Object;
    if-eqz v0, :cond_1

    if-nez v1, :cond_0

    goto :goto_1

    .line 97
    :cond_0
    :try_start_0
    const-string v2, "requestPlay"

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v0, v2, v3}, Lcom/kingxw/qsbridge/EcarxBridge;->inv(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    .line 98
    :goto_0
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushState()V

    .line 99
    return-void

    .line 96
    :cond_1
    :goto_1
    return-void
.end method
