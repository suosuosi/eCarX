.class public Lcom/kingxw/qsbridge/QsMediaInfo;
.super Lcom/ecarx/eas/sdk/mediacenter/AbstractMediaInfo;
.source "QsMediaInfo.smali"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/AbstractMediaInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public getAlbum()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->album()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getAlbumIndex()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getArtist()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->artist()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getArtwork()Landroid/net/Uri;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->artworkUri()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public getAuthor()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getCategoryStr()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getCollected()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getComposer()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getDescription()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getDuration()J
    .locals 2

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->durationMs()J

    move-result-wide v0

    return-wide v0
.end method

.method public getLyric()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getLyricContent()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->lyric()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMediaCp()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getMediaId()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->title()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getMediaPath()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPlayingItemPositionInQueue()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getPlayingMediaListId()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPlayingMediaListType()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getRadioFrequency()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getRadioStationName()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getRating()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getSourceType()I
    .locals 1

    const/4 v0, 0x6

    return v0
.end method

.method public getSubCategoryStr()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getSubtitle()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getSupportCollect()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getTargetType()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxState;->title()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getUuid()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getVip()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getYear()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method
