.class public Lcom/kingxw/qsbridge/Announce;
.super Ljava/lang/Object;
.source "Announce.java"


# static fields
.field static installed:Z

.field static started:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 26
    const/4 v0, 0x0

    sput-boolean v0, Lcom/kingxw/qsbridge/Announce;->installed:Z

    .line 27
    sput v0, Lcom/kingxw/qsbridge/Announce;->started:I

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static buildView(Landroid/app/Activity;)Landroid/view/View;
    .locals 14
    .param p0, "a"    # Landroid/app/Activity;

    .line 88
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 89
    .local v0, "root":Landroid/widget/LinearLayout;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 90
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 91
    const/16 v2, 0x16

    invoke-static {p0, v2}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v3

    const/16 v4, 0x12

    invoke-static {p0, v4}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v4

    invoke-static {p0, v2}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v2

    const/16 v5, 0x8

    invoke-static {p0, v5}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v6

    invoke-virtual {v0, v3, v4, v2, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 93
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 94
    .local v2, "title":Landroid/widget/TextView;
    const-string v3, "\ud83d\udc8e \u6253\u8d4f\u4e70 Token \u00b7 \u652f\u6301\u5171\u521b"

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 95
    const-string v3, "#C8860B"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 96
    const/high16 v3, 0x41900000    # 18.0f

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V

    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v3, 0x11

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 97
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 99
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 100
    .local v4, "pitch":Landroid/widget/TextView;
    const-string v6, "\u65b9\u5411\u76d8\u63a7\u5236\u80fd\u529b \u7531\u4e2a\u4eba\u4e1a\u4f59\u5f00\u53d1\u3001\u514d\u8d39\u5206\u4eab;\u63a5\u5165\u5927\u6a21\u578b\u9700\u6d88\u8017 Token(\u771f\u91d1\u767d\u94f6)\u3002\n\u6253\u8d4f = \u5e2e\u6211\u4e70 Token,\u652f\u6301\u6301\u7eed\u66f4\u65b0\u3001\u4e00\u8d77\u5171\u521b\u65b0\u529f\u80fd \ud83d\ude80\n\u6253\u8d4f\u540e\u52a0\u5fae\u4fe1,\u89e3\u9501\u66f4\u591a\u529f\u80fd / \u63d0\u9700\u6c42 / \u53cd\u9988 Bug\u3002\n\u4f17\u7b79\u6027\u8d28:Token \u82e5\u6709\u7ed3\u4f59,\u4f1a\u5efa\u7fa4\u4ee5\u7ea2\u5305\u5f62\u5f0f\u56de\u9988\u652f\u6301\u8005 \ud83e\udde7"

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 104
    const-string v6, "#666666"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41500000    # 13.0f

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 105
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v6, 0x4

    invoke-static {p0, v6}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v6

    int-to-float v6, v6

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-virtual {v4, v6, v7}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 106
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x1

    const/4 v9, -0x2

    invoke-direct {v6, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 108
    .local v6, "pl":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {p0, v5}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v5

    iput v5, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/16 v5, 0xc

    invoke-static {p0, v5}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v10

    iput v10, v6, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 109
    invoke-virtual {v0, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 111
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    const-string v11, "drawable"

    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v12

    const-string v13, "donate_qr"

    invoke-virtual {v10, v13, v11, v12}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    .line 112
    .local v10, "qr":I
    if-eqz v10, :cond_0

    .line 113
    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 114
    .local v11, "iv":Landroid/widget/ImageView;
    invoke-virtual {v11, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {v11, v1}, Landroid/widget/ImageView;->setAdjustViewBounds(Z)V

    .line 115
    sget-object v12, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 116
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0xe6

    invoke-static {p0, v13}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v13

    invoke-direct {v12, v13, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v11, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 119
    .end local v11    # "iv":Landroid/widget/ImageView;
    :cond_0
    new-instance v11, Landroid/widget/TextView;

    invoke-direct {v11, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 120
    .local v11, "wx":Landroid/widget/TextView;
    const-string v12, "\u52a0\u5fae\u4fe1\u89e3\u9501\u66f4\u591a\u529f\u80fd:wegeek26"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 121
    const-string v12, "#111111"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v12, 0x41700000    # 15.0f

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 122
    sget-object v12, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    invoke-virtual {v11, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 123
    invoke-virtual {v11, v1}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    .line 124
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 126
    .local v1, "wl":Landroid/widget/LinearLayout$LayoutParams;
    invoke-static {p0, v5}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v5

    iput v5, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 127
    invoke-virtual {v0, v11, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 129
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 130
    .local v5, "disc":Landroid/widget/TextView;
    const-string v12, "\u3010\u514d\u8d23\u58f0\u660e\u3011\u672c\u5e94\u7528\u4e3a\u4e2a\u4eba\u6280\u672f\u5b66\u4e60\u4e0e\u7814\u7a76\u4ea4\u6d41\u7684\u975e\u5546\u4e1a\u4f5c\u54c1,\u6309\u300c\u73b0\u72b6\u300d\u514d\u8d39\u63d0\u4f9b,\u4e0d\u4fdd\u8bc1\u53ef\u7528\u6027\u3001\u7a33\u5b9a\u6027\u4e0e\u517c\u5bb9\u6027\u3002\u6253\u8d4f\u7cfb\u7528\u6237\u81ea\u613f\u8d5e\u52a9\u5f00\u53d1\u8005,\u975e\u8d2d\u4e70\u5546\u54c1\u6216\u670d\u52a1\u3001\u4e0d\u6784\u6210\u4ea4\u6613\u5bf9\u4ef7\u3002\u8bf7\u52ff\u7528\u4e8e\u4efb\u4f55\u5546\u4e1a\u6216\u975e\u6cd5\u7528\u9014;\u56e0\u4f7f\u7528\u4ea7\u751f\u7684\u4e00\u5207\u540e\u679c\u7531\u4f7f\u7528\u8005\u81ea\u884c\u627f\u62c5,\u5f00\u53d1\u8005\u4e0d\u627f\u62c5\u4efb\u4f55\u8d23\u4efb\u3002\u4e0e\u5b57\u8282\u8df3\u52a8 / \u6c7d\u6c34\u97f3\u4e50\u65e0\u5173\u3002\u5982\u6d89\u53ca\u60a8\u7684\u6743\u5229\u8bf7\u901a\u8fc7\u4e0a\u65b9\u5fae\u4fe1\u8054\u7cfb\u5220\u9664\u3002"

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 134
    const-string v12, "#999999"

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v12, 0x41200000    # 10.0f

    invoke-virtual {v5, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 135
    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v3, 0x2

    invoke-static {p0, v3}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v5, v3, v7}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 136
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 138
    .local v3, "dl":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v7, 0xe

    invoke-static {p0, v7}, Lcom/kingxw/qsbridge/Announce;->dp(Landroid/app/Activity;I)I

    move-result v7

    iput v7, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 139
    invoke-virtual {v0, v5, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 141
    new-instance v7, Landroid/widget/ScrollView;

    invoke-direct {v7, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 142
    .local v7, "sv":Landroid/widget/ScrollView;
    invoke-virtual {v7, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 143
    return-object v7
.end method

.method static dp(Landroid/app/Activity;I)I
    .locals 2
    .param p0, "a"    # Landroid/app/Activity;
    .param p1, "v"    # I

    .line 43
    int-to-float v0, p1

    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    float-to-int v0, v0

    return v0
.end method

.method static fullscreen(Landroid/app/Activity;)V
    .locals 4
    .param p0, "a"    # Landroid/app/Activity;

    .line 48
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    .line 49
    .local v0, "w":Landroid/view/Window;
    if-nez v0, :cond_0

    return-void

    .line 50
    :cond_0
    const/16 v1, 0x400

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 51
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    .line 52
    .local v1, "dv":Landroid/view/View;
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    if-lt v2, v3, :cond_2

    .line 53
    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/Window;->setDecorFitsSystemWindows(Z)V

    .line 54
    invoke-virtual {v1}, Landroid/view/View;->getWindowInsetsController()Landroid/view/WindowInsetsController;

    move-result-object v2

    .line 55
    .local v2, "c":Landroid/view/WindowInsetsController;
    if-eqz v2, :cond_1

    .line 56
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v3

    invoke-interface {v2, v3}, Landroid/view/WindowInsetsController;->hide(I)V

    .line 57
    const/4 v3, 0x2

    invoke-interface {v2, v3}, Landroid/view/WindowInsetsController;->setSystemBarsBehavior(I)V

    .line 59
    .end local v2    # "c":Landroid/view/WindowInsetsController;
    :cond_1
    goto :goto_0

    .line 60
    :cond_2
    const/16 v2, 0x1706

    invoke-virtual {v1, v2}, Landroid/view/View;->setSystemUiVisibility(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 68
    .end local v0    # "w":Landroid/view/Window;
    .end local v1    # "dv":Landroid/view/View;
    :catchall_0
    move-exception v0

    :goto_0
    nop

    .line 69
    return-void
.end method

.method public static install(Landroid/app/Application;)V
    .locals 1
    .param p0, "app"    # Landroid/app/Application;

    .line 30
    sget-boolean v0, Lcom/kingxw/qsbridge/Announce;->installed:Z

    if-nez v0, :cond_1

    if-nez p0, :cond_0

    goto :goto_0

    .line 31
    :cond_0
    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/Announce;->installed:Z

    .line 32
    new-instance v0, Lcom/kingxw/qsbridge/Announce$1;

    invoke-direct {v0}, Lcom/kingxw/qsbridge/Announce$1;-><init>()V

    invoke-virtual {p0, v0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 41
    return-void

    .line 30
    :cond_1
    :goto_0
    return-void
.end method

.method static show(Landroid/app/Activity;)V
    .locals 1
    .param p0, "a"    # Landroid/app/Activity;

    .line 73
    :try_start_0
    new-instance v0, Lcom/kingxw/qsbridge/Announce$2;

    invoke-direct {v0, p0}, Lcom/kingxw/qsbridge/Announce$2;-><init>(Landroid/app/Activity;)V

    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 84
    :catchall_0
    move-exception v0

    :goto_0
    nop

    .line 85
    return-void
.end method
