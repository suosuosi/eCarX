.class Lcom/kingxw/qsbridge/EcarxCallbackSink$1;
.super Ljava/lang/Object;
.source "EcarxCallbackSink.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/kingxw/qsbridge/EcarxCallbackSink;->key(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$a:Landroid/media/AudioManager;

.field final synthetic val$code:I


# direct methods
.method constructor <init>(Landroid/media/AudioManager;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 23
    iput-object p1, p0, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;->val$a:Landroid/media/AudioManager;

    iput p2, p0, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;->val$code:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 26
    :try_start_0
    iget-object v0, p0, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;->val$a:Landroid/media/AudioManager;

    new-instance v1, Landroid/view/KeyEvent;

    iget v2, p0, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;->val$code:I

    const/4 v3, 0x0

    invoke-direct {v1, v3, v2}, Landroid/view/KeyEvent;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->dispatchMediaKeyEvent(Landroid/view/KeyEvent;)V

    .line 27
    iget-object v0, p0, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;->val$a:Landroid/media/AudioManager;

    new-instance v1, Landroid/view/KeyEvent;

    iget v2, p0, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;->val$code:I

    const/4 v3, 0x1

    invoke-direct {v1, v3, v2}, Landroid/view/KeyEvent;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->dispatchMediaKeyEvent(Landroid/view/KeyEvent;)V

    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 28
    :catchall_0
    move-exception v0

    :goto_0
    nop

    .line 29
    return-void
.end method
