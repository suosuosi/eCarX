.class public Lcom/kingxw/qsbridge/EcarxCallbackSink;
.super Ljava/lang/Object;
.source "EcarxCallbackSink.java"


# static fields
.field static final main:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 12
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lcom/kingxw/qsbridge/EcarxCallbackSink;->main:Landroid/os/Handler;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static am()Landroid/media/AudioManager;
    .locals 2

    .line 15
    sget-object v0, Lcom/kingxw/qsbridge/EcarxBridge;->appCtx:Landroid/content/Context;

    .line 16
    .local v0, "c":Landroid/content/Context;
    if-nez v0, :cond_0

    const/4 v1, 0x0

    return-object v1

    .line 17
    :cond_0
    const-string v1, "audio"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/AudioManager;

    return-object v1
.end method

.method static key(I)V
    .locals 3
    .param p0, "code"    # I

    .line 21
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->am()Landroid/media/AudioManager;

    move-result-object v0

    .line 22
    .local v0, "a":Landroid/media/AudioManager;
    if-nez v0, :cond_0

    return-void

    .line 23
    :cond_0
    sget-object v1, Lcom/kingxw/qsbridge/EcarxCallbackSink;->main:Landroid/os/Handler;

    new-instance v2, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;

    invoke-direct {v2, v0, p0}, Lcom/kingxw/qsbridge/EcarxCallbackSink$1;-><init>(Landroid/media/AudioManager;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 31
    invoke-static {}, Lcom/kingxw/qsbridge/EcarxBridge;->pushState()V

    .line 32
    return-void
.end method

.method public static onFocusChanged(Ljava/lang/String;)V
    .locals 2
    .param p0, "who"    # Ljava/lang/String;

    .line 38
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "focus="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "QsBridge"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static onNext()V
    .locals 2

    .line 36
    const-string v0, "QsBridge"

    const-string v1, "wheel onNext"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    const/16 v0, 0x57

    invoke-static {v0}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->key(I)V

    return-void
.end method

.method public static onPause()V
    .locals 2

    .line 35
    const-string v0, "QsBridge"

    const-string v1, "wheel onPause"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    const/16 v0, 0x7f

    invoke-static {v0}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->key(I)V

    return-void
.end method

.method public static onPlay()V
    .locals 2

    .line 34
    const-string v0, "QsBridge"

    const-string v1, "wheel onPlay"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    const/16 v0, 0x7e

    invoke-static {v0}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->key(I)V

    return-void
.end method

.method public static onPrevious()V
    .locals 2

    .line 37
    const-string v0, "QsBridge"

    const-string v1, "wheel onPrevious"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x1

    sput-boolean v0, Lcom/kingxw/qsbridge/EcarxState;->playing:Z

    const/16 v0, 0x58

    invoke-static {v0}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->key(I)V

    return-void
.end method
