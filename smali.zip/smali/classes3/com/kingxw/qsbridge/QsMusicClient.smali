.class public Lcom/kingxw/qsbridge/QsMusicClient;
.super Lcom/ecarx/eas/sdk/mediacenter/MusicClient;
.source "QsMusicClient.smali"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;-><init>()V

    return-void
.end method


# virtual methods
.method public onForward()Z
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onNext()V

    const/4 v0, 0x1

    return v0
.end method

.method public onMediaCenterFocusChanged(Ljava/lang/String;)V
    .locals 0

    invoke-static {p1}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onFocusChanged(Ljava/lang/String;)V

    return-void
.end method

.method public onNext()Z
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onNext()V

    const/4 v0, 0x1

    return v0
.end method

.method public onPause()Z
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onPause()V

    const/4 v0, 0x1

    return v0
.end method

.method public onPlay()Z
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onPlay()V

    const/4 v0, 0x1

    return v0
.end method

.method public onPrevious()Z
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onPrevious()V

    const/4 v0, 0x1

    return v0
.end method

.method public onReplay()Z
    .locals 1

    invoke-static {}, Lcom/kingxw/qsbridge/EcarxCallbackSink;->onPlay()V

    const/4 v0, 0x1

    return v0
.end method
