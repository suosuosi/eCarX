.class public final enum Lcom/bytedance/auto/lite/serviceapi/config/log/Level;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/bytedance/auto/lite/serviceapi/config/log/Level;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

.field public static final enum D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

.field public static final enum E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

.field public static final enum I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

.field public static final enum V:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

.field public static final enum W:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;


# direct methods
.method private static final synthetic $values()[Lcom/bytedance/auto/lite/serviceapi/config/log/Level;
    .locals 3

    const/4 v0, 0x5

    new-array v0, v0, [Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    sget-object v1, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->V:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    sget-object v1, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    sget-object v1, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->W:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const/4 v2, 0x3

    aput-object v1, v0, v2

    sget-object v1, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const/4 v2, 0x4

    aput-object v1, v0, v2

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    new-instance v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const-string v1, "V"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->V:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    new-instance v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const-string v1, "D"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    new-instance v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const-string v1, "I"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    new-instance v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const-string v1, "W"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->W:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    new-instance v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    const-string v1, "E"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {}, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->$values()[Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    move-result-object v0

    sput-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->$VALUES:[Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/bytedance/auto/lite/serviceapi/config/log/Level;
    .locals 1

    const-class v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    return-object p0
.end method

.method public static values()[Lcom/bytedance/auto/lite/serviceapi/config/log/Level;
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->$VALUES:[Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    return-object v0
.end method
