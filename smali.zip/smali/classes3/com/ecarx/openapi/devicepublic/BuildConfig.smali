.class public final Lcom/ecarx/openapi/devicepublic/BuildConfig;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final APPLICATION_ID:Ljava/lang/String; = "com.ecarx.openapi.devicepublic"

.field public static final AUTHOR:Ljava/lang/String; = ""

.field public static final BUILD_NUMBER:I = 0x2908269

.field public static final BUILD_TYPE:Ljava/lang/String; = "release"

.field public static final DEBUG:Z = false

.field public static final FLAVOR:Ljava/lang/String; = ""

.field public static final PUBLISH_DESC:Ljava/lang/String; = "\u65b0\u65b9\u6848\u8fc1\u79fb"

.field public static final VERSION:Ljava/lang/String; = "4.6.5(2908269)"

.field public static final VERSION_CODE:I = 0x1

.field public static final VERSION_INT:I = 0x1a7

.field public static final VERSION_NAME:Ljava/lang/String; = "1.0"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
