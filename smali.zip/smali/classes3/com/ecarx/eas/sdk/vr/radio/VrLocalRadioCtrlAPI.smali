.class public abstract Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
.super Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final TAG:Ljava/lang/String; = "VrLocalRadioCtrlAPI"

.field private static volatile mInstance:Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_vr_radio_VrLocalRadioCtrlAPI_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_vr_radio_VrLocalRadioCtrlAPI_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private static createVrLocalRadioCtrlAPI(Landroid/content/Context;)Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
    .locals 6

    if-eqz p0, :cond_0

    const-string v0, "VrLocalRadioCtrlAPI"

    const-string v1, "createVrLocalRadioCtrlAPI"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->INVOKESTATIC_com_ecarx_eas_sdk_vr_radio_VrLocalRadioCtrlAPI_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_0
    const-class v1, Lcom/ecarx/eas/sdk/mediacenter/a/i;

    sget v2, Lcom/ecarx/eas/sdk/mediacenter/a/i;->e:I

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    const-class v4, Landroid/content/Context;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v1, v3}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v1

    new-array v2, v2, [Ljava/lang/Object;

    aput-object p0, v2, v5

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    goto :goto_0

    :catch_1
    move-exception p0

    goto :goto_1

    :catch_2
    move-exception p0

    goto :goto_2

    :catch_3
    move-exception p0

    goto :goto_3

    :catch_4
    move-exception p0

    goto :goto_4

    :goto_0
    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->printStackTrace()V

    goto :goto_5

    :goto_1
    invoke-virtual {p0}, Ljava/lang/InstantiationException;->printStackTrace()V

    goto :goto_5

    :goto_2
    invoke-virtual {p0}, Ljava/lang/IllegalAccessException;->printStackTrace()V

    goto :goto_5

    :goto_3
    invoke-virtual {p0}, Ljava/lang/NoSuchMethodException;->printStackTrace()V

    goto :goto_5

    :goto_4
    invoke-virtual {p0}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    :goto_5
    const-string p0, "createVrLocalRadioCtrlAPI failed"

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->INVOKESTATIC_com_ecarx_eas_sdk_vr_radio_VrLocalRadioCtrlAPI_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Ljava/security/InvalidParameterException;

    const-string v0, "param Context is null!"

    invoke-direct {p0, v0}, Ljava/security/InvalidParameterException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static get(Landroid/content/Context;)Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
    .locals 2

    sget-object v0, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->mInstance:Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    if-nez v0, :cond_1

    const-class v0, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->mInstance:Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    if-nez v1, :cond_0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->createVrLocalRadioCtrlAPI(Landroid/content/Context;)Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    move-result-object p0

    sput-object p0, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->mInstance:Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    :cond_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0

    :cond_1
    :goto_0
    sget-object p0, Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;->mInstance:Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    return-object p0
.end method


# virtual methods
.method public abstract cancelRadioCtrlCapabilityDeclaration(Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;)Z
.end method

.method public abstract declareRadioCtrlCapability([ILcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;)Z
.end method

.method public abstract declareVrCtrlPriority(Ljava/lang/String;ILcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;)V
.end method
