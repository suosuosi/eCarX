.class public abstract Lcom/ecarx/eas/sdk/vr/news/PlayNewsIntent;
.super Lcom/ecarx/eas/sdk/vr/news/NewsIntent;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/news/NewsIntent;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract getRawText()Ljava/lang/String;
.end method
