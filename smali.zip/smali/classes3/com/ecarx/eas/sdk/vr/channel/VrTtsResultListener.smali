.class public Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;
.super Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultHandling;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultHandling;-><init>()V

    return-void
.end method


# virtual methods
.method public handleTtsResponse(I)V
    .locals 0

    return-void
.end method
