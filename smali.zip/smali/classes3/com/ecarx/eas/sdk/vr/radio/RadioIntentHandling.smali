.class public Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/vr/radio/IRadioIntentHandling;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleCtrlApp(Lcom/ecarx/eas/sdk/vr/common/MediaCtrlIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    .locals 0

    return-void
.end method

.method public handleCtrlRadio(Lcom/ecarx/eas/sdk/vr/radio/ICtrlLocalRadioIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    .locals 0

    return-void
.end method
