.class public interface abstract Lcom/ecarx/eas/sdk/vr/radio/ICtrlLocalRadioIntent;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/vr/radio/ILocalRadioIntent;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract getRawText()Ljava/lang/String;
.end method
