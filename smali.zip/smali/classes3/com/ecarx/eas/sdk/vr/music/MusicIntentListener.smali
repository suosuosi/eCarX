.class public Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;
.super Lcom/ecarx/eas/sdk/vr/music/MusicIntentHandling;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/music/MusicIntentHandling;-><init>()V

    return-void
.end method


# virtual methods
.method public handleCtrlApp(Lcom/ecarx/eas/sdk/vr/common/MediaCtrlIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    .locals 0

    return-void
.end method

.method public handlePlayMusic(Lcom/ecarx/eas/sdk/vr/music/MusicPlayIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    .locals 0

    return-void
.end method

.method public handleSearchMusic(Lcom/ecarx/eas/sdk/vr/music/MusicSearchIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    .locals 0

    return-void
.end method
