.class public Lcom/ecarx/eas/sdk/vr/common/Response;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/vr/common/IResponse;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public failure(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public noHandler()V
    .locals 0

    return-void
.end method

.method public success()V
    .locals 0

    return-void
.end method
