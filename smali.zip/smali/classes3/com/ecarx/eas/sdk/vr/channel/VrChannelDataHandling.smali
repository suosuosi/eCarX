.class abstract Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataHandling;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract handleVrChannelData(ILcom/ecarx/eas/sdk/vr/channel/SemanticData;)V
.end method
