.class public Lcom/ecarx/eas/sdk/vr/channel/VrTTSResult;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final TTS_STATE_PLAY_END:I = 0x4

.field public static final TTS_STATE_PLAY_INTERRUPTED:I = 0x3

.field public static final TTS_STATE_PLAY_PAUSE:I = 0x2

.field public static final TTS_STATE_PLAY_START:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
