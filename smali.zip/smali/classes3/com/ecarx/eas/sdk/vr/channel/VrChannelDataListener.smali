.class public Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;
.super Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataHandling;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataHandling;-><init>()V

    return-void
.end method


# virtual methods
.method public handleVrChannelData(ILcom/ecarx/eas/sdk/vr/channel/SemanticData;)V
    .locals 0

    return-void
.end method
