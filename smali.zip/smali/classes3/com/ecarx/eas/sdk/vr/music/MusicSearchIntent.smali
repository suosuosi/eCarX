.class public abstract Lcom/ecarx/eas/sdk/vr/music/MusicSearchIntent;
.super Lcom/ecarx/eas/sdk/vr/music/MusicIntent;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/music/MusicIntent;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract getRawText()Ljava/lang/String;
.end method
