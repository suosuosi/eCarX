.class public Lcom/ecarx/eas/sdk/vr/news/NewsIntentListener;
.super Lcom/ecarx/eas/sdk/vr/news/NewsIntentHandling;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/news/NewsIntentHandling;-><init>()V

    return-void
.end method


# virtual methods
.method public handlePlayNews(Lcom/ecarx/eas/sdk/vr/news/PlayNewsIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    .locals 0

    return-void
.end method
