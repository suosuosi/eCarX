.class public interface abstract Lcom/ecarx/eas/sdk/device/a/a/e;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/a/e$a;
    }
.end annotation


# virtual methods
.method public abstract a(I)Landroid/os/IBinder;
.end method
