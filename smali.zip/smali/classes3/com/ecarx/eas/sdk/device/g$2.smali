.class final Lcom/ecarx/eas/sdk/device/g$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/device/g;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/device/g;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;Z)Z
    .locals 0

    if-eqz p4, :cond_0

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/sdk/device/g;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/sdk/device/g;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    return p2
.end method

.method public final onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z
    .locals 0

    if-eqz p3, :cond_0

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/sdk/device/g;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/sdk/device/g;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g$2;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    return p2
.end method
