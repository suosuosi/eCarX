.class abstract Lcom/ecarx/eas/sdk/device/k;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/device/k$1;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_0

    invoke-static {}, Lcom/ecarx/eas/sdk/device/i;->a()Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-static {}, Lcom/ecarx/eas/sdk/device/j;->a()Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object p0

    return-object p0
.end method
