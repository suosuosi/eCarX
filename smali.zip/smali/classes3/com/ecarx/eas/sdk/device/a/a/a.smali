.class public interface abstract Lcom/ecarx/eas/sdk/device/a/a/a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/a/a$a;
    }
.end annotation


# virtual methods
.method public abstract a()Lcom/ecarx/eas/sdk/device/a/a/b;
.end method
