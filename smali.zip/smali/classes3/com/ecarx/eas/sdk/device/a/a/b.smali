.class public interface abstract Lcom/ecarx/eas/sdk/device/a/a/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/a/b$a;
    }
.end annotation


# virtual methods
.method public abstract a(I)I
.end method

.method public abstract a(ILcom/ecarx/eas/sdk/device/a/a/d;)Lcom/ecarx/eas/sdk/device/a/a/c;
.end method

.method public abstract a(Lcom/ecarx/eas/sdk/device/a/a/c;)V
.end method
