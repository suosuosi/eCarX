.class public interface abstract Lcom/ecarx/eas/sdk/device/a/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/b$a;
    }
.end annotation


# virtual methods
.method public abstract a()I
.end method

.method public abstract a(Lcom/ecarx/eas/sdk/device/a/a;)Z
.end method

.method public abstract b()I
.end method

.method public abstract b(Lcom/ecarx/eas/sdk/device/a/a;)Z
.end method
