.class public abstract Lcom/ecarx/eas/sdk/device/a/a/b$a;
.super Landroid/os/Binder;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/a/a/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/device/a/a/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/a/b$a$a;
    }
.end annotation


# direct methods
.method public static a()Lcom/ecarx/eas/sdk/device/a/a/b;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public static a(Landroid/os/IBinder;)Lcom/ecarx/eas/sdk/device/a/a/b;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "ecarx.xsf.gkuiservice.policy.IFunPolicy"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/ecarx/eas/sdk/device/a/a/b;

    if-eqz v1, :cond_1

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/a/b;

    return-object v0

    :cond_1
    new-instance v0, Lcom/ecarx/eas/sdk/device/a/a/b$a$a;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/sdk/device/a/a/b$a$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method


# virtual methods
.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    const/4 v0, 0x1

    const-string v1, "ecarx.xsf.gkuiservice.policy.IFunPolicy"

    if-eq p1, v0, :cond_6

    const/4 v2, 0x2

    if-eq p1, v2, :cond_2

    const/4 v2, 0x3

    if-eq p1, v2, :cond_1

    const v2, 0x5f4e5446

    if-eq p1, v2, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    :cond_0
    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v0

    :cond_1
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/a/a/c$a;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/sdk/device/a/a/c;

    move-result-object p1

    invoke-interface {p0, p1}, Lcom/ecarx/eas/sdk/device/a/a/b;->a(Lcom/ecarx/eas/sdk/device/a/a/c;)V

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    return v0

    :cond_2
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p2

    const/4 p4, 0x0

    if-nez p2, :cond_3

    move-object v1, p4

    goto :goto_0

    :cond_3
    const-string v1, "ecarx.xsf.gkuiservice.policy.IFunPolicyListener"

    invoke-interface {p2, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v1

    if-eqz v1, :cond_4

    instance-of v2, v1, Lcom/ecarx/eas/sdk/device/a/a/d;

    if-eqz v2, :cond_4

    check-cast v1, Lcom/ecarx/eas/sdk/device/a/a/d;

    goto :goto_0

    :cond_4
    new-instance v1, Lcom/ecarx/eas/sdk/device/a/a/d$a$a;

    invoke-direct {v1, p2}, Lcom/ecarx/eas/sdk/device/a/a/d$a$a;-><init>(Landroid/os/IBinder;)V

    :goto_0
    invoke-interface {p0, p1, v1}, Lcom/ecarx/eas/sdk/device/a/a/b;->a(ILcom/ecarx/eas/sdk/device/a/a/d;)Lcom/ecarx/eas/sdk/device/a/a/c;

    move-result-object p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    if-eqz p1, :cond_5

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p4

    :cond_5
    invoke-virtual {p3, p4}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    return v0

    :cond_6
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-interface {p0, p1}, Lcom/ecarx/eas/sdk/device/a/a/b;->a(I)I

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v0
.end method
