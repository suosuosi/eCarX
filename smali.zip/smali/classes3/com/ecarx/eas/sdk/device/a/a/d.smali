.class public interface abstract Lcom/ecarx/eas/sdk/device/a/a/d;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/a/d$a;
    }
.end annotation


# virtual methods
.method public abstract a(I)V
.end method

.method public abstract a(II)V
.end method
