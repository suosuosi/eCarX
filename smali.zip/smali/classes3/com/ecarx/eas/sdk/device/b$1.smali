.class final Lcom/ecarx/eas/sdk/device/b$1;
.super Lcom/ecarx/eas/sdk/device/a/a$a;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/device/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/device/b;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/device/b;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/b$1;->a:Lcom/ecarx/eas/sdk/device/b;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/a/a$a;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_b$1_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a(I)V
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b$1;->a:Lcom/ecarx/eas/sdk/device/b;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/b;->a(Lcom/ecarx/eas/sdk/device/b;)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b$1;->a:Lcom/ecarx/eas/sdk/device/b;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/b;->a(Lcom/ecarx/eas/sdk/device/b;)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;

    invoke-interface {v1, p1}, Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;->onDayNightModeChange(I)V

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    const-string v2, ">> onDayNightModeChange(%d)"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DayNightMode"

    invoke-static {v2, v1}, Lcom/ecarx/eas/sdk/device/b$1;->INVOKESTATIC_com_ecarx_eas_sdk_device_b$1_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final b(I)V
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b$1;->a:Lcom/ecarx/eas/sdk/device/b;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/b;->a(Lcom/ecarx/eas/sdk/device/b;)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b$1;->a:Lcom/ecarx/eas/sdk/device/b;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/b;->a(Lcom/ecarx/eas/sdk/device/b;)Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;

    invoke-interface {v1, p1}, Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;->onDayNightChanged(I)V

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v1, v2

    const-string v2, ">> onDayNightChanged(%d)"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DayNightMode"

    invoke-static {v2, v1}, Lcom/ecarx/eas/sdk/device/b$1;->INVOKESTATIC_com_ecarx_eas_sdk_device_b$1_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_1
    return-void
.end method
