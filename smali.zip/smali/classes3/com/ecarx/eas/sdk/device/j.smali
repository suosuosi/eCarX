.class final Lcom/ecarx/eas/sdk/device/j;
.super Lcom/ecarx/eas/framework/sdk/common/internal/IApi;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/IApi<",
        "Lcom/ecarx/eas/sdk/device/a/a/b;",
        ">;",
        "Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;"
    }
.end annotation


# static fields
.field private static b:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/device/j$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/device/j$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/device/j;->b:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/j;->a:Ljava/util/Map;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method protected static a()Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/device/j;->b:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final getState(I)I
    .locals 6

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mAliveFlag:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "FunPolicyAPI"

    if-nez v0, :cond_0

    new-array v0, v3, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v0, v2

    const-string p1, ">> getState(%d) and mFunPolicy is NULL!!! <<"

    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/a/b;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/device/a/a/b;->a(I)I

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v5, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v5, v2

    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v5, v3

    const-string p1, ">> getState(%d) RemoteException: %s <<"

    invoke-static {p1, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1, v0}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v1
.end method

.method public final registerListener(ILcom/ecarx/eas/sdk/device/api/JoyLimitListener;)Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mAliveFlag:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    if-nez p2, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/j;->a:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "FunPolicyAPI"

    if-eqz v0, :cond_1

    const-string p1, "registerListener: duplicate register mJoyLimitListeners.contains(listener)"

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_1
    new-instance v0, Lcom/ecarx/eas/sdk/device/m;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/device/m;-><init>(Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;)V

    :try_start_0
    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v3, Lcom/ecarx/eas/sdk/device/a/a/b;

    invoke-interface {v3, p1, v0}, Lcom/ecarx/eas/sdk/device/a/a/b;->a(ILcom/ecarx/eas/sdk/device/a/a/d;)Lcom/ecarx/eas/sdk/device/a/a/c;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "registerListener: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, p1}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object p1, v1

    :goto_0
    if-eqz p1, :cond_2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/j;->a:Ljava/util/Map;

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_2
    const-string p1, "registerListener fail!!!"

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    :goto_1
    return-object v1
.end method

.method public final unRegisterListener(Ljava/lang/Object;)V
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mAliveFlag:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const-string v1, "FunPolicyAPI"

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/j;->a:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/a/b;

    if-eqz p1, :cond_2

    instance-of v2, p1, Lcom/ecarx/eas/sdk/device/a/a/c;

    if-eqz v2, :cond_1

    move-object v2, p1

    check-cast v2, Lcom/ecarx/eas/sdk/device/a/a/c;

    invoke-interface {v0, v2}, Lcom/ecarx/eas/sdk/device/a/a/b;->a(Lcom/ecarx/eas/sdk/device/a/a/c;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/j;->a:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "token is invalid !"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "token is null!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "unRegisterListener: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, p1}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void

    :cond_3
    :goto_0
    const-string p1, "unRegisterListener: mJoyLimitListenerMap.containsKey(token) false!"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/device/j;->INVOKESTATIC_com_ecarx_eas_sdk_device_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
