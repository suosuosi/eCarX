.class public abstract Lcom/ecarx/eas/sdk/device/api/DeviceAPI;
.super Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;-><init>()V

    return-void
.end method

.method public static createDeviceAPI(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/api/DeviceAPI;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {}, Lcom/ecarx/eas/sdk/device/f;->a()Lcom/ecarx/eas/sdk/device/f;

    move-result-object p0

    return-object p0
.end method

.method public static get(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/api/DeviceAPI;
    .locals 0

    invoke-static {}, Lcom/ecarx/eas/sdk/device/f;->a()Lcom/ecarx/eas/sdk/device/f;

    move-result-object p0

    return-object p0
.end method
