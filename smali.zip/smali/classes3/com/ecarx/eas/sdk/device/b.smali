.class public final Lcom/ecarx/eas/sdk/device/b;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDayNightMode;


# instance fields
.field private a:Lcom/ecarx/eas/sdk/device/a/b;

.field private final b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private d:Lcom/ecarx/eas/sdk/device/a/a;


# direct methods
.method public constructor <init>(Lcom/ecarx/eas/sdk/device/a/b;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->b:Ljava/util/Set;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v0, Lcom/ecarx/eas/sdk/device/b$1;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/sdk/device/b$1;-><init>(Lcom/ecarx/eas/sdk/device/b;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->d:Lcom/ecarx/eas/sdk/device/a/a;

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_b_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_b_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/b;)Ljava/util/Set;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/b;->b:Ljava/util/Set;

    return-object p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a()V
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/b;->d:Lcom/ecarx/eas/sdk/device/a/a;

    invoke-interface {v1, v2}, Lcom/ecarx/eas/sdk/device/a/b;->a(Lcom/ecarx/eas/sdk/device/a/a;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-void

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_1
    return-void
.end method

.method public final a(Lcom/ecarx/eas/sdk/device/a/b;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/device/b;->a()V

    return-void
.end method

.method public final getDayNight()I
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/b;->b()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v1, "DayNightMode"

    const-string v2, "Fail to get DayNight."

    invoke-static {v1, v2, v0}, Lcom/ecarx/eas/sdk/device/b;->INVOKESTATIC_com_ecarx_eas_sdk_device_b_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v0, -0x1

    return v0
.end method

.method public final getDayNightMode()I
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/b;->a()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v1, "DayNightMode"

    const-string v2, "Fail to get DayNightMode."

    invoke-static {v1, v2, v0}, Lcom/ecarx/eas/sdk/device/b;->INVOKESTATIC_com_ecarx_eas_sdk_device_b_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v0, -0x1

    return v0
.end method

.method public final registerDayNightModeCallBack(Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;)Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x1

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/b;->d:Lcom/ecarx/eas/sdk/device/a/a;

    invoke-interface {v0, v2}, Lcom/ecarx/eas/sdk/device/a/b;->a(Lcom/ecarx/eas/sdk/device/a/a;)Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v0, "DayNightMode"

    const-string v2, ">> registerDayNightModeCallBack Fail!!! <<"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/device/b;->INVOKESTATIC_com_ecarx_eas_sdk_device_b_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    move v0, v1

    :goto_0
    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    :cond_1
    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->b:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v0

    :cond_2
    return v0
.end method

.method public final unregisterDayNigntModeCallBack(Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->b:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->b:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    return p1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->a:Lcom/ecarx/eas/sdk/device/a/b;

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/b;->d:Lcom/ecarx/eas/sdk/device/a/a;

    invoke-interface {v0, v1}, Lcom/ecarx/eas/sdk/device/a/b;->b(Lcom/ecarx/eas/sdk/device/a/a;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    :cond_1
    :goto_0
    return p1
.end method
