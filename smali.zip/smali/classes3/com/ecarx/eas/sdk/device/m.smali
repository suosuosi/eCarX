.class final Lcom/ecarx/eas/sdk/device/m;
.super Lcom/ecarx/eas/sdk/device/a/a/d$a;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;


# direct methods
.method public constructor <init>(Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/a/a/d$a;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/m;->a:Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;

    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 0

    return-void
.end method

.method public final a(II)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/m;->a:Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;->onJoyLimitStateChanged(II)V

    return-void
.end method
