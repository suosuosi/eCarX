.class public interface abstract Lcom/ecarx/eas/sdk/device/a/d;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/device/a/d$a;
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/String;I)V
.end method
