.class public final Lcom/ecarx/eas/sdk/device/f;
.super Lcom/ecarx/eas/sdk/device/api/DeviceAPI;
.source ""


# static fields
.field private static d:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/device/f;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private volatile a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

.field private volatile b:Ljava/lang/String;

.field private volatile c:I

.field private e:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/device/f$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/device/f$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/device/f;->d:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/api/DeviceAPI;-><init>()V

    new-instance v0, Lcom/ecarx/eas/sdk/device/f$2;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/sdk/device/f$2;-><init>(Lcom/ecarx/eas/sdk/device/f;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->e:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/f;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;)I
    .locals 4

    const/4 v0, 0x1

    if-nez p1, :cond_0

    return v0

    :cond_0
    iget-object p1, p1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    if-eqz p1, :cond_4

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, -0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_2
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;

    iget v3, v2, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;->type:I

    if-le v3, v0, :cond_2

    iget v0, v2, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;->version:I

    move v1, v0

    move v0, v3

    goto :goto_0

    :cond_3
    iput v1, p0, Lcom/ecarx/eas/sdk/device/f;->c:I

    :cond_4
    :goto_1
    return v0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/f;)Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    return-object p0
.end method

.method public static a()Lcom/ecarx/eas/sdk/device/f;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/device/f;->d:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/device/f;

    return-object v0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/f;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V
    .locals 7

    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-ne p1, v1, :cond_0

    move-object v2, v1

    goto :goto_0

    :cond_0
    move-object v2, v0

    :goto_0
    sget-object v3, Lcom/ecarx/eas/sdk/device/d$1;->a:[I

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v3, v3, v4

    const/4 v4, 0x1

    if-eq v3, v4, :cond_1

    invoke-static {}, Lcom/ecarx/eas/sdk/device/h;->a()Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object v3

    goto :goto_1

    :cond_1
    invoke-static {}, Lcom/ecarx/eas/sdk/device/c;->a()Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object v3

    :goto_1
    iput-object v3, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-ne p1, v0, :cond_2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/f;->b()V

    return-void

    :cond_2
    if-ne p1, v1, :cond_3

    if-ne v2, v1, :cond_3

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/f;->c()V

    return-void

    :cond_3
    if-ne p1, v1, :cond_7

    if-ne v2, v0, :cond_7

    const/4 p1, 0x0

    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/DeadObjectException;->printStackTrace()V

    move-object v0, p1

    :goto_2
    const/4 v1, 0x0

    const-string v2, "DeviceAPI"

    if-nez v0, :cond_4

    new-array p0, v1, [Ljava/lang/Object;

    const-string p1, ">> EASFrameworkService is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    :goto_3
    invoke-static {v2, p0}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_4
    :try_start_1
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v4

    iget-object v5, p0, Lcom/ecarx/eas/sdk/device/f;->b:Ljava/lang/String;

    const-string v6, "device"

    invoke-interface {v0, v3, v4, v5, v6}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->getService(IILjava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object p1
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_4
    if-nez p1, :cond_5

    new-array p0, v1, [Ljava/lang/Object;

    const-string p1, ">> EASFrameworkService device binder is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto :goto_3

    :cond_5
    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/a/c$a;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/sdk/device/a/c;

    move-result-object p1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    instance-of v0, v0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz v0, :cond_6

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_6
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/g;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/g;

    move-result-object p1

    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/f;->b:Ljava/lang/String;

    invoke-virtual {p1, v0, p0}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/f;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;I)V
    .locals 2

    const/4 p1, 0x3

    const/4 v0, 0x1

    if-eq p2, v0, :cond_0

    if-eq p2, p1, :cond_0

    invoke-static {}, Lcom/ecarx/eas/sdk/device/h;->a()Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object v1

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/ecarx/eas/sdk/device/c;->a()Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object v1

    :goto_0
    iput-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-eq p2, v0, :cond_2

    if-ne p2, p1, :cond_1

    goto :goto_1

    :cond_1
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/f;->c()V

    return-void

    :cond_2
    :goto_1
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/f;->b()V

    return-void
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private b()V
    .locals 8

    const/4 v0, 0x0

    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v1

    invoke-virtual {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    move-result-object v1
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Landroid/os/DeadObjectException;->printStackTrace()V

    move-object v1, v0

    :goto_0
    const/4 v2, 0x0

    const-string v3, "DeviceAPI"

    if-nez v1, :cond_0

    new-array v0, v2, [Ljava/lang/Object;

    const-string v1, ">> OpenAPIService getServicePool is NULL <<"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_1
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v4

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v5

    iget-object v6, p0, Lcom/ecarx/eas/sdk/device/f;->b:Ljava/lang/String;

    const-string v7, "device"

    invoke-interface {v1, v4, v5, v6, v7}, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;->getService(IILjava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception v1

    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_1
    if-nez v0, :cond_1

    new-array v0, v2, [Ljava/lang/Object;

    const-string v1, ">> OpenAPIService device binder is NULL <<"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_1
    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/a/c$a;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/sdk/device/a/c;

    move-result-object v0

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    instance-of v1, v1, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_2
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/g;

    move-result-object v0

    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/f;->b:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Ljava/lang/String;)V

    return-void
.end method

.method private c()V
    .locals 3

    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/DeadObjectException;->printStackTrace()V

    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_0

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, ">> EASFrameworkService is NULL <<"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DeviceAPI"

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    instance-of v1, v1, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_1
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/g;

    move-result-object v0

    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/f;->b:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lcom/ecarx/eas/sdk/device/g;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final getDayNightMode()Lcom/ecarx/eas/sdk/device/api/IDayNightMode;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getDayNightMode()Lcom/ecarx/eas/sdk/device/api/IDayNightMode;

    move-result-object v0

    return-object v0
.end method

.method public final getDeviceState()Lcom/ecarx/eas/sdk/device/api/IDeviceState;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getDeviceState()Lcom/ecarx/eas/sdk/device/api/IDeviceState;

    move-result-object v0

    return-object v0
.end method

.method public final getOpenIHUID()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getOpenIHUID()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getOpenVIN()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getOpenVIN()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getOperatorCode()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, -0x1

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getOperatorCode()I

    move-result v0

    return v0
.end method

.method public final getOperatorName()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getOperatorName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getSupplierCode()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getSupplierCode()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getVehicleType()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    if-nez v0, :cond_0

    const-string v0, "DeviceAPI"

    const-string v1, ">> please wait for device init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getVehicleType()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getVehicleTypeConfig()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    const/4 v1, 0x0

    const-string v2, "DeviceAPI"

    if-nez v0, :cond_0

    const-string v0, ">> please wait for device init success!!! <<"

    :goto_0
    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/device/f;->INVOKESTATIC_com_ecarx_eas_sdk_device_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    iget v0, p0, Lcom/ecarx/eas/sdk/device/f;->c:I

    const/4 v3, 0x2

    if-ge v0, v3, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "service version<2  version="

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v3, p0, Lcom/ecarx/eas/sdk/device/f;->c:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->a:Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;->getVehicleTypeConfig()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;)V
    .locals 3

    invoke-super {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;->init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;)V

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/f;->b:Ljava/lang/String;

    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    const-string v1, "device"

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/f;->e:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)V
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public final release()V
    .locals 0

    invoke-super {p0}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;->release()V

    return-void
.end method
