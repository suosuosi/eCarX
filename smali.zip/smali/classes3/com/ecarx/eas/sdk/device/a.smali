.class public abstract Lcom/ecarx/eas/sdk/device/a;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method public static a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)I
    .locals 10

    const-string v0, "DayNightAPI"

    const/4 v1, -0x1

    if-nez p0, :cond_0

    return v1

    :cond_0
    new-instance v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;

    invoke-direct {v2}, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;-><init>()V

    const-string v3, ""

    iput-object v3, v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;->value:Ljava/lang/String;

    new-instance v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    invoke-static {v2}, Lcom/ecarx/eas/framework/sdk/proto/MessageNano;->toByteArray(Lcom/ecarx/eas/framework/sdk/proto/MessageNano;)[B

    move-result-object v8

    const/4 v2, 0x0

    new-array v9, v2, [B

    const-string v5, "device"

    const-string v6, "daymode"

    move-object v4, v3

    move-object v7, p1

    invoke-direct/range {v4 .. v9}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    :try_start_0
    invoke-static {p0, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->sendMsg(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    move-result-object p0

    iget p1, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    const/16 v4, 0xc8

    if-eq p1, v4, :cond_1

    const-string v4, ">> method = %s, code=%d, msg=%s <<"

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    iget-object v3, v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;->mMethod:Ljava/lang/String;

    aput-object v3, v5, v2

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v5, v2

    const/4 p1, 0x2

    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mMsg:Ljava/lang/String;

    aput-object p0, v5, p1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/device/a;->INVOKESTATIC_com_ecarx_eas_sdk_device_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_1
    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    invoke-static {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->getInt([B)I

    move-result p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1, p0}, Lcom/ecarx/eas/sdk/device/a;->INVOKESTATIC_com_ecarx_eas_sdk_device_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v1
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method
