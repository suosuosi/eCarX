.class public interface abstract Lcom/ecarx/eas/sdk/device/api/IDayNightMode$IDayNightChangeCallBack;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/device/api/IDayNightMode;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "IDayNightChangeCallBack"
.end annotation


# virtual methods
.method public abstract onDayNightChanged(I)V
.end method

.method public abstract onDayNightModeChange(I)V
.end method
