.class public Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "JoyLimitListener"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onJoyLimitStateChanged(II)V
    .locals 0

    return-void
.end method
