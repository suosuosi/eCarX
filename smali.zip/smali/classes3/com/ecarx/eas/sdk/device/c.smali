.class final Lcom/ecarx/eas/sdk/device/c;
.super Lcom/ecarx/eas/framework/sdk/common/internal/IApi;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/IApi<",
        "Lcom/ecarx/eas/sdk/device/a/c;",
        ">;",
        "Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;"
    }
.end annotation


# static fields
.field private static b:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/device/c;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Lcom/ecarx/eas/sdk/device/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/device/c$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/device/c$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/device/c;->b:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method public static a()Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/device/c;->b:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final getDayNightMode()Lcom/ecarx/eas/sdk/device/api/IDayNightMode;
    .locals 3

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/c;->a:Lcom/ecarx/eas/sdk/device/b;

    if-nez v0, :cond_1

    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/device/b;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v1, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/device/a/c;->i()Lcom/ecarx/eas/sdk/device/a/b;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/device/b;-><init>(Lcom/ecarx/eas/sdk/device/a/b;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/c;->a:Lcom/ecarx/eas/sdk/device/b;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    const-string v1, "DeviceAPI"

    const-string v2, "Fail to create OpenDayNightModeWrapper"

    invoke-static {v1, v2, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    :cond_1
    :goto_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/c;->a:Lcom/ecarx/eas/sdk/device/b;

    return-object v0
.end method

.method public final getDeviceState()Lcom/ecarx/eas/sdk/device/api/IDeviceState;
    .locals 1

    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/g;

    move-result-object v0

    return-object v0
.end method

.method public final getOpenIHUID()Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->m()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v2, "DeviceAPI"

    const-string v3, "Fail to getOpenIHUID"

    invoke-static {v2, v3, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method public final getOpenVIN()Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->n()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v2, "DeviceAPI"

    const-string v3, "Fail to getOpenVIN"

    invoke-static {v2, v3, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method public final getOperatorCode()I
    .locals 4

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_0

    return v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->k()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v2, "DeviceAPI"

    const-string v3, "Fail to getOperatorCode"

    invoke-static {v2, v3, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v1
.end method

.method public final getOperatorName()Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->l()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v2, "DeviceAPI"

    const-string v3, "Fail to getOperatorName"

    invoke-static {v2, v3, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method public final getSupplierCode()Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->h()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v2, "DeviceAPI"

    const-string v3, "Fail to getSupplierCode"

    invoke-static {v2, v3, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method public final getVehicleType()Ljava/lang/String;
    .locals 4

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->f()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-string v2, "DeviceAPI"

    const-string v3, "Fail to getVehicleType"

    invoke-static {v2, v3, v0}, Lcom/ecarx/eas/sdk/device/c;->INVOKESTATIC_com_ecarx_eas_sdk_device_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method public final getVehicleTypeConfig()Ljava/lang/String;
    .locals 2

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->q()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method public final synthetic init(Landroid/os/IInterface;)V
    .locals 1

    check-cast p1, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-super {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mAliveFlag:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/c;->a:Lcom/ecarx/eas/sdk/device/b;

    if-eqz p1, :cond_0

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/sdk/device/a/c;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/device/a/c;->i()Lcom/ecarx/eas/sdk/device/a/b;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/ecarx/eas/sdk/device/b;->a(Lcom/ecarx/eas/sdk/device/a/b;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :cond_0
    return-void
.end method
