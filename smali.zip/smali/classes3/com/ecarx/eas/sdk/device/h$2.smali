.class final Lcom/ecarx/eas/sdk/device/h$2;
.super Lcom/ecarx/eas/sdk/device/a/b$a;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/device/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/device/h;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/device/h;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/h$2;->a:Lcom/ecarx/eas/sdk/device/h;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/device/a/b$a;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_h$2_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/h$2;->a:Lcom/ecarx/eas/sdk/device/h;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/h;->a(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getDayNightMode"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final a(Lcom/ecarx/eas/sdk/device/a/a;)Z
    .locals 10

    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/h$2;->a:Lcom/ecarx/eas/sdk/device/h;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/device/h;->c(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    if-nez v1, :cond_0

    return v0

    :cond_0
    new-instance v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;

    invoke-direct {v2}, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;-><init>()V

    const-string v3, ""

    iput-object v3, v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;->value:Ljava/lang/String;

    new-instance v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    const-string v5, "device"

    const-string v6, "daymode"

    const-string v7, "registerDayNightModeCallBack"

    invoke-static {v2}, Lcom/ecarx/eas/framework/sdk/proto/MessageNano;->toByteArray(Lcom/ecarx/eas/framework/sdk/proto/MessageNano;)[B

    move-result-object v8

    new-array v9, v0, [B

    move-object v4, v3

    invoke-direct/range {v4 .. v9}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {v1, v3, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->sendMsgAndBinder(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    move-result-object p1

    iget v1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    const/16 v2, 0xc8

    if-eq v1, v2, :cond_1

    const-string v2, "DayNightAPI"

    const-string v4, ">> \u670d\u52a1\u5185\u90e8\u9519\u8bef method = %s, code=%d, msg=%s <<"

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    iget-object v3, v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;->mMethod:Ljava/lang/String;

    aput-object v3, v5, v0

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v3

    const/4 v1, 0x2

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mMsg:Ljava/lang/String;

    aput-object p1, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/device/h$2;->INVOKESTATIC_com_ecarx_eas_sdk_device_h$2_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v0

    :cond_1
    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->getBool([B)Z

    move-result p1
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v0
.end method

.method public final b()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/h$2;->a:Lcom/ecarx/eas/sdk/device/h;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/h;->b(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getDayNight"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final b(Lcom/ecarx/eas/sdk/device/a/a;)Z
    .locals 10

    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/h$2;->a:Lcom/ecarx/eas/sdk/device/h;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/device/h;->d(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    if-nez v1, :cond_0

    return v0

    :cond_0
    new-instance v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;

    invoke-direct {v2}, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;-><init>()V

    const-string v3, ""

    iput-object v3, v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;->value:Ljava/lang/String;

    new-instance v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    const-string v5, "device"

    const-string v6, "daymode"

    const-string v7, "unregisterDayNightModeCallBack"

    invoke-static {v2}, Lcom/ecarx/eas/framework/sdk/proto/MessageNano;->toByteArray(Lcom/ecarx/eas/framework/sdk/proto/MessageNano;)[B

    move-result-object v8

    new-array v9, v0, [B

    move-object v4, v3

    invoke-direct/range {v4 .. v9}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {v1, v3, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->sendMsgAndBinder(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    move-result-object p1

    iget v1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    const/16 v2, 0xc8

    if-eq v1, v2, :cond_1

    const-string v2, "DayNightAPI"

    const-string v4, ">> \u670d\u52a1\u5185\u90e8\u9519\u8bef method = %s, code=%d, msg=%s <<"

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    iget-object v3, v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;->mMethod:Ljava/lang/String;

    aput-object v3, v5, v0

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v3

    const/4 v1, 0x2

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mMsg:Ljava/lang/String;

    aput-object p1, v5, v1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/device/h$2;->INVOKESTATIC_com_ecarx_eas_sdk_device_h$2_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v0

    :cond_1
    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->getBool([B)Z

    move-result p1
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v0
.end method
