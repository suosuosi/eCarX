.class final Lcom/ecarx/eas/sdk/device/i;
.super Lcom/ecarx/eas/framework/sdk/common/internal/IApi;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/IApi<",
        "Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;",
        ">;",
        "Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;"
    }
.end annotation


# static fields
.field private static b:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/device/i$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/device/i$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/device/i;->b:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/i;->a:Ljava/util/Map;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method protected static a()Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/device/i;->b:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final getState(I)I
    .locals 1

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->isAlive()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, -0x1

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/device/l;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;I)I

    move-result p1

    return p1
.end method

.method public final registerListener(ILcom/ecarx/eas/sdk/device/api/JoyLimitListener;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mAliveFlag:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    if-nez p2, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/i;->a:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "EasFunPolicyAPI"

    if-eqz v0, :cond_1

    const-string p1, "registerListener: duplicate register mJoyLimitListeners.contains(listener)"

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_1
    new-instance v0, Lcom/ecarx/eas/sdk/device/m;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/device/m;-><init>(Lcom/ecarx/eas/sdk/device/api/JoyLimitListener;)V

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    invoke-static {v1, p1, v0}, Lcom/ecarx/eas/sdk/device/l;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;ILcom/ecarx/eas/sdk/device/m;)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/i;->a:Ljava/util/Map;

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_2
    const-string p2, "registerListener fail!!!"

    invoke-static {v2, p2}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-object p1

    :cond_3
    :goto_1
    return-object v1
.end method

.method public final unRegisterListener(Ljava/lang/Object;)V
    .locals 10

    const-string v0, "DrivePolicyAPI"

    const-string v1, "EasFunPolicyAPI"

    if-nez p1, :cond_0

    const-string p1, "unRegisterListener fail: token is NULL!"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mAliveFlag:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_5

    iget-object v2, p0, Lcom/ecarx/eas/sdk/device/i;->a:Ljava/util/Map;

    invoke-interface {v2, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    goto/16 :goto_1

    :cond_1
    instance-of v2, p1, Landroid/os/IBinder;

    if-nez v2, :cond_2

    const-string p1, "unRegisterListener fail: token is Not Binder!"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_2
    move-object v2, p1

    check-cast v2, Landroid/os/IBinder;

    :try_start_0
    const-string v3, "ecarx.xsf.gkuiservice.policy.IFunPolicyClientToken"

    invoke-interface {v2}, Landroid/os/IBinder;->getInterfaceDescriptor()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    const-string p1, "unRegisterListener fail: token is Not ecarx.xsf.gkuiservice.policy.IFunPolicyClientToken!"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1

    return-void

    :cond_3
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    if-eqz v1, :cond_4

    new-instance v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;

    invoke-direct {v2}, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;-><init>()V

    const-string v3, ""

    iput-object v3, v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$VoidMsg;->value:Ljava/lang/String;

    new-instance v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    invoke-static {v2}, Lcom/ecarx/eas/framework/sdk/proto/MessageNano;->toByteArray(Lcom/ecarx/eas/framework/sdk/proto/MessageNano;)[B

    move-result-object v8

    const/4 v2, 0x0

    new-array v9, v2, [B

    const-string v5, "drivepolicy"

    const-string v6, "funpolicy"

    const-string v7, "unRegisterListener"

    move-object v4, v3

    invoke-direct/range {v4 .. v9}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    :try_start_1
    move-object v4, p1

    check-cast v4, Landroid/os/IBinder;

    invoke-static {v1, v3, v4}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->sendMsgAndBinder(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    move-result-object v1

    iget v4, v1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    const/16 v5, 0xc8

    if-eq v4, v5, :cond_4

    const-string v5, ">> method = %s, code=%d, msg=%s <<"

    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    iget-object v3, v3, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;->mMethod:Ljava/lang/String;

    aput-object v3, v6, v2

    const/4 v2, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    aput-object v3, v6, v2

    const/4 v2, 0x2

    iget-object v1, v1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mMsg:Ljava/lang/String;

    aput-object v1, v6, v2

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_4
    :goto_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/i;->a:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const-string p1, "Token is Died!!!"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_5
    :goto_1
    const-string p1, "unRegisterListener: mJoyLimitListenerMap.containsKey(token) false!"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/device/i;->INVOKESTATIC_com_ecarx_eas_sdk_device_i_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
