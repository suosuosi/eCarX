.class abstract Lcom/ecarx/eas/sdk/device/l;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_l_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_l_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method public static a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;I)I
    .locals 9

    const-string v0, "DrivePolicyAPI"

    const/4 v1, -0x1

    if-nez p0, :cond_0

    return v1

    :cond_0
    new-instance v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;

    invoke-direct {v2}, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;-><init>()V

    iput p1, v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;->value:I

    new-instance p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    invoke-static {v2}, Lcom/ecarx/eas/framework/sdk/proto/MessageNano;->toByteArray(Lcom/ecarx/eas/framework/sdk/proto/MessageNano;)[B

    move-result-object v7

    const/4 v2, 0x0

    new-array v8, v2, [B

    const-string v4, "drivepolicy"

    const-string v5, "funpolicy"

    const-string v6, "getState"

    move-object v3, p1

    invoke-direct/range {v3 .. v8}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    :try_start_0
    invoke-static {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->sendMsg(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    move-result-object p0

    iget v3, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    const/16 v4, 0xc8

    if-eq v3, v4, :cond_1

    const-string v4, ">> method = %s, code=%d, msg=%s <<"

    const/4 v5, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;->mMethod:Ljava/lang/String;

    aput-object p1, v5, v2

    const/4 p1, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    aput-object v2, v5, p1

    const/4 p1, 0x2

    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mMsg:Ljava/lang/String;

    aput-object p0, v5, p1

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/device/l;->INVOKESTATIC_com_ecarx_eas_sdk_device_l_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_1
    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    invoke-static {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->getInt([B)I

    move-result p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1, p0}, Lcom/ecarx/eas/sdk/device/l;->INVOKESTATIC_com_ecarx_eas_sdk_device_l_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v1
.end method

.method public static a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;ILcom/ecarx/eas/sdk/device/m;)Ljava/lang/Object;
    .locals 9

    const-string v0, "DrivePolicyAPI"

    const/4 v1, 0x0

    if-nez p0, :cond_0

    return-object v1

    :cond_0
    new-instance v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;

    invoke-direct {v2}, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;-><init>()V

    iput p1, v2, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;->value:I

    new-instance p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    invoke-static {v2}, Lcom/ecarx/eas/framework/sdk/proto/MessageNano;->toByteArray(Lcom/ecarx/eas/framework/sdk/proto/MessageNano;)[B

    move-result-object v7

    const/4 v2, 0x0

    new-array v8, v2, [B

    const-string v4, "drivepolicy"

    const-string v5, "funpolicy"

    const-string v6, "registerListener"

    move-object v3, p1

    invoke-direct/range {v3 .. v8}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    :try_start_0
    invoke-static {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgAPI;->sendMsgAndBinder(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    move-result-object p0

    iget p2, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    const/16 v3, 0xc8

    if-eq p2, v3, :cond_1

    const-string v3, ">> method = %s, code=%d, msg=%s <<"

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;->mMethod:Ljava/lang/String;

    aput-object p1, v4, v2

    const/4 p1, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    aput-object p2, v4, p1

    const/4 p1, 0x2

    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mMsg:Ljava/lang/String;

    aput-object p0, v4, p1

    invoke-static {v3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/device/l;->INVOKESTATIC_com_ecarx_eas_sdk_device_l_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_1
    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mBinder:Landroid/os/IBinder;
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1, p0}, Lcom/ecarx/eas/sdk/device/l;->INVOKESTATIC_com_ecarx_eas_sdk_device_l_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v1
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method
