.class public Lcom/ecarx/eas/sdk/device/g;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDeviceState;


# static fields
.field private static volatile c:Lcom/ecarx/eas/sdk/device/g;


# instance fields
.field private a:Landroid/content/Context;

.field private volatile b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

.field private volatile d:Ljava/lang/String;

.field private e:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private f:Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;

.field private g:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v0, Lcom/ecarx/eas/sdk/device/g$1;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/sdk/device/g$1;-><init>(Lcom/ecarx/eas/sdk/device/g;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->f:Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;

    new-instance v0, Lcom/ecarx/eas/sdk/device/g$3;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/sdk/device/g$3;-><init>(Lcom/ecarx/eas/sdk/device/g;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->g:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/g;->a:Landroid/content/Context;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/g;
    .locals 2

    sget-object v0, Lcom/ecarx/eas/sdk/device/g;->c:Lcom/ecarx/eas/sdk/device/g;

    if-nez v0, :cond_1

    const-class v0, Lcom/ecarx/eas/sdk/device/g;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/device/g;->c:Lcom/ecarx/eas/sdk/device/g;

    if-nez v1, :cond_0

    new-instance v1, Lcom/ecarx/eas/sdk/device/g;

    invoke-direct {v1, p0}, Lcom/ecarx/eas/sdk/device/g;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/ecarx/eas/sdk/device/g;->c:Lcom/ecarx/eas/sdk/device/g;

    :cond_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0

    :cond_1
    :goto_0
    sget-object p0, Lcom/ecarx/eas/sdk/device/g;->c:Lcom/ecarx/eas/sdk/device/g;

    return-object p0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/g;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/g;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object p0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/g;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V
    .locals 7

    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/k;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    sget-object v0, Lcom/ecarx/eas/sdk/device/g$4;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string v2, "DeviceStateProxy"

    const/4 v3, 0x0

    if-eq p1, v0, :cond_3

    const/4 v0, 0x2

    if-eq p1, v0, :cond_0

    goto :goto_1

    :cond_0
    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    move-result-object v3
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    :goto_0
    if-nez v3, :cond_1

    new-array p0, v1, [Ljava/lang/Object;

    const-string p1, ">> EASFrameworkService is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Lcom/ecarx/eas/sdk/device/g;->INVOKESTATIC_com_ecarx_eas_sdk_device_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_1
    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    instance-of p1, p1, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz p1, :cond_2

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    check-cast p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {p0, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_2
    :goto_1
    return-void

    :cond_3
    :try_start_1
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    move-result-object p1
    :try_end_1
    .catch Landroid/os/DeadObjectException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    move-object p1, v3

    :goto_2
    if-nez p1, :cond_4

    new-array p0, v1, [Ljava/lang/Object;

    const-string p1, ">> OpenAPIService getServicePool is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Lcom/ecarx/eas/sdk/device/g;->INVOKESTATIC_com_ecarx_eas_sdk_device_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_4
    :try_start_2
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v4

    iget-object v5, p0, Lcom/ecarx/eas/sdk/device/g;->d:Ljava/lang/String;

    const-string v6, "gkuiservice"

    invoke-interface {p1, v0, v4, v5, v6}, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;->getService(IILjava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object p1
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_3

    :catch_2
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    move-object p1, v3

    :goto_3
    if-nez p1, :cond_5

    new-array p0, v1, [Ljava/lang/Object;

    const-string p1, ">> OpenAPIService GKUIService binder is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Lcom/ecarx/eas/sdk/device/g;->INVOKESTATIC_com_ecarx_eas_sdk_device_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_5
    invoke-static {p1}, Lcom/ecarx/eas/sdk/device/a/a/e$a;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/sdk/device/a/a/e;

    move-result-object p1

    if-nez p1, :cond_6

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    check-cast p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {p0, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    return-void

    :cond_6
    const/16 v0, 0x12c

    :try_start_3
    invoke-interface {p1, v0}, Lcom/ecarx/eas/sdk/device/a/a/e;->a(I)Landroid/os/IBinder;

    move-result-object v3
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_4

    :catch_3
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_4
    if-nez v3, :cond_7

    new-array p1, v1, [Ljava/lang/Object;

    const-string v0, ">> OpenAPIService GKUIService DrivePolicy binder is NULL <<"

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/device/g;->INVOKESTATIC_com_ecarx_eas_sdk_device_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_7
    invoke-static {v3}, Lcom/ecarx/eas/sdk/device/a/a/a$a;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/sdk/device/a/a/a;

    move-result-object p1

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    check-cast p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    return-void
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/sdk/device/g;->b:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    return-object p0
.end method


# virtual methods
.method public final a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Ljava/lang/String;)V
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iput-object p2, p0, Lcom/ecarx/eas/sdk/device/g;->d:Ljava/lang/String;

    sget-object p2, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-ne p1, p2, :cond_1

    const-string p1, "gkuiservice"

    goto :goto_0

    :cond_1
    const-string p1, "drivepolicy"

    :goto_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->a:Landroid/content/Context;

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/g;->f:Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;

    new-instance v2, Lcom/ecarx/eas/sdk/device/g$2;

    invoke-direct {v2, p0}, Lcom/ecarx/eas/sdk/device/g$2;-><init>(Lcom/ecarx/eas/sdk/device/g;)V

    invoke-virtual {p2, v0, v1, p1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)V

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/g;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public getDrivingJoyLimit()Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g;->g:Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    return-object v0
.end method
