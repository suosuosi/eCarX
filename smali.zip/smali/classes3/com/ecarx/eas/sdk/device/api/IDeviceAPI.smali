.class public interface abstract Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final OPERATOR_NAME_UNKNOWN:Ljava/lang/String; = ""
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end field

.field public static final OPERATOR_UNKNOWN:I = 0xff
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end field


# virtual methods
.method public abstract getDayNightMode()Lcom/ecarx/eas/sdk/device/api/IDayNightMode;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getDeviceState()Lcom/ecarx/eas/sdk/device/api/IDeviceState;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getOpenIHUID()Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getOpenVIN()Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getOperatorCode()I
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getOperatorName()Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getSupplierCode()Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getVehicleType()Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract getVehicleTypeConfig()Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method
