.class final Lcom/ecarx/eas/sdk/device/f$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/device/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/device/f;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/device/f;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_f$2_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;Z)Z
    .locals 2

    const/4 p1, 0x1

    const/4 v0, 0x0

    if-nez p4, :cond_1

    iget-object p2, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;)Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object p2

    if-eqz p2, :cond_0

    return p1

    :cond_0
    return v0

    :cond_1
    if-eqz p3, :cond_2

    new-instance p4, Ljava/lang/StringBuilder;

    const-string v1, "VersionInfo>>>"

    invoke-direct {p4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3}, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    const-string v1, "DeviceAPI"

    invoke-static {v1, p4}, Lcom/ecarx/eas/sdk/device/f$2;->INVOKESTATIC_com_ecarx_eas_sdk_device_f$2_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    iget-object p4, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-static {p4, p3}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;)I

    move-result p3

    invoke-static {p4, p2, p3}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;I)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;)Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object p2

    if-eqz p2, :cond_3

    return p1

    :cond_3
    return v0
.end method

.method public final onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z
    .locals 1

    const/4 p1, 0x1

    const/4 v0, 0x0

    if-nez p3, :cond_1

    iget-object p2, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;)Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object p2

    if-eqz p2, :cond_0

    return p1

    :cond_0
    return v0

    :cond_1
    iget-object p3, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-static {p3, p2}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/device/f$2;->a:Lcom/ecarx/eas/sdk/device/f;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/device/f;->a(Lcom/ecarx/eas/sdk/device/f;)Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    move-result-object p2

    if-eqz p2, :cond_2

    return p1

    :cond_2
    return v0
.end method
