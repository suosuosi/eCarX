.class public interface abstract Lcom/ecarx/eas/sdk/device/api/IDeviceState;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract getDrivingJoyLimit()Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;
.end method
