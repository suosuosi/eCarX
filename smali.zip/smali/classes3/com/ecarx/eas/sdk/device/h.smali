.class final Lcom/ecarx/eas/sdk/device/h;
.super Lcom/ecarx/eas/framework/sdk/common/internal/IApi;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/IApi<",
        "Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;",
        ">;",
        "Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;"
    }
.end annotation


# static fields
.field private static a:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/device/h;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private b:Lcom/ecarx/eas/sdk/device/a/b;

.field private c:Lcom/ecarx/eas/sdk/device/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/device/h$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/device/h$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/device/h;->a:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;-><init>()V

    new-instance v0, Lcom/ecarx/eas/sdk/device/h$2;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/sdk/device/h$2;-><init>(Lcom/ecarx/eas/sdk/device/h;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/h;->b:Lcom/ecarx/eas/sdk/device/a/b;

    return-void
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    return-object p0
.end method

.method public static a()Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/device/h;->a:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/device/api/IDeviceAPI;

    return-object v0
.end method

.method static synthetic b(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    return-object p0
.end method

.method static synthetic c(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    return-object p0
.end method

.method static synthetic d(Lcom/ecarx/eas/sdk/device/h;)Landroid/os/IInterface;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    return-object p0
.end method


# virtual methods
.method public final getDayNightMode()Lcom/ecarx/eas/sdk/device/api/IDayNightMode;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/h;->c:Lcom/ecarx/eas/sdk/device/b;

    if-nez v0, :cond_0

    new-instance v0, Lcom/ecarx/eas/sdk/device/b;

    iget-object v1, p0, Lcom/ecarx/eas/sdk/device/h;->b:Lcom/ecarx/eas/sdk/device/a/b;

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/device/b;-><init>(Lcom/ecarx/eas/sdk/device/a/b;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/device/h;->c:Lcom/ecarx/eas/sdk/device/b;

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/h;->c:Lcom/ecarx/eas/sdk/device/b;

    return-object v0
.end method

.method public final getDeviceState()Lcom/ecarx/eas/sdk/device/api/IDeviceState;
    .locals 1

    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/device/g;

    move-result-object v0

    return-object v0
.end method

.method public final getOpenIHUID()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getOpenIHUID"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getOpenVIN()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getOpenVIN"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getOperatorCode()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getOperatorCode"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->b(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public final getOperatorName()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getOperatorName"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getSupplierCode()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getSupplierCode"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getVehicleType()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getVehicleType"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getVehicleTypeConfig()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    const-string v1, "getVehicleTypeConfig"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/device/e;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic init(Landroid/os/IInterface;)V
    .locals 0

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    invoke-super {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    iget-object p1, p0, Lcom/ecarx/eas/sdk/device/h;->c:Lcom/ecarx/eas/sdk/device/b;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lcom/ecarx/eas/sdk/device/b;->a()V

    :cond_0
    return-void
.end method
