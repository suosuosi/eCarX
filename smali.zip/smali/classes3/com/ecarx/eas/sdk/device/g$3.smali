.class final Lcom/ecarx/eas/sdk/device/g$3;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/device/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/device/g;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/device/g;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_device_g$3_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final getState(I)I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    aput-object p1, v0, v1

    const-string p1, ">> IDrivingJoyLimit getState(%d) and Proxy is NULL<<"

    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "DeviceStateProxy"

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/device/g$3;->INVOKESTATIC_com_ecarx_eas_sdk_device_g$3_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, -0x1

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;->getState(I)I

    move-result p1

    return p1
.end method

.method public final registerListener(ILcom/ecarx/eas/sdk/device/api/JoyLimitListener;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    if-nez v0, :cond_0

    const-string p1, "DeviceStateProxy"

    const-string p2, ">> IDrivingJoyLimit registerListener <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/device/g$3;->INVOKESTATIC_com_ecarx_eas_sdk_device_g$3_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;->registerListener(ILcom/ecarx/eas/sdk/device/api/JoyLimitListener;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final unRegisterListener(Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    if-nez v0, :cond_0

    const-string p1, "DeviceStateProxy"

    const-string v0, ">> IDrivingJoyLimit unRegisterListener <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/device/g$3;->INVOKESTATIC_com_ecarx_eas_sdk_device_g$3_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/device/g$3;->a:Lcom/ecarx/eas/sdk/device/g;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/device/g;->b(Lcom/ecarx/eas/sdk/device/g;)Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/device/api/IDrivingJoyLimit;->unRegisterListener(Ljava/lang/Object;)V

    return-void
.end method
