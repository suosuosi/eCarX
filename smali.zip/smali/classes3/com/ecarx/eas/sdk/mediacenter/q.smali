.class public final Lcom/ecarx/eas/sdk/mediacenter/q;
.super Lecarx/xsf/mediacenter/IVideoPlaybackInfo$Stub;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

.field private b:Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IVideoPlaybackInfo$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/q;->a:Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    return-void
.end method

.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IVideoPlaybackInfo$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/q;->b:Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_q_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/q;->a:Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/q;->b:Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final getPlaybackStatus()I
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;->getPlaybackStatus()I

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;->getPlaybackStatus()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final isCollected()Z
    .locals 3

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "VideoPlaybackInfo"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/q;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_q_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;->isCollected()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isDownloaded()Z
    .locals 3

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "VideoPlaybackInfo"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/q;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_q_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;->isDownloaded()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportCollect()Z
    .locals 3

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "VideoPlaybackInfo"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/q;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_q_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;->isSupportCollect()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportDownload()Z
    .locals 3

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "VideoPlaybackInfo"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/q;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_q_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;->isSupportDownload()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportVrCtrlPlayStatus()Z
    .locals 3

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->a()Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const-string v0, "VideoPlaybackInfo"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/q;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_q_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/q;->b()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;->isSupportVrCtrlPlayStatus()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method
