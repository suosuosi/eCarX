.class public interface abstract Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract register(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;)Ljava/lang/Object;
.end method

.method public abstract requestControlled(Ljava/lang/Object;)Z
.end method

.method public abstract unregister(Ljava/lang/Object;)Z
.end method
