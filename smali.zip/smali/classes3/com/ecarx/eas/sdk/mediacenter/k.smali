.class public final Lcom/ecarx/eas/sdk/mediacenter/k;
.super Lecarx/xsf/mediacenter/INewsClient$Stub;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

.field private b:Lcom/ecarx/eas/sdk/mediacenter/NewsClient;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/INewsClient$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/k;->a:Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    return-void
.end method

.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/INewsClient$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/k;->b:Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_k_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/k;->a:Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/k;->b:Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final getNewsPlaybackInfo()Lecarx/xsf/mediacenter/INewsPlaybackInfo;
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/l;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v1

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/INewsClient;->getNewsPlaybackInfo()Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/l;-><init>(Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)V

    return-object v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/l;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v1

    invoke-virtual {v1}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->getNewsPlaybackInfo()Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/l;-><init>(Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)V

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final onCollect(IZ)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "NewsClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/k;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_k_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onCollect(IZ)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onDownload(IZ)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "NewsClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/k;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_k_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onDownload(IZ)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onExit()Z
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v0, "NewsClientWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/k;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_k_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onExit()Z

    move-result v0

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method public final onMediaCenterFocusChanged(Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "NewsClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/k;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_k_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onMediaCenterFocusChanged(Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method public final onNext()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/INewsClient;->onNext()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onNext()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onPause()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/INewsClient;->onPause()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onPause()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onPlay()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/INewsClient;->onPlay()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onPlay()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onPrevious()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/INewsClient;->onPrevious()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onPrevious()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onReplay()Z
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->a()Lcom/ecarx/eas/sdk/mediacenter/INewsClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v0, "NewsClientWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/k;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_k_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/k;->b()Lcom/ecarx/eas/sdk/mediacenter/NewsClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/NewsClient;->onReplay()Z

    move-result v0

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method
