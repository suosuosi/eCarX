.class public final Lcom/ecarx/eas/sdk/mediacenter/a/i$a;
.super Lcom/ecarx/eas/sdk/mediacenter/a/g;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/mediacenter/a/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field private a:Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;


# direct methods
.method public constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/a/i;Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/a/g;-><init>()V

    iput-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->a:Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_i$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final handleCtrlApp(I)Z
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->a:Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/a;

    invoke-direct {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/a;-><init>(I)V

    new-instance p1, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v0, v1, p1}, Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;->handleCtrlApp(Lcom/ecarx/eas/sdk/vr/common/MediaCtrlIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "handleCtrlApp error : "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_i$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1
.end method

.method public final handleCtrlMediaClient(II)Z
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->a:Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/a;

    invoke-direct {v1, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a/a;-><init>(II)V

    new-instance p1, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v0, v1, p1}, Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;->handleCtrlApp(Lcom/ecarx/eas/sdk/vr/common/MediaCtrlIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a()Ljava/lang/String;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "handleCtrlMediaClient error : "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_i$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1
.end method

.method public final handlePlayRadio(Lecarx/xsf/mediacenter/vr/QRadioResult;)Z
    .locals 3

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->a:Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/b;

    invoke-direct {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/b;-><init>(Lecarx/xsf/mediacenter/vr/QRadioResult;)V

    new-instance p1, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v0, v1, p1}, Lcom/ecarx/eas/sdk/vr/radio/RadioIntentHandling;->handleCtrlRadio(Lcom/ecarx/eas/sdk/vr/radio/ICtrlLocalRadioIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "handleCtrlRadio error : "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/i$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_i$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1
.end method
