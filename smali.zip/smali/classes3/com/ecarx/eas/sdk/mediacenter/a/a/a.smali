.class public final Lcom/ecarx/eas/sdk/mediacenter/a/a/a;
.super Lecarx/xsf/mediacenter/vr/channel/IVrChannelObserver$Stub;
.source ""


# direct methods
.method public constructor <init>(Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/vr/channel/IVrChannelObserver$Stub;-><init>()V

    return-void
.end method


# virtual methods
.method public final handleVrChannelSemantic(IILjava/lang/String;)V
    .locals 0

    return-void
.end method
