.class public final Lcom/ecarx/eas/sdk/mediacenter/control/c;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/mediacenter/control/c$a;
    }
.end annotation


# instance fields
.field private a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(B)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;
    .locals 3

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;-><init>()V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getAlbum()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setAlbum(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getAppIcon()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setAppIcon(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getAppName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setAppName(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getArtist()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setArtist(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setArtwork(Landroid/net/Uri;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isCollected()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setCollected(Z)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getCurrentLyricSentence()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setCurrentLyricSentence(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isDownloaded()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setDownloaded(Z)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getDuration()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setDuration(J)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLaunchIntent()Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setLaunchIntent(Landroid/app/PendingIntent;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLoopMode()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setLoopMode(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLyric()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setLyric(Landroid/net/Uri;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setLyricContent(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setMediaPath(Landroid/net/Uri;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getNextArtwork()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setNextArtwork(Landroid/net/Uri;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlaybackStatus()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setPlaybackStatus(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayingItemPositionInQueue()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setPlayingItemPositionInQueue(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPreviousArtwork()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setPreviousArtwork(Landroid/net/Uri;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setRadioFrequency(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getRadioMode()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setRadioMode(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setRadioStationName(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getSourceType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setSourceType(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isSupportCollect()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setSupportCollect(Z)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isSupportDownload()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setSupportDownload(Z)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setTitle(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getUuid()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setUuid(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setPlayingMediaListId(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayingMediaListType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setPlayingMediaListType(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getVip()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setVip(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayerIntent()Landroid/app/PendingIntent;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;->setPlayerIntent(Landroid/app/PendingIntent;)V

    return-object v0
.end method

.method public static a()Lcom/ecarx/eas/sdk/mediacenter/control/c;
    .locals 1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/control/c$a;->a()Lcom/ecarx/eas/sdk/mediacenter/control/c;

    move-result-object v0

    return-object v0
.end method

.method static a(Ljava/util/List;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;",
            ">;"
        }
    .end annotation

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    return-object p0

    :cond_1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/xsf/mediacenter/IMedia;

    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;

    invoke-direct {v2}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;-><init>()V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getAlbum()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setAlbum(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getAlbumIndex()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setAlbumIndex(I)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getArtist()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setArtist(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getArtwork()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setArtWork(Landroid/net/Uri;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getAuthor()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setAuthor(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getCategoryStr()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setCategoryStr(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getComposer()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setComposer(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getDescription()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setDescription(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getDuration()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setDuration(J)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getLyric()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setLyric(Landroid/net/Uri;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getLyricContent()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setLyricContent(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getMediaCp()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setMediaCp(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getMediaId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setMediaId(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getMediaPath()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setMediaPath(Landroid/net/Uri;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getPlayingItemPositionInQueue()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setPositionInQueue(I)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getRadioFrequency()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setRadioFrequency(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getRadioStationName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setRadioStationName(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getRating()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setRating(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getSourceType()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setSourceType(I)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getCategoryStr()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setSubCategoryStr(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getSubtitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setSubtitle(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getTargetType()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setTargetType(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setTitle(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getUuid()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setUuid(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getYear()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setYear(Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getVip()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setVip(I)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setPlayingMediaListId(Ljava/lang/String;)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListType()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setPlayingMediaListType(I)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getSupportCollect()I

    move-result v3

    invoke-virtual {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setSupportCollect(I)V

    invoke-virtual {v1}, Lecarx/xsf/mediacenter/IMedia;->getCollected()I

    move-result v1

    invoke-virtual {v2, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;->setCollected(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_2
    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a(Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;)Lcom/ecarx/eas/sdk/mediacenter/control/c;
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    return-object p0
.end method

.method public final getMediaContentTypeList(Ljava/lang/Object;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getMediaContentTypeList(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Ljava/util/List;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final getMediaList(Ljava/lang/Object;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getMediaList(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final getMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getMusicPlaybackInfo(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final getSourceType(Ljava/lang/Object;)I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, -0x1

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getSourceType(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)I

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final playCtlPlay(Ljava/lang/Object;ILjava/lang/String;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string p2, "Please setApiSvc first"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->playCtlPlay(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final playCtrlPause(Ljava/lang/Object;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->pause(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final playCtrlPause(Ljava/lang/Object;I)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string p2, "Please setApiSvc first"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->playCtrlPause(Lecarx/xsf/mediacenter/control/IMediaControllerToken;I)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final playCtrlPlay(Ljava/lang/Object;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->resume(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final playCtrlPlayByContent(Ljava/lang/Object;ILjava/lang/String;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string p2, "Please setApiSvc first"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->playCtrlPlayByContent(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final playCtrlPlayByMediaID(Ljava/lang/Object;ILjava/lang/String;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string p2, "Please setApiSvc first"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->play(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final register(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string p2, "Please setApiSvc first"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/control/d;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/d;-><init>(Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->register(Ljava/lang/String;Lecarx/xsf/mediacenter/control/IMediaController;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final requestControl(Ljava/lang/Object;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->requestControl(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final unregister(Ljava/lang/Object;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControllerAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_c_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->unregister(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method
