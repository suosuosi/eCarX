.class public final Lcom/ecarx/eas/sdk/mediacenter/a/j$a;
.super Lcom/ecarx/eas/sdk/mediacenter/a/c;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/mediacenter/a/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private a:Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;


# direct methods
.method public constructor <init>(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/a/c;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->a:Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final handleCtrlApp(I)Z
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->a:Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/a;

    invoke-direct {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/a;-><init>(I)V

    new-instance p1, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v0, v1, p1}, Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;->handleCtrlApp(Lcom/ecarx/eas/sdk/vr/common/MediaCtrlIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "handleCtrlMedia error : "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VrMusicCtrlAPIImpl"

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1
.end method

.method public final handleCtrlMediaClient(II)Z
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->a:Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/a;

    invoke-direct {v1, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a/a;-><init>(II)V

    new-instance p1, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v0, v1, p1}, Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;->handleCtrlApp(Lcom/ecarx/eas/sdk/vr/common/MediaCtrlIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "handleCtrlMedia error : "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "VrMusicCtrlAPIImpl"

    invoke-static {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1
.end method

.method public final handlePlayMusic(Lecarx/xsf/mediacenter/vr/QMusicResult;)Z
    .locals 5

    const/4 v0, 0x0

    const-string v1, "VrMusicCtrlAPIImpl"

    if-nez p1, :cond_0

    const-string p1, "handlePlayMedia QMusicResult is NULL!!"

    :goto_0
    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v0

    :cond_0
    :try_start_0
    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->a:Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;

    new-instance v3, Lcom/ecarx/eas/sdk/mediacenter/a/e;

    invoke-direct {v3, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/e;-><init>(Lecarx/xsf/mediacenter/vr/QMusicResult;)V

    new-instance v4, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {v4}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v2, v3, v4}, Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;->handlePlayMusic(Lcom/ecarx/eas/sdk/vr/music/MusicPlayIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "handlePlayMedia success : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lecarx/xsf/mediacenter/vr/QMusicResult;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "handlePlayMedia error : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_0
.end method

.method public final handleSearchMusic(Lecarx/xsf/mediacenter/vr/QMusicResult;)Z
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->a:Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/h;

    invoke-direct {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/h;-><init>(Lecarx/xsf/mediacenter/vr/QMusicResult;)V

    new-instance p1, Lcom/ecarx/eas/sdk/vr/common/Response;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/vr/common/Response;-><init>()V

    invoke-virtual {v0, v1, p1}, Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;->handleSearchMusic(Lcom/ecarx/eas/sdk/vr/music/MusicSearchIntent;Lcom/ecarx/eas/sdk/vr/common/IResponse;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    move-exception p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "handleSearchMedia error : "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "VrMusicCtrlAPIImpl"

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j$a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1
.end method
