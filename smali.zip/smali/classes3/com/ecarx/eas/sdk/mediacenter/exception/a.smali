.class public Lcom/ecarx/eas/sdk/mediacenter/exception/a;
.super Lcom/ecarx/eas/sdk/mediacenter/exception/MediaCenterException;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 1

    const-string v0, "media center no connected!"

    invoke-direct {p0, v0}, Lcom/ecarx/eas/sdk/mediacenter/exception/MediaCenterException;-><init>(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/MediaCenterException;-><init>(Ljava/lang/String;)V

    return-void
.end method
