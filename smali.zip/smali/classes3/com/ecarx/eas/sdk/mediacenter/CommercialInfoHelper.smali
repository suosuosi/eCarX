.class public Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static TAG:Ljava/lang/String; = "CommercialInfoHelper"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$002(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static changeIMediaLists2Ex(Lecarx/xsf/mediacenter/IMediaLists;)Lecarx/eas/xsf/mediacenter/IMediaListsEx;
    .locals 1

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaLists2JsonStr(Lecarx/xsf/mediacenter/IMediaLists;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getPendingIntentsByIMediaLists(Lecarx/xsf/mediacenter/IMediaLists;)Ljava/util/List;

    move-result-object p0

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaListsExByJson(Ljava/lang/String;Ljava/util/List;)Lecarx/eas/xsf/mediacenter/IMediaListsEx;

    move-result-object p0

    return-object p0
.end method

.method public static convertContentInfo(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IContent;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;",
            ">;"
        }
    .end annotation

    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/xsf/mediacenter/IContent;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getContentInfo(Lecarx/xsf/mediacenter/IContent;)Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static convertIMediaList2Json(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMediaList;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "convertIMediaLists"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/xsf/mediacenter/IMediaList;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaLists2Json(Lecarx/xsf/mediacenter/IMediaList;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static convertIMediaListEx2Json(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/eas/xsf/mediacenter/IMediaListEx;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "convertIMediaLists"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/eas/xsf/mediacenter/IMediaListEx;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaListsEx2Json(Lecarx/eas/xsf/mediacenter/IMediaListEx;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static convertIMediaLists(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;",
            ">;)",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMediaList;",
            ">;"
        }
    .end annotation

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "convertIMediaLists"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaList(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)Lecarx/xsf/mediacenter/IMediaList;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static convertIMediaLists2Json(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "convertIMediaLists"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaList2Json(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static convertMediaListInfos(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMediaList;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;",
            ">;"
        }
    .end annotation

    :try_start_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/xsf/mediacenter/IMediaList;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaListInfo(Lecarx/xsf/mediacenter/IMediaList;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static convertToIContent(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;",
            ">;)",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IContent;",
            ">;"
        }
    .end annotation

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "convertToIContent"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIContent(Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;)Lecarx/xsf/mediacenter/IContent;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_0
    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getContentInfo(Lecarx/xsf/mediacenter/IContent;)Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;
    .locals 2

    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;-><init>()V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IContent;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->setId(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IContent;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->setTitle(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IContent;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->setPendingIntent(Landroid/app/PendingIntent;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IContent;->getBackground()Landroid/net/Uri;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->setBackground(Landroid/net/Uri;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIContent(Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;)Lecarx/xsf/mediacenter/IContent;
    .locals 4

    :try_start_0
    new-instance v0, Lecarx/xsf/mediacenter/IContent;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/IContent;-><init>()V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IContent;->setId(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IContent;->setTitle(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IContent;->setPendingIntent(Landroid/app/PendingIntent;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getBackground()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IContent;->setBackground(Landroid/net/Uri;)V

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "IContent: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IContent;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ", ContentInfo: id = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " title = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ", pendingIntent = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, ", url = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;->getBackground()Landroid/net/Uri;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIMedia2Json(Lecarx/xsf/mediacenter/IMedia;)Lorg/json/JSONObject;
    .locals 4

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v1, "uuid"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getUuid()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "title"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artist"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getArtist()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "album"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getAlbum()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "duration"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getDuration()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string v1, "positionInQueue"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingItemPositionInQueue()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "sourceType"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getSourceType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "mediaPath"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getMediaPath()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "lyricContent"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getLyricContent()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "lyric"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getLyric()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artWork"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getArtwork()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "radioFrequency"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getRadioFrequency()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "radioStationName"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getRadioStationName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "playingMediaListId"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "playingMediaListType"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "vip"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getVip()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "supportCollect"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getSupportCollect()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "collected"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getCollected()I

    move-result p0

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Lorg/json/JSONException;->printStackTrace()V

    :goto_0
    return-object v0
.end method

.method public static getIMediaBeanList2Json(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "getIMediaBeanList2Json"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p0, :cond_1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/xsf/mediacenter/IMedia;

    if-eqz v1, :cond_0

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMedia2Json(Lecarx/xsf/mediacenter/IMedia;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static getIMediaBeanListEx2Json(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/eas/xsf/mediacenter/IMediaEx;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "getIMediaBeanList2Json"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p0, :cond_1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/eas/xsf/mediacenter/IMediaEx;

    if-eqz v1, :cond_0

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaEx2Json(Lecarx/eas/xsf/mediacenter/IMediaEx;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static getIMediaEx2Json(Lecarx/eas/xsf/mediacenter/IMediaEx;)Lorg/json/JSONObject;
    .locals 4

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v1, "uuid"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getUuid()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "title"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artist"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getArtist()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "album"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getAlbum()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "duration"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getDuration()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string v1, "positionInQueue"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getPlayingItemPositionInQueue()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "sourceType"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getSourceType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "mediaPath"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getMediaPath()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "lyricContent"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getLyricContent()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "lyric"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getLyric()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artWork"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getArtwork()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "radioFrequency"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getRadioFrequency()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "radioStationName"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getRadioStationName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "playingMediaListId"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "playingMediaListType"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getPlayingMediaListType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "vip"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getVip()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "supportCollect"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getSupportCollect()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "collected"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaEx;->getCollected()I

    move-result p0

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Lorg/json/JSONException;->printStackTrace()V

    :goto_0
    return-object v0
.end method

.method public static getIMediaList(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)Lecarx/xsf/mediacenter/IMediaList;
    .locals 4

    :try_start_0
    new-instance v0, Lecarx/xsf/mediacenter/IMediaList;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/IMediaList;-><init>()V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMediaList;->setTitle(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMediaList;->setMediaListId(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListType()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMediaList;->setMediaListType(I)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getSourceType()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMediaList;->setSourceType(I)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaList()Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMediaList;->setMediaList(Ljava/util/List;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMediaList;->setPendingIntent(Landroid/app/PendingIntent;)V
    :try_end_1
    .catch Ljava/lang/NoSuchMethodError; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    move-exception v1

    :try_start_2
    invoke-virtual {v1}, Ljava/lang/NoSuchMethodError;->printStackTrace()V

    :goto_0
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "MediaListInfo: title = "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " , sourceType = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getSourceType()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " listId = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "list = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaList()Ljava/util/List;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " , "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    return-object v0

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static getIMediaList2Json(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)Lorg/json/JSONObject;
    .locals 4

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "title"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "mediaListId"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artwork"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "mediaListType"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "sourceType"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getSourceType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "mediaList"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaList()Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lcom/ecarx/eas/sdk/mediacenter/d;->c(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "MediaListInfo: title = "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " , sourceType = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getSourceType()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " listId = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "list = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaList()Ljava/util/List;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " , "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIMediaLists(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lecarx/xsf/mediacenter/IMediaLists;
    .locals 3

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v2, "getIMediaLists"

    invoke-static {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;->getMediaListsInfo()Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertIMediaLists(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    new-instance v1, Lecarx/xsf/mediacenter/IMediaLists;

    invoke-direct {v1}, Lecarx/xsf/mediacenter/IMediaLists;-><init>()V

    invoke-virtual {v1, p0}, Lecarx/xsf/mediacenter/IMediaLists;->setMediaLists(Ljava/util/List;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v0
.end method

.method private static getIMediaLists2Json(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lorg/json/JSONObject;
    .locals 3

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v2, "getIMediaLists"

    invoke-static {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;->getMediaListsInfo()Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertIMediaLists2Json(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object p0

    const-string v2, "mediaLists"

    invoke-virtual {v1, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v0
.end method

.method public static getIMediaLists2Json(Lecarx/xsf/mediacenter/IMediaList;)Lorg/json/JSONObject;
    .locals 4

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "title"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "mediaListId"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaListId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "mediaListType"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaListType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "sourceType"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getSourceType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "mediaList"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaList()Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaBeanList2Json(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "pendingIntent"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v2

    invoke-static {v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->object2String(Landroid/os/Parcelable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "MediaListInfo: title = "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " , sourceType = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getSourceType()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " listId = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaListId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "list = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaList()Ljava/util/List;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " , "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static getIMediaLists2Json(Lecarx/xsf/mediacenter/IMediaLists;)Lorg/json/JSONObject;
    .locals 2

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "getIMediaLists"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaLists;->getMediaLists()Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertIMediaList2Json(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object p0

    const-string v1, "mediaLists"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static getIMediaLists2JsonStr(Lecarx/xsf/mediacenter/IMediaLists;)Ljava/lang/String;
    .locals 0

    if-eqz p0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaLists2Json(Lecarx/xsf/mediacenter/IMediaLists;)Lorg/json/JSONObject;

    move-result-object p0

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIMediaListsByJson(Ljava/lang/String;)Lecarx/xsf/mediacenter/IMediaLists;
    .locals 14

    const-string v0, "sourceType"

    const-string v1, "title"

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v2, Lecarx/xsf/mediacenter/IMediaLists;

    invoke-direct {v2}, Lecarx/xsf/mediacenter/IMediaLists;-><init>()V

    :try_start_0
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "mediaLists"

    invoke-virtual {v3, p0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    if-eqz p0, :cond_5

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v6

    if-ge v5, v6, :cond_4

    invoke-virtual {p0, v5}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    if-eqz v6, :cond_3

    new-instance v7, Lecarx/xsf/mediacenter/IMediaList;

    invoke-direct {v7}, Lecarx/xsf/mediacenter/IMediaList;-><init>()V

    invoke-virtual {v6, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lecarx/xsf/mediacenter/IMediaList;->setTitle(Ljava/lang/String;)V

    const-string v8, "mediaListId"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lecarx/xsf/mediacenter/IMediaList;->setMediaListId(Ljava/lang/String;)V

    const-string v8, "mediaListType"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Lecarx/xsf/mediacenter/IMediaList;->setMediaListType(I)V

    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Lecarx/xsf/mediacenter/IMediaList;->setSourceType(I)V

    const-string v8, "mediaList"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    if-eqz v6, :cond_2

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    move v9, v4

    :goto_1
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-ge v9, v10, :cond_1

    new-instance v10, Lecarx/xsf/mediacenter/IMedia;

    invoke-direct {v10}, Lecarx/xsf/mediacenter/IMedia;-><init>()V

    invoke-virtual {v6, v9}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    const-string v12, "uuid"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setUuid(Ljava/lang/String;)V

    invoke-virtual {v11, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setTitle(Ljava/lang/String;)V

    const-string v12, "artist"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setArtist(Ljava/lang/String;)V

    const-string v12, "album"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setAlbum(Ljava/lang/String;)V

    const-string v12, "duration"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v12

    invoke-virtual {v10, v12, v13}, Lecarx/xsf/mediacenter/IMedia;->setDuration(J)V

    const-string v12, "positionInQueue"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setPositionInQueue(I)V

    invoke-virtual {v11, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setSourceType(I)V

    const-string v12, "mediaPath"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setMediaPath(Landroid/net/Uri;)V

    const-string v12, "lyricContent"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setLyricContent(Ljava/lang/String;)V

    const-string v12, "lyric"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setLyric(Landroid/net/Uri;)V

    const-string v12, "artWork"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setArtWork(Landroid/net/Uri;)V

    const-string v12, "radioFrequency"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setRadioFrequency(Ljava/lang/String;)V

    const-string v12, "radioStationName"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setRadioStationName(Ljava/lang/String;)V

    const-string v12, "playingMediaListId"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setPlayingMediaListId(Ljava/lang/String;)V

    const-string v12, "playingMediaListType"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setPlayingMediaListType(I)V

    const-string v12, "vip"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setVip(I)V

    const-string v12, "supportCollect"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/xsf/mediacenter/IMedia;->setSupportCollect(I)V

    const-string v12, "collected"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Lecarx/xsf/mediacenter/IMedia;->setCollected(I)V

    invoke-interface {v8, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_1

    :cond_1
    invoke-virtual {v7, v8}, Lecarx/xsf/mediacenter/IMediaList;->setMediaList(Ljava/util/List;)V

    :cond_2
    invoke-interface {v3, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_0

    :cond_4
    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMediaLists;->setMediaLists(Ljava/util/List;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Lorg/json/JSONException;->printStackTrace()V

    :cond_5
    :goto_2
    return-object v2
.end method

.method private static getIMediaListsEx2Json(Lecarx/eas/xsf/mediacenter/IMediaListEx;)Lorg/json/JSONObject;
    .locals 4

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "title"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "mediaListId"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getMediaListId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artwork"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getArtwork()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "mediaListType"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getMediaListType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "sourceType"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getSourceType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "mediaList"

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getMediaList()Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaBeanListEx2Json(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "MediaListInfo: title = "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " , sourceType = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getSourceType()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " listId = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getMediaListId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "list = "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->getMediaList()Ljava/util/List;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " , "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static getIMediaListsEx2Json(Lecarx/eas/xsf/mediacenter/IMediaListsEx;)Lorg/json/JSONObject;
    .locals 2

    :try_start_0
    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v1, "getIMediaLists"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {p0}, Lecarx/eas/xsf/mediacenter/IMediaListsEx;->getMediaLists()Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertIMediaListEx2Json(Ljava/util/List;)Lorg/json/JSONArray;

    move-result-object p0

    const-string v1, "mediaLists"

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIMediaListsEx2JsonStr(Lecarx/eas/xsf/mediacenter/IMediaListsEx;)Ljava/lang/String;
    .locals 0

    if-eqz p0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaListsEx2Json(Lecarx/eas/xsf/mediacenter/IMediaListsEx;)Lorg/json/JSONObject;

    move-result-object p0

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIMediaListsExByIExContent(Lcom/ecarx/eas/xsf/mediacenter/IExContent;)Lecarx/eas/xsf/mediacenter/IMediaListsEx;
    .locals 1

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;->getData()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;->getPendingIntents()Ljava/util/List;

    move-result-object p0

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaListsExByJson(Ljava/lang/String;Ljava/util/List;)Lecarx/eas/xsf/mediacenter/IMediaListsEx;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getIMediaListsExByJson(Ljava/lang/String;Ljava/util/List;)Lecarx/eas/xsf/mediacenter/IMediaListsEx;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Landroid/app/PendingIntent;",
            ">;)",
            "Lecarx/eas/xsf/mediacenter/IMediaListsEx;"
        }
    .end annotation

    const-string v0, "sourceType"

    const-string v1, "title"

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v2, Lecarx/eas/xsf/mediacenter/IMediaListsEx;

    invoke-direct {v2}, Lecarx/eas/xsf/mediacenter/IMediaListsEx;-><init>()V

    :try_start_0
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "mediaLists"

    invoke-virtual {v3, p0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    if-eqz p0, :cond_6

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v6

    if-ge v5, v6, :cond_5

    invoke-virtual {p0, v5}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    if-eqz v6, :cond_4

    new-instance v7, Lecarx/eas/xsf/mediacenter/IMediaListEx;

    invoke-direct {v7}, Lecarx/eas/xsf/mediacenter/IMediaListEx;-><init>()V

    invoke-virtual {v6, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setTitle(Ljava/lang/String;)V

    const-string v8, "mediaListId"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setMediaListId(Ljava/lang/String;)V

    const-string v8, "artwork"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v8

    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setArtwork(Landroid/net/Uri;)V

    const-string v8, "mediaListType"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setMediaListType(I)V

    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setSourceType(I)V

    if-eqz p1, :cond_1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v8

    if-le v8, v5, :cond_1

    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/app/PendingIntent;

    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setPendingIntent(Landroid/app/PendingIntent;)V

    :cond_1
    const-string v8, "mediaList"

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    if-eqz v6, :cond_3

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    move v9, v4

    :goto_1
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-ge v9, v10, :cond_2

    new-instance v10, Lecarx/eas/xsf/mediacenter/IMediaEx;

    invoke-direct {v10}, Lecarx/eas/xsf/mediacenter/IMediaEx;-><init>()V

    invoke-virtual {v6, v9}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    const-string v12, "uuid"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setUuid(Ljava/lang/String;)V

    invoke-virtual {v11, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setTitle(Ljava/lang/String;)V

    const-string v12, "artist"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setArtist(Ljava/lang/String;)V

    const-string v12, "album"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setAlbum(Ljava/lang/String;)V

    const-string v12, "duration"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v12

    invoke-virtual {v10, v12, v13}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setDuration(J)V

    const-string v12, "positionInQueue"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setPositionInQueue(I)V

    invoke-virtual {v11, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setSourceType(I)V

    const-string v12, "mediaPath"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setMediaPath(Landroid/net/Uri;)V

    const-string v12, "lyricContent"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setLyricContent(Ljava/lang/String;)V

    const-string v12, "lyric"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setLyric(Landroid/net/Uri;)V

    const-string v12, "artWork"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setArtWork(Landroid/net/Uri;)V

    const-string v12, "radioFrequency"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setRadioFrequency(Ljava/lang/String;)V

    const-string v12, "radioStationName"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setRadioStationName(Ljava/lang/String;)V

    const-string v12, "playingMediaListId"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setPlayingMediaListId(Ljava/lang/String;)V

    const-string v12, "playingMediaListType"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setPlayingMediaListType(I)V

    const-string v12, "vip"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setVip(I)V

    const-string v12, "supportCollect"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v10, v12}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setSupportCollect(I)V

    const-string v12, "collected"

    invoke-virtual {v11, v12}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Lecarx/eas/xsf/mediacenter/IMediaEx;->setCollected(I)V

    invoke-interface {v8, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_1

    :cond_2
    invoke-virtual {v7, v8}, Lecarx/eas/xsf/mediacenter/IMediaListEx;->setMediaList(Ljava/util/List;)V

    :cond_3
    invoke-interface {v3, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_0

    :cond_5
    invoke-virtual {v2, v3}, Lecarx/eas/xsf/mediacenter/IMediaListsEx;->setMediaLists(Ljava/util/List;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Lorg/json/JSONException;->printStackTrace()V

    :cond_6
    :goto_2
    return-object v2
.end method

.method public static getMediaErrorBeanIExContent(Lecarx/xsf/mediacenter/session/MediaErrorBean;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;
    .locals 2

    if-eqz p0, :cond_0

    new-instance v0, Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    invoke-direct {v0}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;-><init>()V

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaErrorBeanJsonStr(Lecarx/xsf/mediacenter/session/MediaErrorBean;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;->setData(Ljava/lang/String;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object p0

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;->setPendingIntents(Ljava/util/List;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private static getMediaErrorBeanJson(Lecarx/xsf/mediacenter/session/MediaErrorBean;)Lorg/json/JSONObject;
    .locals 4

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    const-string v2, "getMediaErrorBeanJson"

    invoke-static {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "packageName"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "errorState"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->getErrorState()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "sourceType"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->getSourceType()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v2, "errorMsg"

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->getErrorMsg()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v0
.end method

.method public static getMediaErrorBeanJsonStr(Lecarx/xsf/mediacenter/session/MediaErrorBean;)Ljava/lang/String;
    .locals 0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaErrorBeanJson(Lecarx/xsf/mediacenter/session/MediaErrorBean;)Lorg/json/JSONObject;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getMediaListInfo(Lecarx/xsf/mediacenter/IMediaList;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 2

    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/i;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/i;-><init>()V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/i;->a(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaListId()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/ecarx/eas/sdk/mediacenter/i;->a:Ljava/lang/String;

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaListType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/i;->b(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getSourceType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/i;->a(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getMediaList()Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->d(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/i;->a(Ljava/util/List;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaList;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/i;->a(Landroid/app/PendingIntent;)V
    :try_end_1
    .catch Ljava/lang/NoSuchMethodError; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    move-exception p0

    :try_start_2
    invoke-virtual {p0}, Ljava/lang/NoSuchMethodError;->printStackTrace()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :goto_0
    return-object v0

    :catch_1
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getMediaListsInfo(Lecarx/xsf/mediacenter/IMediaLists;)Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;
    .locals 1

    :try_start_0
    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaLists;->getMediaLists()Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertMediaListInfos(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;-><init>()V

    invoke-virtual {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;->setMediaListsInfo(Ljava/util/List;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getMediaListsInfo2IExContent(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;
    .locals 4

    if-eqz p0, :cond_1

    new-instance v0, Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    invoke-direct {v0}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;-><init>()V

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaListsInfo2JsonStr(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;->setData(Ljava/lang/String;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;->getMediaListsInfo()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_0

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;->getMediaListsInfo()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    invoke-virtual {v3}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Lcom/ecarx/eas/xsf/mediacenter/IExContent;->setPendingIntents(Ljava/util/List;)V

    return-object v0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getMediaListsInfo2JsonStr(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Ljava/lang/String;
    .locals 0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaLists2Json(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lorg/json/JSONObject;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private static getPendingIntentsByIMediaLists(Lecarx/xsf/mediacenter/IMediaLists;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/IMediaLists;",
            ")",
            "Ljava/util/List<",
            "Landroid/app/PendingIntent;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_0
    :try_start_0
    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaLists;->getMediaLists()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMediaLists;->getMediaLists()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lecarx/xsf/mediacenter/IMediaList;

    invoke-virtual {v2}, Lecarx/xsf/mediacenter/IMediaList;->getPendingIntent()Landroid/app/PendingIntent;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0

    :catchall_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static getProgress(Ljava/lang/String;)J
    .locals 2

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "progress"

    invoke-virtual {v0, p0}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-wide v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const-wide/16 v0, -0x1

    return-wide v0
.end method

.method public static getTTSResultJson(Ljava/lang/String;)I
    .locals 1

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "status"

    invoke-virtual {v0, p0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    const/4 p0, -0x1

    return p0
.end method

.method public static getVrChannelInfo2Json(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lorg/json/JSONObject;
    .locals 5

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "VrChannelInfo  is null "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "mediaPackageName"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getMediaPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "mediaVersion"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getMediaVersion()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "mediaDescription"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getMediaDescription()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "channelDataType"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getChannelDataType()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    sget-object v2, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "MediaListInfo: mediaPackageName = "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getMediaPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " , mediaVersion = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getMediaVersion()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " mediaDescription = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getMediaDescription()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "channelDataType = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->getChannelDataType()I

    move-result p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " , "

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception p0

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->TAG:Ljava/lang/String;

    invoke-static {p0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_CommercialInfoHelper_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v0
.end method

.method private static object2String(Landroid/os/Parcelable;)Ljava/lang/String;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-virtual {v0}, Landroid/os/Parcel;->marshall()[B

    move-result-object p0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    invoke-static {p0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static unmarshall([B)Landroid/os/Parcel;
    .locals 3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    array-length v1, p0

    const/4 v2, 0x0

    invoke-virtual {v0, p0, v2, v1}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    return-object v0
.end method

.method public static unmarshall(Ljava/lang/String;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "Landroid/os/Parcelable$Creator<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    invoke-static {p0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->unmarshall([B)Landroid/os/Parcel;

    move-result-object p0

    :try_start_0
    invoke-interface {p1, p0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Landroid/os/Parcel;->recycle()V

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p0}, Landroid/os/Parcel;->recycle()V

    throw p1
.end method
