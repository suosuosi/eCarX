.class public final Lcom/ecarx/eas/sdk/mediacenter/control/b;
.super Lecarx/xsf/mediacenter/control/IMediaControlClient$Stub;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/control/IMediaControlClient$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a:Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    return-void
.end method

.method private a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a:Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final getMediaContentTypeList()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->getMediaContentTypeList()Ljava/util/List;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final onControlledChanged(Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onControlledChanged(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public final onPause(I)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onPause(I)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onPauseNow()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onPauseNow()Z

    move-result v0

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public final onPlay(ILjava/lang/String;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onPlay(ILjava/lang/String;)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onPlayByContent(ILjava/lang/String;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onPlayByContent(ILjava/lang/String;)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onPlayByMediaId(ILjava/lang/String;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onPlayByMediaId(ILjava/lang/String;)Z

    move-result p1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onResumeNow()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/b;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;->onResumeNow()Z

    move-result v0

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method
