.class public Lcom/ecarx/eas/sdk/mediacenter/a/f;
.super Lcom/ecarx/eas/sdk/vr/news/PlayNewsIntent;
.source ""


# static fields
.field private static final a:Ljava/lang/String; = "f"


# instance fields
.field private b:Lecarx/xsf/mediacenter/vr/QNewsResult;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(Lecarx/xsf/mediacenter/vr/QNewsResult;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/news/PlayNewsIntent;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/f;->b:Lecarx/xsf/mediacenter/vr/QNewsResult;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public getNewsCategory()Ljava/lang/String;
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/f;->b:Lecarx/xsf/mediacenter/vr/QNewsResult;

    iget-object v0, v0, Lecarx/xsf/mediacenter/vr/QNewsResult;->newsCategory:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/a/f;->a:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, " getNewsCategory error : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a/f;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0
.end method

.method public getNewsId()Ljava/lang/String;
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/f;->b:Lecarx/xsf/mediacenter/vr/QNewsResult;

    iget-object v0, v0, Lecarx/xsf/mediacenter/vr/QNewsResult;->newsId:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/a/f;->a:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, " getNewsId error : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a/f;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0
.end method

.method public getRawText()Ljava/lang/String;
    .locals 4

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/f;->b:Lecarx/xsf/mediacenter/vr/QNewsResult;

    iget-object v0, v0, Lecarx/xsf/mediacenter/vr/QNewsResult;->rawText:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/a/f;->a:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, " getRawText error : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a/f;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_f_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0
.end method
