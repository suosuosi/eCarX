.class final Lcom/ecarx/eas/sdk/mediacenter/a$3$1;
.super Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ecarx/eas/sdk/mediacenter/a$3;->getMediaList()Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lecarx/xsf/mediacenter/IMedia;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/a$3;Lecarx/xsf/mediacenter/IMedia;)V
    .locals 0

    iput-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public final getAlbum()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getAlbum()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getAlbumIndex()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getAlbumIndex()I

    move-result v0

    return v0
.end method

.method public final getArtist()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getArtist()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getArtwork()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final getAuthor()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getAuthor()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getCategoryStr()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getCategoryStr()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getCollected()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getCollected()I

    move-result v0

    return v0
.end method

.method public final getComposer()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getComposer()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getDescription()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getDescription()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getDuration()J
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getDuration()J

    move-result-wide v0

    return-wide v0
.end method

.method public final getLyric()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getLyric()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final getLyricContent()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getLyricContent()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getMediaCp()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getMediaCp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getMediaId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getMediaId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getMediaPath()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getMediaPath()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public final getPlayingItemPositionInQueue()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingItemPositionInQueue()I

    move-result v0

    return v0
.end method

.method public final getPlayingMediaListId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getPlayingMediaListType()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListType()I

    move-result v0

    return v0
.end method

.method public final getRadioFrequency()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getRadioFrequency()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getRadioStationName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getRadioStationName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getRating()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getRating()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getSourceType()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getSourceType()I

    move-result v0

    return v0
.end method

.method public final getSubCategoryStr()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getSubCategoryStr()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getSubtitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getSubtitle()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getSupportCollect()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getSupportCollect()I

    move-result v0

    return v0
.end method

.method public final getTargetType()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getTargetType()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getUuid()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getUuid()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getVip()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getVip()I

    move-result v0

    return v0
.end method

.method public final getYear()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a$3$1;->a:Lecarx/xsf/mediacenter/IMedia;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getYear()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
