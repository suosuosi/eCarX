.class final Lcom/ecarx/eas/sdk/mediacenter/control/a$a;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/sdk/mediacenter/control/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# static fields
.field private static final a:Lcom/ecarx/eas/sdk/mediacenter/control/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/control/a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/control/a;-><init>(B)V

    sput-object v0, Lcom/ecarx/eas/sdk/mediacenter/control/a$a;->a:Lcom/ecarx/eas/sdk/mediacenter/control/a;

    return-void
.end method

.method static synthetic a()Lcom/ecarx/eas/sdk/mediacenter/control/a;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/control/a$a;->a:Lcom/ecarx/eas/sdk/mediacenter/control/a;

    return-object v0
.end method
