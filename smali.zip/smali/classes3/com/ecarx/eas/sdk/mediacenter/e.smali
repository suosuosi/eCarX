.class public final Lcom/ecarx/eas/sdk/mediacenter/e;
.super Lcom/ecarx/eas/framework/sdk/common/internal/IApi;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/IApi<",
        "Lecarx/xsf/mediacenter/IMediaCenterSvc;",
        ">;",
        "Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;"
    }
.end annotation


# static fields
.field private static g:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/mediacenter/e;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Landroid/content/Context;

.field private b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

.field private c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

.field private d:Lcom/ecarx/eas/sdk/mediacenter/a/i;

.field private e:Lcom/ecarx/eas/sdk/mediacenter/a/j;

.field private f:Lcom/ecarx/eas/sdk/mediacenter/a/k;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/e$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/e$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/mediacenter/e;->g:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object p0

    return-object p0
.end method

.method private a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/e$3;

    invoke-direct {v0, p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e$3;-><init>(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)V

    return-object v0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object p0

    return-object p0
.end method

.method private a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/e$4;

    invoke-direct {v0, p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e$4;-><init>(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V

    return-object v0
.end method

.method public static a()Lcom/ecarx/eas/sdk/mediacenter/e;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/e;->g:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/mediacenter/e;

    return-object v0
.end method

.method private a(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)V

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerMusic(Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method private a(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/k;

    invoke-direct {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/k;-><init>(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)V

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerNews(Lecarx/xsf/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method private a(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/p;

    invoke-direct {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/p;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)V

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerVideo(Lecarx/xsf/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method private static a(Landroid/content/Intent;)Ljava/lang/String;
    .locals 5

    const/4 v0, 0x0

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v2, "state_action"

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "state_package"

    invoke-virtual {p0}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {p0, v3}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_2
    :goto_1
    return-object v0
.end method

.method private static a(Ljava/lang/Object;)V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "verifyToken: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "MediaCenterAPIImpl"

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    instance-of p0, p0, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final abandonPlayFocus(Ljava/lang/Object;)V
    .locals 0

    return-void
.end method

.method public final asyncSendVrChannelResult(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Ljava/lang/String;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->wrap(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;

    move-result-object p2

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->asyncSendVrChannelResult(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "asyncSendVrChannelResult, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final cancelSupportCollectTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelSupportCollectTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final cancelSupportDownloadTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelSupportDownloadTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final cancelVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->wrap(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelVrChannelCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "cancelVrChannelCapability, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final cancelVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final connect(Ljava/lang/Object;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public final declareMediaCenterCapability(Ljava/lang/Object;[I)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareMediaCenterCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final declareSupportCollectTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareSupportCollectTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final declareSupportDownloadTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareSupportDownloadTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final declareVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->wrap(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;

    move-result-object p2

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/a/a;

    invoke-direct {v1, p3}, Lcom/ecarx/eas/sdk/mediacenter/a/a/a;-><init>(Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)V

    invoke-interface {v0, p1, p2, v1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareVrChannelCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;Lecarx/xsf/mediacenter/vr/channel/IVrChannelObserver;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "declareVrChannelCapability, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final declareVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final getECarXAPIBaseVERSION_INT()I
    .locals 1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/n;->a()I

    move-result v0

    return v0
.end method

.method public final getMediaControlClientApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPIImpl"

    const-string v2, "unbind media center service"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a()Lcom/ecarx/eas/sdk/mediacenter/control/a;

    move-result-object v0

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-interface {v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->getMediaControlClientApi()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a(Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;)Lcom/ecarx/eas/sdk/mediacenter/control/a;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v1
.end method

.method public final getMediaControllerApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPIImpl"

    const-string v2, "unbind media center service"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a()Lcom/ecarx/eas/sdk/mediacenter/control/c;

    move-result-object v0

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-interface {v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->getMediaControllerApi()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a(Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;)Lcom/ecarx/eas/sdk/mediacenter/control/c;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v1
.end method

.method public final getRecoveryMediaList(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->getRecoveryMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "getRecoveryMediaList, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final getRecoveryMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->getRecoveryMusicPlaybackInfo(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "getRecoveryMusicPlaybackInfo, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final getVrLocalRadioApi()Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->d:Lcom/ecarx/eas/sdk/mediacenter/a/i;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getVrMusicApi()Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->e:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getVrNewsApi()Lcom/ecarx/eas/sdk/vr/news/VrNewsCtrlAPI;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->f:Lcom/ecarx/eas/sdk/mediacenter/a/k;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final synthetic init(Landroid/os/IInterface;)V
    .locals 1

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-super {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->a:Landroid/content/Context;

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz p1, :cond_0

    :try_start_0
    invoke-interface {p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->getStateBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/i;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->d:Lcom/ecarx/eas/sdk/mediacenter/a/i;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/j;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->e:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/a/k;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/k;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->f:Lcom/ecarx/eas/sdk/mediacenter/a/k;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/k;->a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V

    const-string p1, "MediaCenterAPIImpl"

    const-string v0, " InitialImpl OK"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void
.end method

.method public final onMusicRecoveryComplete(Ljava/lang/Object;)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->onMusicRecoveryComplete(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "registerMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final queryCurrentFocusClient(Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string v1, "MediaCenterAPIImpl"

    if-eqz v0, :cond_0

    :try_start_0
    const-string v0, "queryCurrentFocusClient"

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->queryCurrentFocusClient(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const-string p1, "queryCurrentFocusClient, but unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final register(Landroid/os/Binder;)Ljava/lang/Object;
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Not implementation"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final synthetic registerMusic(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Ljava/lang/Object;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1

    return-object p1
.end method

.method public final registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    const-string v2, "MediaCenterAPIImpl"

    if-nez v0, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "svc: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInMusic(Ljava/lang/String;Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;Ljava/lang/String;)Ljava/lang/Object;
    .locals 3

    iget-object p3, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v0, 0x0

    const-string v1, "MediaCenterAPIImpl"

    if-nez p3, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v0

    :cond_0
    :try_start_0
    new-instance p3, Ljava/lang/StringBuilder;

    const-string v2, "svc: "

    invoke-direct {p3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-static {v1, p3}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p3, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)V

    invoke-interface {p3, p1, v1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInMusic(Ljava/lang/String;Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v0
.end method

.method public final registerMusicRecoveryIntent(Ljava/lang/Object;ILandroid/content/Intent;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p3}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Landroid/content/Intent;)Ljava/lang/String;

    move-result-object p3

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->registerMusicRecoveryIntent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return p1

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "registerMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final registerMusicWithZoneId(ILjava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final synthetic registerNews(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Ljava/lang/Object;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1

    return-object p1
.end method

.method public final registerNews(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/k;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/k;-><init>(Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInNews(Ljava/lang/String;Lecarx/xsf/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method public final synthetic registerVideo(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Ljava/lang/Object;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1

    return-object p1
.end method

.method public final registerVideo(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/p;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/p;-><init>(Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInVideo(Ljava/lang/String;Lecarx/xsf/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method public final requestPlay(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->requestPlay(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final sendVrTtsActionResult(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final setMusicRecoveryCallback(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/e$2;

    invoke-direct {v1, p0, p2}, Lcom/ecarx/eas/sdk/mediacenter/e$2;-><init>(Lcom/ecarx/eas/sdk/mediacenter/e;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V

    invoke-interface {v0, p1, v1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->setMusicRecoveryCallback(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/staterecover/IMusicRecoveryListener;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "registerMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final unRegisterMusicRecoveryIntent(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->unRegisterMusicRecoveryIntent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return p1

    :cond_0
    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "unRegisterMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final unregister(Ljava/lang/Object;)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    const/4 v1, 0x1

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->unregister(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateCollectMsg(Ljava/lang/Object;IILjava/lang/String;ILjava/lang/String;)V
    .locals 9

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string v1, "MediaCenterAPIImpl"

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "updateCollectMsg type = "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "operation = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " uuid = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " resultCode = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " message = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    move-object v3, p1

    check-cast v3, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move v4, p2

    move v5, p3

    move-object v6, p4

    move v7, p5

    move-object v8, p6

    invoke-interface/range {v2 .. v8}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCollectMsgByUUID(Lecarx/xsf/mediacenter/IMediaCenterClientToken;IILjava/lang/String;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "updateCollectMsg, but unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final updateCollectMsg(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 3

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string v1, "MediaCenterAPIImpl"

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "updateCollectMsg resultCode = "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " message = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCollectMsg(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "updateCollectMsg, but unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final updateCurrentLyric(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentLyric(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateCurrentPlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)V"
        }
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p3}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object p3

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updatePlaylist(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/util/List;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateCurrentProgress(Ljava/lang/Object;J)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentProgress(Lecarx/xsf/mediacenter/IMediaCenterClientToken;J)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateCurrentRecommendInfo(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z
    .locals 3

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/o;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/o;-><init>(Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentRecommendInfo(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IRecommend;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateCurrentSourceType(Ljava/lang/Object;I)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentSourceType(Lecarx/xsf/mediacenter/IMediaCenterClientToken;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateErrorMsg(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateErrorMsg(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final updateErrorStateAndPendingIntent(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)V
    .locals 0

    return-void
.end method

.method public final updateMediaContent(Ljava/lang/Object;Ljava/util/List;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;",
            ">;)Z"
        }
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertToIContent(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaContent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/util/List;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return v1
.end method

.method public final updateMediaContentTypeList(Ljava/lang/Object;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaContentTypeList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final updateMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V
    .locals 5

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    move-object v1, p1

    check-cast v1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-virtual {p2}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getSourceType()I

    move-result v2

    invoke-virtual {p2}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListType()I

    move-result v3

    invoke-virtual {p2}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaList()Ljava/util/List;

    move-result-object v4

    invoke-static {v4}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v0, v1, v2, v3, v4}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;IILjava/util/List;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaList(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)Lecarx/xsf/mediacenter/IMediaList;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaPlayList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMediaList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final updateMediaSourceTypeList(Ljava/lang/Object;[I)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaSourceTypeList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_0
    const/4 p1, 0x1

    return p1
.end method

.method public final updateMultiMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z
    .locals 3

    const-string v0, "MediaCenterAPIImpl"

    const-string v1, "updateMultiMediaList"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return v2

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaLists(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lecarx/xsf/mediacenter/IMediaLists;

    move-result-object p2

    invoke-interface {v1, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMultiMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMediaLists;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return v2
.end method

.method public final updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)Z
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/m;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/m;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMusicPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/m;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/m;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMusicPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)Z
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/l;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/l;-><init>(Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateNewsPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/INewsPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/l;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/l;-><init>(Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateNewsPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/INewsPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updatePlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p3}, Lcom/ecarx/eas/sdk/mediacenter/d;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p3

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updatePlaylist(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/util/List;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)Z
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/q;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/q;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateVideoPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IVideoPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/e;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_e_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/q;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/q;-><init>(Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateVideoPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IVideoPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updateZoneId(Ljava/lang/Object;I)V
    .locals 0

    return-void
.end method
