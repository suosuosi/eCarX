.class final Lcom/ecarx/eas/sdk/mediacenter/g$2;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ecarx/eas/sdk/mediacenter/g;->init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/mediacenter/g;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/g;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g$2;->a:Lcom/ecarx/eas/sdk/mediacenter/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;Z)Z
    .locals 0

    if-eqz p4, :cond_0

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g$2;->a:Lcom/ecarx/eas/sdk/mediacenter/g;

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->a(Lcom/ecarx/eas/sdk/mediacenter/g;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g$2;->a:Lcom/ecarx/eas/sdk/mediacenter/g;

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/g;->a(Lcom/ecarx/eas/sdk/mediacenter/g;)Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-result-object p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z
    .locals 0

    if-eqz p3, :cond_0

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g$2;->a:Lcom/ecarx/eas/sdk/mediacenter/g;

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->a(Lcom/ecarx/eas/sdk/mediacenter/g;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g$2;->a:Lcom/ecarx/eas/sdk/mediacenter/g;

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/g;->a(Lcom/ecarx/eas/sdk/mediacenter/g;)Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-result-object p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method
