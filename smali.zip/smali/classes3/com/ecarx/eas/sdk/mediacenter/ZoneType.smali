.class public Lcom/ecarx/eas/sdk/mediacenter/ZoneType;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final CSD:I = 0x0

.field public static final PSD:I = 0x1

.field public static final ROW_2_CENTER:I = 0x3

.field public static final ROW_2_LEFT:I = 0x2

.field public static final ROW_2_RIGHT:I = 0x4

.field public static final ROW_3_CENTER:I = 0x6

.field public static final ROW_3_LEFT:I = 0x5

.field public static final ROW_3_RIGHT:I = 0x7


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
