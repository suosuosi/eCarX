.class public final Lcom/ecarx/eas/sdk/mediacenter/i;
.super Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
.source ""


# instance fields
.field public a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:I

.field private d:I

.field private e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;"
        }
    .end annotation
.end field

.field private f:Landroid/app/PendingIntent;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 0

    iput p1, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->c:I

    return-void
.end method

.method public final a(Landroid/app/PendingIntent;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->f:Landroid/app/PendingIntent;

    return-void
.end method

.method public final a(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->b:Ljava/lang/String;

    return-void
.end method

.method public final a(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->e:Ljava/util/List;

    return-void
.end method

.method public final b(I)V
    .locals 0

    iput p1, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->d:I

    return-void
.end method

.method public final getMediaList()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->e:Ljava/util/List;

    return-object v0
.end method

.method public final getMediaListId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final getMediaListType()I
    .locals 1

    iget v0, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->d:I

    return v0
.end method

.method public final getPendingIntent()Landroid/app/PendingIntent;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->f:Landroid/app/PendingIntent;

    return-object v0
.end method

.method public final getSourceType()I
    .locals 1

    iget v0, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->c:I

    return v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/i;->b:Ljava/lang/String;

    return-object v0
.end method
