.class public final Lcom/ecarx/eas/sdk/mediacenter/control/d;
.super Lecarx/xsf/mediacenter/control/IMediaController$Stub;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/control/IMediaController$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a:Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    return-void
.end method

.method private a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a:Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final onControllerChanged(Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;->onControllerChanged(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public final updateCurrentProgress(J)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;->updateCurrentProgress(J)V

    :cond_0
    return-void
.end method

.method public final updateErrorMsg(ILjava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;->updateErrorMsg(ILjava/lang/String;)V

    :cond_0
    return-void
.end method

.method public final updateMediaContentTypeList(Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;->updateMediaContentTypeList(Ljava/util/List;)V

    :cond_0
    return-void
.end method

.method public final updatePlaybackInfo(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;->updatePlaybackInfo(Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;)V

    :cond_0
    return-void
.end method

.method public final updatePlaylist(ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/d;->a()Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;->updatePlaylist(ILjava/util/List;)V

    :cond_0
    return-void
.end method
