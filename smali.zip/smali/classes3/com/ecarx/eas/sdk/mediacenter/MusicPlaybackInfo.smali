.class public Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
.super Lcom/ecarx/eas/sdk/mediacenter/AbstractMusicPlaybackInfo;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/AbstractMusicPlaybackInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public getAlbum()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getAppIcon()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getAppName()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getArtist()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getArtwork()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getCurrentLyricSentence()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getDuration()J
    .locals 2

    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getLaunchIntent()Landroid/app/PendingIntent;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getLoopMode()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getLyric()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getLyricContent()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getMediaPath()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getNextArtwork()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPackageName()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPlaybackStatus()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getPlayerIntent()Landroid/app/PendingIntent;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPlayingItemPositionInQueue()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getPlayingMediaListId()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPlayingMediaListType()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getPreviousArtwork()Landroid/net/Uri;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getRadioFrequency()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getRadioMode()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getRadioStationName()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getSourceType()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getUuid()Ljava/lang/String;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getVip()I
    .locals 1

    const/4 v0, -0x1

    return v0
.end method

.method public isCollected()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isDownloaded()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isSupportCollect()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isSupportDownload()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isSupportLoopModeSwitch()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public isSupportVrCtrlPlayStatus()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method
