.class public interface abstract Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract onGetMediaList(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V
.end method

.method public abstract onGetMusicPlaybackInfo(Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)V
.end method
