.class public Lcom/ecarx/eas/sdk/mediacenter/n;
.super Ljava/lang/Object;
.source ""


# static fields
.field private static a:Landroid/app/Application;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "StaticFieldLeak"
        }
    .end annotation
.end field


# direct methods
.method public static a()I
    .locals 8

    :try_start_0
    invoke-static {}, Ljava/lang/ClassLoader;->getSystemClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const-string v1, "com.ecarx.sdk.ECarXAPIBase"

    const/4 v2, 0x1

    invoke-static {v1, v2, v0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    array-length v3, v1

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_1

    aget-object v5, v1, v4

    const-string v6, "VERSION_INT"

    invoke-virtual {v5}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-virtual {v5, v2}, Ljava/lang/reflect/Field;->setAccessible(Z)V

    invoke-virtual {v5, v0}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v0

    :cond_0
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :catch_0
    :catchall_0
    :cond_1
    const/16 v0, 0x15a

    return v0
.end method

.method public static a(Lecarx/xsf/mediacenter/IRecommend;)Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;
    .locals 3

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;

    invoke-direct {v1}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;-><init>()V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IRecommend;->getRecommendType()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;->setRecommendType(I)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IRecommend;->getId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;->setId(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IRecommend;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;->setTitle(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IRecommend;->getArtist()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;->setArtist(Ljava/lang/String;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IRecommend;->getArtwork()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;->setArtwork(Landroid/net/Uri;)V

    invoke-interface {p0}, Lecarx/xsf/mediacenter/IRecommend;->getTextDescription()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfoBean;->setTextDes(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v0
.end method

.method public static b()Landroid/app/Application;
    .locals 2

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/n;->a:Landroid/app/Application;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/n;->c()Landroid/app/Application;

    move-result-object v0

    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/n;->a:Landroid/app/Application;

    if-nez v1, :cond_2

    if-nez v0, :cond_1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/n;->c()Landroid/app/Application;

    move-result-object v1

    sput-object v1, Lcom/ecarx/eas/sdk/mediacenter/n;->a:Landroid/app/Application;

    goto :goto_0

    :cond_1
    sput-object v0, Lcom/ecarx/eas/sdk/mediacenter/n;->a:Landroid/app/Application;

    :cond_2
    :goto_0
    return-object v0
.end method

.method private static c()Landroid/app/Application;
    .locals 6

    const-string v0, "u should init first"

    :try_start_0
    const-string v1, "android.app.ActivityThread"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const-string v2, "currentActivityThread"

    const/4 v3, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v4, 0x0

    new-array v5, v3, [Ljava/lang/Object;

    invoke-virtual {v2, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const-string v4, "getApplication"

    new-array v5, v3, [Ljava/lang/Class;

    invoke-virtual {v1, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    new-array v3, v3, [Ljava/lang/Object;

    invoke-virtual {v1, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_0

    check-cast v1, Landroid/app/Application;

    return-object v1

    :cond_0
    new-instance v1, Ljava/lang/NullPointerException;

    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/ClassNotFoundException;->printStackTrace()V

    goto :goto_0

    :catch_1
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/reflect/InvocationTargetException;->printStackTrace()V

    goto :goto_0

    :catch_2
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/IllegalAccessException;->printStackTrace()V

    goto :goto_0

    :catch_3
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/NoSuchMethodException;->printStackTrace()V

    :goto_0
    new-instance v1, Ljava/lang/NullPointerException;

    invoke-direct {v1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v1
.end method
