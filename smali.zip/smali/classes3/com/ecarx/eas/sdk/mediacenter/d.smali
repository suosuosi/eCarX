.class public final Lcom/ecarx/eas/sdk/mediacenter/d;
.super Ljava/lang/Object;
.source ""


# static fields
.field private static a:Ljava/lang/String; = "MediaBeanHelper"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_d_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static a(Lecarx/xsf/mediacenter/IMedia;)Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;
    .locals 3

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/c;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/c;-><init>()V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->a(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getArtist()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->b(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getAlbum()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->c(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getDuration()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/c;->a(J)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingItemPositionInQueue()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->a(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getSourceType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->b(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getMediaPath()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->a(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getLyricContent()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->d(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getLyric()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->b(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getArtwork()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->c(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getRadioFrequency()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/c;->e(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getRadioStationName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/c;->f(Ljava/lang/String;)V

    return-object v0
.end method

.method private static a(Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;)Lecarx/xsf/mediacenter/IMedia;
    .locals 4

    new-instance v0, Lecarx/xsf/mediacenter/IMedia;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/IMedia;-><init>()V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getUuid()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setUuid(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setTitle(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getArtist()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setArtist(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getAlbum()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setAlbum(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getDuration()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lecarx/xsf/mediacenter/IMedia;->setDuration(J)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getPlayingItemPositionInQueue()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setPositionInQueue(I)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getSourceType()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setSourceType(I)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setMediaPath(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setLyricContent(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getLyric()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setLyric(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setArtWork(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setRadioFrequency(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setRadioStationName(Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setPlayingMediaListId(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getPlayingMediaListType()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setPlayingMediaListType(I)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getVip()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setVip(I)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/NoSuchMethodError;->printStackTrace()V

    :goto_0
    :try_start_1
    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getSupportCollect()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setSupportCollect(I)V

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getCollected()I

    move-result v1

    invoke-virtual {v0, v1}, Lecarx/xsf/mediacenter/IMedia;->setCollected(I)V
    :try_end_1
    .catch Ljava/lang/NoSuchMethodError; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/NoSuchMethodError;->printStackTrace()V

    :goto_1
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/d;->a:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, " IMedia:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/IMedia;->getUuid()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ", info:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getUuid()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/d;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_d_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v0
.end method

.method public static a(Ljava/util/List;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;",
            ">;)",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;

    new-instance v2, Lecarx/xsf/mediacenter/IMedia;

    invoke-direct {v2}, Lecarx/xsf/mediacenter/IMedia;-><init>()V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getTitle()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setTitle(Ljava/lang/String;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getArtist()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setArtist(Ljava/lang/String;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getAlbum()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setAlbum(Ljava/lang/String;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getDuration()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lecarx/xsf/mediacenter/IMedia;->setDuration(J)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getPlayingItemPositionInQueue()I

    move-result v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setPositionInQueue(I)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getSourceType()I

    move-result v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setSourceType(I)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setMediaPath(Landroid/net/Uri;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setLyricContent(Ljava/lang/String;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getLyric()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setLyric(Landroid/net/Uri;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setArtWork(Landroid/net/Uri;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lecarx/xsf/mediacenter/IMedia;->setRadioFrequency(Ljava/lang/String;)V

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lecarx/xsf/mediacenter/IMedia;->setRadioStationName(Ljava/lang/String;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static b(Lecarx/xsf/mediacenter/IMedia;)Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;
    .locals 3

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/h;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/h;-><init>()V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getUuid()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->a(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->b(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getArtist()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->c(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getAlbum()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->d(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getDuration()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/h;->a(J)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingItemPositionInQueue()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->a(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getSourceType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->b(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getMediaPath()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->a(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getLyricContent()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->e(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getLyric()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->b(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getArtwork()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->c(Landroid/net/Uri;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getRadioFrequency()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->f(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getRadioStationName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->g(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->h(Ljava/lang/String;)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getPlayingMediaListType()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->d(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getVip()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/h;->c(I)V

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getSupportCollect()I

    invoke-virtual {p0}, Lecarx/xsf/mediacenter/IMedia;->getCollected()I

    return-object v0
.end method

.method public static b(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/d;->a:Ljava/lang/String;

    const-string v1, "getIMediaBeanList"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_d_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;

    if-eqz v1, :cond_0

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->a(Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;)Lecarx/xsf/mediacenter/IMedia;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method private static b(Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;)Lorg/json/JSONObject;
    .locals 4

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v1, "uuid"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getUuid()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "title"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getTitle()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artist"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getArtist()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "album"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getAlbum()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "duration"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getDuration()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string v1, "positionInQueue"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getPlayingItemPositionInQueue()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "sourceType"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getSourceType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "mediaPath"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "lyricContent"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "lyric"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getLyric()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "artWork"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "radioFrequency"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "radioStationName"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "playingMediaListId"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "playingMediaListType"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getPlayingMediaListType()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "vip"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getVip()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "supportCollect"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getSupportCollect()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "collected"

    invoke-virtual {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;->getCollected()I

    move-result p0

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Lorg/json/JSONException;->printStackTrace()V

    :goto_0
    return-object v0
.end method

.method public static c(Ljava/util/List;)Lorg/json/JSONArray;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)",
            "Lorg/json/JSONArray;"
        }
    .end annotation

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/d;->a:Ljava/lang/String;

    const-string v1, "getIMediaBeanList2Json"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_d_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    if-eqz p0, :cond_1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;

    if-eqz v1, :cond_0

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static d(Ljava/util/List;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lecarx/xsf/mediacenter/IMedia;

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Lecarx/xsf/mediacenter/IMedia;)Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-object v0
.end method
