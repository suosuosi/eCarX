.class public Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;
.super Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# instance fields
.field private background:Landroid/net/Uri;

.field private id:Ljava/lang/String;

.field private pendingIntent:Landroid/app/PendingIntent;

.field private title:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public getBackground()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->background:Landroid/net/Uri;

    return-object v0
.end method

.method public getId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->id:Ljava/lang/String;

    return-object v0
.end method

.method public getPendingIntent()Landroid/app/PendingIntent;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->pendingIntent:Landroid/app/PendingIntent;

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->title:Ljava/lang/String;

    return-object v0
.end method

.method public setBackground(Landroid/net/Uri;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->background:Landroid/net/Uri;

    return-void
.end method

.method public setId(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->id:Ljava/lang/String;

    return-void
.end method

.method public setPendingIntent(Landroid/app/PendingIntent;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->pendingIntent:Landroid/app/PendingIntent;

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/ContentInfoBean;->title:Ljava/lang/String;

    return-void
.end method
