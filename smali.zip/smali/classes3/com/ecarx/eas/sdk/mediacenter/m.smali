.class public final Lcom/ecarx/eas/sdk/mediacenter/m;
.super Lecarx/xsf/mediacenter/IMusicPlaybackInfo$Stub;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

.field private b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;


# direct methods
.method public constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    return-void
.end method

.method public constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final getAlbum()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getAlbum()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getAlbum()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "album is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ""

    return-object v0
.end method

.method public final getAppIcon()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getAppIcon()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    return-object v1
.end method

.method public final getAppName()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    const-string v2, "PlaybackInfoWrapper"

    if-eqz v0, :cond_0

    const-string v0, "old interface not support"

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getAppName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "app name is null"

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1
.end method

.method public final getArtist()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getArtist()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getArtist()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "artist is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ""

    return-object v0
.end method

.method public final getArtwork()Landroid/net/Uri;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "artwork is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getCurrentLyricSentence()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getCurrentLyricSentence()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getCurrentLyricSentence()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, ""

    return-object v0
.end method

.method public final getDuration()J
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getDuration()J

    move-result-wide v0

    return-wide v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getDuration()J

    move-result-wide v0

    return-wide v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "duration is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public final getLaunchIntent()Landroid/app/PendingIntent;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getLaunchIntent()Landroid/app/PendingIntent;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getLaunchIntent()Landroid/app/PendingIntent;

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getLoopMode()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getLoopMode()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getLoopMode()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final getLyric()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getLyric()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getLyric()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getLyricContent()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, ""

    return-object v0
.end method

.method public final getMediaPath()Landroid/net/Uri;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "MediaPath type is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getNextArtwork()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getNextArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getNextArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPackageName()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPackageName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    return-object v1
.end method

.method public final getPlaybackStatus()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getPlaybackStatus()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPlaybackStatus()I

    move-result v0

    return v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "PlaybackStatus type is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return v0
.end method

.method public final getPlayerIntent()Landroid/app/PendingIntent;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPlayerIntent()Landroid/app/PendingIntent;

    move-result-object v0

    return-object v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPlayingItemPositionInQueue()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getPlayingItemPositionInQueue()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPlayingItemPositionInQueue()I

    move-result v0

    return v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "PlayingItemPositionInQueue is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return v0
.end method

.method public final getPlayingMediaListId()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPlayingMediaListType()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPlayingMediaListType()I

    move-result v0

    return v0

    :cond_1
    :goto_0
    const/4 v0, -0x1

    return v0
.end method

.method public final getPreviousArtwork()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getPreviousArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getPreviousArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getRadioFrequency()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, ""

    return-object v0
.end method

.method public final getRadioMode()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getRadioMode()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getRadioMode()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final getRadioStationName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getSourceType()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getSourceType()I

    move-result v0

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getSourceType()I

    move-result v0

    return v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "source type is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "title is null"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, ""

    return-object v0
.end method

.method public final getUuid()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    const-string v2, "PlaybackInfoWrapper"

    if-eqz v0, :cond_0

    const-string v0, "old interface not support"

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getUuid()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const-string v0, "uuid is null"

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1
.end method

.method public final getVip()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->getVip()I

    move-result v0

    return v0

    :cond_1
    :goto_0
    const/4 v0, -0x1

    return v0
.end method

.method public final isCollected()Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->isCollected()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isDownloaded()Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->isDownloaded()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportCollect()Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->isSupportCollect()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportDownload()Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->isSupportDownload()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportLoopModeSwitch()Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->isSupportLoopModeSwitch()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method

.method public final isSupportVrCtrlPlayStatus()Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const-string v0, "PlaybackInfoWrapper"

    const-string v2, "old interface not support"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/m;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_m_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/m;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;->isSupportVrCtrlPlayStatus()Z

    move-result v0

    return v0

    :cond_1
    return v1
.end method
