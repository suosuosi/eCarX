.class public abstract Lcom/ecarx/eas/sdk/mediacenter/MediaCenterAPI;
.super Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;-><init>()V

    return-void
.end method

.method public static createMediaCenterAPI(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/MediaCenterAPI;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/g;->a()Lcom/ecarx/eas/sdk/mediacenter/g;

    move-result-object p0

    return-object p0
.end method

.method public static get(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/MediaCenterAPI;
    .locals 0

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/g;->a()Lcom/ecarx/eas/sdk/mediacenter/g;

    move-result-object p0

    return-object p0
.end method
