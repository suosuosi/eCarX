.class public Lcom/ecarx/eas/sdk/mediacenter/SemanticsLevelOneType;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final BLUETOOTH:I = 0x6000000

.field public static final CONTROL:I = 0x2000000

.field public static final KTV:I = 0x14000000

.field public static final MUSIC:I = 0x4000000

.field public static final NETRADIO:I = 0xa000000

.field public static final NEWS:I = 0xc000000

.field public static final PLATE:I = 0x12000000

.field public static final QUERY:I = 0x10000000

.field public static final TUNER:I = 0xe000000

.field public static final USB:I = 0x8000000

.field public static final VIDEO:I = 0x16000000


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
