.class public Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;
.super Lcom/ecarx/eas/sdk/mediacenter/control/AbstractMediaController;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/AbstractMediaController;-><init>()V

    return-void
.end method


# virtual methods
.method public onControllerChanged(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public updateCurrentProgress(J)V
    .locals 0

    return-void
.end method

.method public updateErrorMsg(ILjava/lang/String;)V
    .locals 0

    return-void
.end method

.method public updateMediaContentTypeList(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation

    return-void
.end method

.method public updatePlaybackInfo(Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;)V
    .locals 0

    return-void
.end method

.method public updatePlaylist(ILjava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;",
            ">;)V"
        }
    .end annotation

    return-void
.end method
