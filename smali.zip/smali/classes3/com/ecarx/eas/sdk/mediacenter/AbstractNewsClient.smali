.class public abstract Lcom/ecarx/eas/sdk/mediacenter/AbstractNewsClient;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final TYPE_COLLECTION_IMAGE:I = 0x2

.field public static final TYPE_COLLECTION_MUSIC:I = 0x0

.field public static final TYPE_COLLECTION_NEWS:I = 0x4

.field public static final TYPE_COLLECTION_RADIO:I = 0x3

.field public static final TYPE_COLLECTION_UNKNOWN:I = -0x1

.field public static final TYPE_COLLECTION_VIDEO:I = 0x1

.field public static final TYPE_DOWNLOAD_IMAGE:I = 0x2

.field public static final TYPE_DOWNLOAD_MUSIC:I = 0x0

.field public static final TYPE_DOWNLOAD_NEWS:I = 0x4

.field public static final TYPE_DOWNLOAD_RADIO:I = 0x3

.field public static final TYPE_DOWNLOAD_UNKNOWN:I = -0x1

.field public static final TYPE_DOWNLOAD_VIDEO:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract getNewsPlaybackInfo()Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;
.end method

.method public abstract onCollect(IZ)Z
.end method

.method public abstract onDownload(IZ)Z
.end method

.method public abstract onExit()Z
.end method

.method public abstract onMediaCenterFocusChanged(Ljava/lang/String;)V
.end method

.method public abstract onNext()Z
.end method

.method public abstract onPause()Z
.end method

.method public abstract onPlay()Z
.end method

.method public abstract onPrevious()Z
.end method

.method public abstract onReplay()Z
.end method
