.class public Lcom/ecarx/eas/sdk/mediacenter/VideoClient;
.super Lcom/ecarx/eas/sdk/mediacenter/AbstractVideoClient;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/AbstractVideoClient;-><init>()V

    return-void
.end method


# virtual methods
.method public getVideoPlaybackInfo()Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public onCollect(IZ)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public onDownload(IZ)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public onExit()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onForward()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onMediaCenterFocusChanged(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public onNext()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onPause()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onPlay()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onPrevious()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onReplay()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public onRewind()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method
