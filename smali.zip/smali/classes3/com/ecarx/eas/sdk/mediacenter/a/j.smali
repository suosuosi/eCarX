.class public Lcom/ecarx/eas/sdk/mediacenter/a/j;
.super Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/mediacenter/a/j$a;
    }
.end annotation


# static fields
.field private static volatile a:Lcom/ecarx/eas/sdk/mediacenter/a/j;

.field public static final synthetic d:I


# instance fields
.field private b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/ecarx/eas/sdk/mediacenter/a/j$a;",
            ">;"
        }
    .end annotation
.end field

.field private c:Lecarx/xsf/mediacenter/IMediaCenterSvc;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;-><init>()V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->W:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private a(Ljava/lang/String;)Lcom/ecarx/eas/sdk/mediacenter/a/j$a;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public static a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/j;
    .locals 2

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    if-nez v0, :cond_1

    const-class v0, Lcom/ecarx/eas/sdk/mediacenter/a/j;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a:Lcom/ecarx/eas/sdk/mediacenter/a/j;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_0

    :try_start_1
    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/j;

    invoke-direct {v1, p0}, Lcom/ecarx/eas/sdk/mediacenter/a/j;-><init>(Landroid/content/Context;)V

    sput-object v1, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a:Lcom/ecarx/eas/sdk/mediacenter/a/j;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    const/4 p0, 0x0

    :try_start_2
    sput-object p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    :cond_0
    :goto_0
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0

    :cond_1
    :goto_1
    sget-object p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    return-object p0
.end method

.method private a(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z
    .locals 6

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "VrMusicCtrlAPIImpl"

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "_attachMediaIntentObserverWrapper request: "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v3, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;

    invoke-direct {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j$a;-><init>(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)V

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    invoke-interface {p1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "VrMusicCtrlAPIImpl"

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "_attachMediaIntentObserverWrapper callbackMap.put : "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :cond_1
    monitor-exit v1

    return v0

    :catchall_0
    move-exception p1

    monitor-exit v1

    throw p1
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private b(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z
    .locals 5

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v2, "VrMusicCtrlAPIImpl"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "_detachMediaIntentObserverWrapper request: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    invoke-interface {v2, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "VrMusicCtrlAPIImpl"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "_detachMediaIntentObserverWrapper callbackMap.remove : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :cond_1
    monitor-exit v1

    return v0

    :catchall_0
    move-exception p1

    monitor-exit v1

    throw p1
.end method

.method private c(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z
    .locals 5

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v2, "VrMusicCtrlAPIImpl"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "_checkMediaIntentObserverWrapper request: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b:Ljava/util/Map;

    invoke-interface {v2, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    const-string v0, "VrMusicCtrlAPIImpl"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "_checkMediaIntentObserverWrapper callbackMap.remove : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :cond_1
    monitor-exit v1

    return v0

    :catchall_0
    move-exception p1

    monitor-exit v1

    throw p1
.end method


# virtual methods
.method public final a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    return-void
.end method

.method public cancelMusicCtrlCapabilityDeclaration(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z

    move-result v0

    if-eqz v0, :cond_0

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Ljava/lang/String;)Lcom/ecarx/eas/sdk/mediacenter/a/j$a;

    move-result-object v2

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelMusicCtrlCapabilityDeclaration(Lecarx/xsf/mediacenter/vr/IMusicIntentObserver;)Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    move v0, v1

    :goto_0
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "mSvrMng.cancelMediaCtrlCapabilityDeclaration : "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "VrMusicCtrlAPIImpl"

    invoke-static {v3, v2}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v0, :cond_0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->b(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z

    move-result p1

    return p1

    :cond_0
    return v1
.end method

.method public declareMusicCtrlCapability([ILcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-direct {p0, p2}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "declareMediaCtrlCapability : "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Ljava/lang/String;)Lcom/ecarx/eas/sdk/mediacenter/a/j$a;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "VrMusicCtrlAPIImpl"

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Ljava/lang/String;)Lcom/ecarx/eas/sdk/mediacenter/a/j$a;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareMusicCtrlCapability([ILecarx/xsf/mediacenter/vr/IMusicIntentObserver;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :cond_0
    return v1
.end method

.method public declareVrCtrlPriority(Ljava/lang/String;ILcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)V
    .locals 8

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    invoke-direct {p0, p3}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c(Lcom/ecarx/eas/sdk/vr/music/MusicIntentListener;)Z

    move-result v0

    if-eqz v0, :cond_0

    :try_start_0
    const-string v0, "VrMusicCtrlAPIImpl"

    const-string v1, "mSvrMng.declareVrCtrlPriority."

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a/j;->c:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-direct {p0, p3}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Ljava/lang/String;)Lcom/ecarx/eas/sdk/mediacenter/a/j$a;

    move-result-object v5

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v3, p1

    move v4, p2

    invoke-interface/range {v2 .. v7}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareVrCtrlPriority(Ljava/lang/String;ILecarx/xsf/mediacenter/vr/IMusicIntentObserver;Lecarx/xsf/mediacenter/vr/IRadioIntentObserver;Lecarx/xsf/mediacenter/vr/INewsIntentObserver;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :cond_0
    return-void
.end method
