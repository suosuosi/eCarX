.class final Lcom/ecarx/eas/sdk/mediacenter/e$2;
.super Lecarx/xsf/mediacenter/staterecover/IMusicRecoveryListener$Stub;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ecarx/eas/sdk/mediacenter/e;->setMusicRecoveryCallback(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;

.field private synthetic b:Lcom/ecarx/eas/sdk/mediacenter/e;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/e;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/e$2;->b:Lcom/ecarx/eas/sdk/mediacenter/e;

    iput-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e$2;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;

    invoke-direct {p0}, Lecarx/xsf/mediacenter/staterecover/IMusicRecoveryListener$Stub;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGetMediaList(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$2;->b:Lcom/ecarx/eas/sdk/mediacenter/e;

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object p1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$2;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;->onGetMediaList(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V

    :cond_0
    return-void
.end method

.method public final onGetMusicPlaybackInfo(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$2;->b:Lcom/ecarx/eas/sdk/mediacenter/e;

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object p1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$2;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;->onGetMusicPlaybackInfo(Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)V

    :cond_0
    return-void
.end method
