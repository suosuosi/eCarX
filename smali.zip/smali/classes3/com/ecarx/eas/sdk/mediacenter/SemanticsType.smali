.class public Lcom/ecarx/eas/sdk/mediacenter/SemanticsType;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final BLUETOOTH_CLOSE:I = 0x6000002

.field public static final BLUETOOTH_EX1:I = 0x6000008

.field public static final BLUETOOTH_EX2:I = 0x6000010

.field public static final BLUETOOTH_EX3:I = 0x6000020

.field public static final BLUETOOTH_OPEN:I = 0x6000001

.field public static final BLUETOOTH_PLAY:I = 0x6000004

.field public static final CONTROL_CANCEL_COLLECT:I = 0x2000020

.field public static final CONTROL_CANCEL_DOWNLOAD:I = 0x2000200

.field public static final CONTROL_CANCEL_SUBSCRIBE:I = 0x2000080

.field public static final CONTROL_CLOSE:I = 0x2000800

.field public static final CONTROL_COLLECT:I = 0x2000010

.field public static final CONTROL_DOWNLOAD:I = 0x2000100

.field public static final CONTROL_EX1:I = 0x2002000

.field public static final CONTROL_EX2:I = 0x2004000

.field public static final CONTROL_EX3:I = 0x2008000

.field public static final CONTROL_MODE:I = 0x2000400

.field public static final CONTROL_NEXT:I = 0x2000004

.field public static final CONTROL_OPEN_LYRIC:I = 0x2200000

.field public static final CONTROL_OPEN_PLAY:I = 0x2100000

.field public static final CONTROL_PAUSE:I = 0x2000002

.field public static final CONTROL_PLAY:I = 0x2000001

.field public static final CONTROL_PREVIOUS:I = 0x2000008

.field public static final CONTROL_REPLAY:I = 0x2010000

.field public static final CONTROL_START:I = 0x2001000

.field public static final CONTROL_SUBSCRIBE:I = 0x2000040

.field public static final KTV_SEARCH_ARTIST:I = 0x14000002

.field public static final KTV_SEARCH_ARTIST_SONG:I = 0x14000004

.field public static final KTV_SEARCH_SONG:I = 0x14000001

.field public static final MUSIC_EX1:I = 0x4000800

.field public static final MUSIC_EX2:I = 0x4001000

.field public static final MUSIC_EX3:I = 0x4002000

.field public static final MUSIC_PLAY:I = 0x4000001

.field public static final MUSIC_PLAY_COLLECT:I = 0x4000100

.field public static final MUSIC_PLAY_DOWNLOAD:I = 0x4000200

.field public static final MUSIC_PLAY_MOBILE:I = 0x4000400

.field public static final MUSIC_SEARCH_ALBUM:I = 0x4000010

.field public static final MUSIC_SEARCH_ARTIST:I = 0x4000004

.field public static final MUSIC_SEARCH_ARTIST_ALBUM:I = 0x4000020

.field public static final MUSIC_SEARCH_ARTIST_FOR_SHOW:I = 0x4008000

.field public static final MUSIC_SEARCH_ARTIST_SONG:I = 0x4000008

.field public static final MUSIC_SEARCH_ARTIST_SONG_FOR_SHOW:I = 0x4010000

.field public static final MUSIC_SEARCH_RANK:I = 0x4000080

.field public static final MUSIC_SEARCH_SONG:I = 0x4000002

.field public static final MUSIC_SEARCH_SONG_FOR_SHOW:I = 0x4004000

.field public static final MUSIC_SEARCH_TYPE:I = 0x4000040

.field public static final NETRADIO_CLOSE:I = 0xa000002

.field public static final NETRADIO_EX1:I = 0xa000100

.field public static final NETRADIO_EX2:I = 0xa000200

.field public static final NETRADIO_EX3:I = 0xa000400

.field public static final NETRADIO_OPEN:I = 0xa000001

.field public static final NETRADIO_PLAY:I = 0xa000004

.field public static final NETRADIO_PLAY_ALBUM:I = 0xa000008

.field public static final NETRADIO_PLAY_ARTIST_TYPE:I = 0xa000010

.field public static final NETRADIO_PLAY_PRESENTER:I = 0xa000080

.field public static final NETRADIO_PLAY_SUBSCRIBE:I = 0xa000040

.field public static final NETRADIO_PLAY_TYPE:I = 0xa000020

.field public static final NEWS_CLOSE:I = 0xc000002

.field public static final NEWS_EX1:I = 0xc000020

.field public static final NEWS_EX2:I = 0xc000040

.field public static final NEWS_EX3:I = 0xc000080

.field public static final NEWS_OPEN:I = 0xc000001

.field public static final NEWS_PLAY:I = 0xc000004

.field public static final NEWS_PLAY_RANDOM:I = 0xc000010

.field public static final NEWS_PLAY_TYPE:I = 0xc000008

.field public static final PLATE_EX1:I = 0x12000002

.field public static final PLATE_EX2:I = 0x12000004

.field public static final PLATE_EX3:I = 0x12000008

.field public static final PLATE_INFO:I = 0x12000001

.field public static final QUERY_ARTIST:I = 0x10000002

.field public static final QUERY_EX1:I = 0x10000004

.field public static final QUERY_EX2:I = 0x10000008

.field public static final QUERY_EX3:I = 0x10000010

.field public static final QUERY_SONG:I = 0x10000001

.field public static final TUNER_AMPLITUDE:I = 0xe000010

.field public static final TUNER_CLOSE:I = 0xe000002

.field public static final TUNER_EX1:I = 0xe000020

.field public static final TUNER_EX2:I = 0xe000040

.field public static final TUNER_EX3:I = 0xe000080

.field public static final TUNER_FREQUENCY:I = 0xe000008

.field public static final TUNER_OPEN:I = 0xe000001

.field public static final TUNER_PLAY:I = 0xe000004

.field public static final USB_CLOSE:I = 0x8000002

.field public static final USB_EX1:I = 0x8000008

.field public static final USB_EX2:I = 0x8000010

.field public static final USB_EX3:I = 0x8000020

.field public static final USB_OPEN:I = 0x8000001

.field public static final USB_PLAY:I = 0x8000004

.field public static final VIDEO_FAST_FORWARD_TIME_SLOT:I = 0x16000004

.field public static final VIDEO_FAST_FORWARD_TO_TIME_SLOT:I = 0x16000010

.field public static final VIDEO_PLAY_VIDEO_NAME:I = 0x16000002

.field public static final VIDEO_REWIND_TIME_SLOT:I = 0x16000008

.field public static final VIDEO_REWIND_TO_TIME_SLOT:I = 0x16000020


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
