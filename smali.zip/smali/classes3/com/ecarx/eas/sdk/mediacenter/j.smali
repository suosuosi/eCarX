.class public final Lcom/ecarx/eas/sdk/mediacenter/j;
.super Lecarx/xsf/mediacenter/IMusicClient$Stub;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/mediacenter/b$a;


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

.field private b:Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

.field private c:Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;

.field private d:Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IMusicClient$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/j;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    return-void
.end method

.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IMusicClient$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/j;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/j;->a:Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/j;->b:Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final a(ILjava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/xsf/mediacenter/IExContent;Landroid/os/IBinder;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;
    .locals 1

    new-instance p4, Ljava/lang/StringBuilder;

    const-string v0, "onAction:"

    invoke-direct {p4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ","

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string p3, "MusicClientWrapper"

    invoke-static {p3, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p2, 0x0

    const/4 p4, 0x1

    if-eq p1, p4, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object p1

    if-eqz p1, :cond_1

    const-string p1, "old interface not support"

    invoke-static {p3, p1}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_1
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object p1

    if-eqz p1, :cond_2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object p1

    invoke-virtual {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getMultiMediaList([I)Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaListsInfo2IExContent(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_2
    :goto_0
    return-object p2
.end method

.method public final a(ILjava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;
    .locals 19

    move-object/from16 v1, p0

    move/from16 v0, p1

    move-object/from16 v2, p3

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "onAction:"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, ","

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v5, p2

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v4, p4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "MusicClientWrapper"

    invoke-static {v4, v3}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    if-eq v0, v3, :cond_4

    const/4 v4, 0x2

    if-eq v0, v4, :cond_3

    const/4 v3, 0x4

    if-eq v0, v3, :cond_2

    const/4 v3, 0x5

    if-eq v0, v3, :cond_1

    :cond_0
    :goto_0
    const/4 v2, 0x0

    goto/16 :goto_2

    :cond_1
    invoke-direct/range {p0 .. p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct/range {p0 .. p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-static/range {p3 .. p3}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getProgress(Ljava/lang/String;)J

    move-result-wide v2

    invoke-virtual {v0, v2, v3}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onSeek(J)V

    goto :goto_0

    :cond_2
    iget-object v0, v1, Lcom/ecarx/eas/sdk/mediacenter/j;->d:Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;

    if-eqz v0, :cond_0

    invoke-static/range {p3 .. p3}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getTTSResultJson(Ljava/lang/String;)I

    move-result v0

    iget-object v2, v1, Lcom/ecarx/eas/sdk/mediacenter/j;->d:Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;

    invoke-virtual {v2, v0}, Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;->handleTtsResponse(I)V

    goto :goto_0

    :cond_3
    iget-object v0, v1, Lcom/ecarx/eas/sdk/mediacenter/j;->c:Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;

    if-eqz v0, :cond_0

    new-instance v4, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;

    invoke-direct {v4}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;-><init>()V

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v2, "semantic"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    const-string v6, "mediaSource"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "mediaType"

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "titleName"

    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "artistName"

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "albumName"

    invoke-virtual {v0, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "typeName"

    invoke-virtual {v0, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "mediaCtrl"

    invoke-virtual {v0, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "tunerFrequency"

    invoke-virtual {v0, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "subTypeName"

    invoke-virtual {v0, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "modeType"

    invoke-virtual {v0, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v15

    const-string v5, "originInfo"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v3, "errorCode"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v1, "errorMsg"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 p1, v1

    const-string v1, "detailsIntent"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 p3, v1

    const-string v1, "recogSlotTag"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v16, v1

    const-string v1, "mobileMusicName"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v17, v1

    const-string v1, "videoName"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v18, v1

    const-string v1, "timeSlot"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v0

    invoke-virtual {v4, v2}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setSemantic(I)V

    invoke-virtual {v4, v6}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setMediaSource(Ljava/lang/String;)V

    invoke-virtual {v4, v7}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setMediaType(Ljava/lang/String;)V

    invoke-virtual {v4, v8}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setTitleName(Ljava/lang/String;)V

    invoke-virtual {v4, v9}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setArtistName(Ljava/lang/String;)V

    invoke-virtual {v4, v10}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setAlbumName(Ljava/lang/String;)V

    invoke-virtual {v4, v11}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setTypeName(Ljava/lang/String;)V

    invoke-virtual {v4, v12}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setMediaCtrl(Ljava/lang/String;)V

    invoke-virtual {v4, v13}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setTunerFrequency(Ljava/lang/String;)V

    invoke-virtual {v4, v14}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setSubTypeName(Ljava/lang/String;)V

    invoke-virtual {v4, v15}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setModeType(I)V

    invoke-virtual {v4, v5}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setOriginInfo(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setErrorCode(Ljava/lang/String;)V

    move-object/from16 v2, p1

    invoke-virtual {v4, v2}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setErrorMsg(Ljava/lang/String;)V

    move-object/from16 v2, p3

    invoke-virtual {v4, v2}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setDetailsIntent(Ljava/lang/String;)V

    move-object/from16 v2, v16

    invoke-virtual {v4, v2}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setRecogSlotTag(Ljava/lang/String;)V

    move-object/from16 v2, v17

    invoke-virtual {v4, v2}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setMobileMusicName(Ljava/lang/String;)V

    invoke-virtual {v4, v0, v1}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setTimeSlot(J)V

    move-object/from16 v0, v18

    invoke-virtual {v4, v0}, Lcom/ecarx/eas/sdk/vr/channel/SemanticData;->setVideoName(Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    :goto_1
    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/ecarx/eas/sdk/mediacenter/j;->c:Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;

    const/4 v2, 0x1

    invoke-virtual {v0, v2, v4}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;->handleVrChannelData(ILcom/ecarx/eas/sdk/vr/channel/SemanticData;)V

    goto/16 :goto_0

    :cond_4
    :try_start_1
    invoke-direct/range {p0 .. p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_5

    const-string v0, "old interface not support"

    invoke-static {v4, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0

    :cond_5
    invoke-direct/range {p0 .. p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct/range {p0 .. p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getMultiMediaList([I)Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;

    move-result-object v0

    if-nez v0, :cond_6

    return-object v2

    :cond_6
    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaListsInfo2JsonStr(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "result:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    return-object v0

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto/16 :goto_0

    :goto_2
    return-object v2
.end method

.method public final a(Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/j;->c:Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;

    return-void
.end method

.method public final a(Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/j;->d:Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;

    return-void
.end method

.method public final ctrlCollect(IZ)I
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->ctrlCollect(IZ)I

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, -0x1

    return p1
.end method

.method public final ctrlCollectByUUID(ILjava/lang/String;Z)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->ctrlCollect(ILjava/lang/String;Z)V

    :cond_1
    return-void
.end method

.method public final ctrlPauseMediaList(I)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->ctrlPauseMediaList(I)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final ctrlPlayMediaList(I)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->ctrlPlayMediaList(I)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final getContentList()Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IContent;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v0, "MusicClientWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getContentList()Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertToIContent(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getCurrentProgress()J
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->getCurrentProgress()J

    move-result-wide v0

    return-wide v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getCurrentProgress()J

    move-result-wide v0

    return-wide v0

    :cond_1
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public final getCurrentSourceType()I
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->getCurrentSourceType()I

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getCurrentSourceType()I

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final getMediaSourceTypeList()[I
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->getMediaSourceTypeList()[I

    move-result-object v0

    return-object v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getMediaSourceTypeList()[I

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    new-array v0, v0, [I

    return-object v0
.end method

.method public final getMultiMediaList([I)Lecarx/xsf/mediacenter/IMediaLists;
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getMultiMediaList([I)Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;

    move-result-object p1

    if-nez p1, :cond_1

    return-object v1

    :cond_1
    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaLists(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lecarx/xsf/mediacenter/IMediaLists;

    move-result-object p1

    return-object p1

    :cond_2
    :goto_0
    return-object v1
.end method

.method public final getMusicPlaybackInfo()Lecarx/xsf/mediacenter/IMusicPlaybackInfo;
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/m;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v1

    invoke-interface {v1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->getMusicPlaybackInfo()Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)V

    return-object v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/m;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v1

    invoke-virtual {v1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getMusicPlaybackInfo()Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/m;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)V

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPlaylist(I)Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;"
        }
    .end annotation

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->getPlaylist(I)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/d;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    return-object p1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->getPlaylist(I)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final onCancelRecommend(Lecarx/xsf/mediacenter/IRecommend;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/n;->a(Lecarx/xsf/mediacenter/IRecommend;)Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onCancelRecommend(Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onCollect(IZ)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onCollect(IZ)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onDownload(IZ)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onDownload(IZ)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onExit()Z
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v0, "MusicClientWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onExit()Z

    move-result v0

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method public final onForward()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onForward()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onForward()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onLoopModeChange(I)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onLoopModeChange(I)Z

    move-result p1

    return p1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onLoopModeChange(I)Z

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final onMediaCenterFocusChanged(Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onMediaCenterFocusChanged(Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method public final onMediaForward(Z)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final onMediaQualityChange(I)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onMediaQualityChange(I)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onMediaRewind(Z)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final onMediaSelected(Lecarx/xsf/mediacenter/IMedia;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/d;->a(Lecarx/xsf/mediacenter/IMedia;)Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onMediaSelected(Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;)Z

    move-result p1

    return p1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Lecarx/xsf/mediacenter/IMedia;)Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onMediaSelected(Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;)Z

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final onMediaSelectedPlay(ILjava/lang/String;)Z
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    const-string v1, "MusicClientWrapper"

    if-eqz v0, :cond_0

    const-string p1, "old interface not support"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    const-string v0, "getOriginClazz  onMediaSelected"

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onMediaSelected(ILjava/lang/String;)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onNext()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onNext()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onNext()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onPause()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onPause()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onPause()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onPlay()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onPlay()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onPlay()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onPlayRecommend(Lecarx/xsf/mediacenter/IRecommend;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/n;->a(Lecarx/xsf/mediacenter/IRecommend;)Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onPlayRecommend(Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onPrevious()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onPrevious()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onPrevious()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onReplay()Z
    .locals 2

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v0, "MusicClientWrapper"

    const-string v1, "old interface not support"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onReplay()Z

    move-result v0

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method public final onRewind()Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onRewind()Z

    move-result v0

    return v0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onRewind()Z

    move-result v0

    return v0

    :cond_1
    const/4 v0, 0x0

    return v0
.end method

.method public final onSourceChanged(ILjava/lang/String;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onSourceChanged(ILjava/lang/String;)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method

.method public final onSourceSelected(I)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;->onSourceSelected(I)Z

    move-result p1

    return p1

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->onSourceSelected(I)Z

    move-result p1

    return p1

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final operationType(I)V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string v0, "old interface not support"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->operationType(I)V

    :cond_1
    return-void
.end method

.method public final selectListMediaPlay(IILjava/lang/String;)Z
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->a()Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string p1, "MusicClientWrapper"

    const-string p2, "old interface not support"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_j_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/j;->b()Lcom/ecarx/eas/sdk/mediacenter/MusicClient;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/MusicClient;->selectListMediaPlay(IILjava/lang/String;)Z

    move-result p1

    return p1

    :cond_1
    :goto_0
    const/4 p1, 0x0

    return p1
.end method
