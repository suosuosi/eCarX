.class public final Lcom/ecarx/eas/sdk/mediacenter/o;
.super Lecarx/xsf/mediacenter/IRecommend$Stub;
.source ""


# instance fields
.field private a:Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/IRecommend$Stub;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/o;->a:Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    return-void
.end method

.method private a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/o;->a:Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    :cond_0
    return-object v0
.end method


# virtual methods
.method public final getArtist()Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;->getArtist()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getArtwork()Landroid/net/Uri;
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getId()Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getRecommendType()I
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;->getRecommendType()I

    move-result v0

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public final getTextDescription()Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;->getTextDescription()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/o;->a()Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;

    move-result-object v0

    invoke-virtual {v0}, Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method
