.class public interface abstract Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract abandonPlayFocus(Ljava/lang/Object;)V
.end method

.method public abstract asyncSendVrChannelResult(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Ljava/lang/String;)Z
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract cancelSupportCollectTypes(Ljava/lang/Object;[I)Z
.end method

.method public abstract cancelSupportDownloadTypes(Ljava/lang/Object;[I)Z
.end method

.method public abstract cancelVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract cancelVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
.end method

.method public abstract connect(Ljava/lang/Object;)V
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract declareMediaCenterCapability(Ljava/lang/Object;[I)V
.end method

.method public abstract declareSupportCollectTypes(Ljava/lang/Object;[I)Z
.end method

.method public abstract declareSupportDownloadTypes(Ljava/lang/Object;[I)Z
.end method

.method public abstract declareVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract declareVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
.end method

.method public abstract getECarXAPIBaseVERSION_INT()I
.end method

.method public abstract getMediaControlClientApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;
.end method

.method public abstract getMediaControllerApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;
.end method

.method public abstract getRecoveryMediaList(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
.end method

.method public abstract getRecoveryMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
.end method

.method public abstract getVrLocalRadioApi()Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
.end method

.method public abstract getVrMusicApi()Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;
.end method

.method public abstract getVrNewsApi()Lcom/ecarx/eas/sdk/vr/news/VrNewsCtrlAPI;
.end method

.method public abstract onMusicRecoveryComplete(Ljava/lang/Object;)V
.end method

.method public abstract queryCurrentFocusClient(Ljava/lang/Object;)Ljava/lang/String;
.end method

.method public abstract register(Landroid/os/Binder;)Ljava/lang/Object;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract registerMusic(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Ljava/lang/Object;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
.end method

.method public abstract registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;Ljava/lang/String;)Ljava/lang/Object;
.end method

.method public abstract registerMusicRecoveryIntent(Ljava/lang/Object;ILandroid/content/Intent;)Z
.end method

.method public abstract registerMusicWithZoneId(ILjava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
.end method

.method public abstract registerNews(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Ljava/lang/Object;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract registerNews(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)Ljava/lang/Object;
.end method

.method public abstract registerVideo(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Ljava/lang/Object;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract registerVideo(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)Ljava/lang/Object;
.end method

.method public abstract requestPlay(Ljava/lang/Object;)Z
.end method

.method public abstract sendVrTtsActionResult(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z
.end method

.method public abstract setMusicRecoveryCallback(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V
.end method

.method public abstract unRegisterMusicRecoveryIntent(Ljava/lang/Object;)Z
.end method

.method public abstract unregister(Ljava/lang/Object;)Z
.end method

.method public abstract updateCollectMsg(Ljava/lang/Object;IILjava/lang/String;ILjava/lang/String;)V
.end method

.method public abstract updateCollectMsg(Ljava/lang/Object;ILjava/lang/String;)V
.end method

.method public abstract updateCurrentLyric(Ljava/lang/Object;Ljava/lang/String;)V
.end method

.method public abstract updateCurrentPlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract updateCurrentProgress(Ljava/lang/Object;J)V
.end method

.method public abstract updateCurrentRecommendInfo(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z
.end method

.method public abstract updateCurrentSourceType(Ljava/lang/Object;I)V
.end method

.method public abstract updateErrorMsg(Ljava/lang/Object;ILjava/lang/String;)V
.end method

.method public abstract updateErrorStateAndPendingIntent(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)V
.end method

.method public abstract updateMediaContent(Ljava/lang/Object;Ljava/util/List;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;",
            ">;)Z"
        }
    .end annotation
.end method

.method public abstract updateMediaContentTypeList(Ljava/lang/Object;Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract updateMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V
.end method

.method public abstract updateMediaSourceTypeList(Ljava/lang/Object;[I)Z
.end method

.method public abstract updateMultiMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z
.end method

.method public abstract updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)Z
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)Z
.end method

.method public abstract updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)Z
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)Z
.end method

.method public abstract updatePlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)Z
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)Z
.end method

.method public abstract updateZoneId(Ljava/lang/Object;I)V
.end method
