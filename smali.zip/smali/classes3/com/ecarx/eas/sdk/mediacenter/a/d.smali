.class public Lcom/ecarx/eas/sdk/mediacenter/a/d;
.super Lecarx/xsf/mediacenter/vr/INewsIntentObserver$Stub;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/vr/INewsIntentObserver$Stub;-><init>()V

    return-void
.end method


# virtual methods
.method public handlePlayNews(Lecarx/xsf/mediacenter/vr/QNewsResult;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method
