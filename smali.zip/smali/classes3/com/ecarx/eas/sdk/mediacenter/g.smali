.class public final Lcom/ecarx/eas/sdk/mediacenter/g;
.super Lcom/ecarx/eas/sdk/mediacenter/MediaCenterAPI;
.source ""


# static fields
.field private static d:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/mediacenter/g;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private volatile a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

.field private volatile b:Ljava/lang/String;

.field private c:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/g$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/g$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/mediacenter/g;->d:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaCenterAPI;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    .locals 3

    const-string v0, "MediaCenterAPI"

    const/4 v1, -0x1

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/16 v2, 0x80

    invoke-virtual {p0, p1, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v2, "getMetaDataInt:"

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    const/4 p1, 0x0

    invoke-virtual {p0, p2, p1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "getMetaDataInt: data:"

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return v1
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/mediacenter/g;)Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    return-object p0
.end method

.method public static a()Lcom/ecarx/eas/sdk/mediacenter/g;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/g;->d:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/mediacenter/g;

    return-object v0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/mediacenter/g;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)V
    .locals 8

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->c:Landroid/content/Context;

    const-string v1, "ecarx.xsf.mediacenter"

    const-string v2, "EAS_SUPPORT"

    invoke-static {v0, v1, v2}, Lcom/ecarx/eas/sdk/mediacenter/g;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    goto :goto_0

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    :goto_0
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    const-string v2, "mediacenter"

    const/4 v3, 0x0

    const-string v4, "MediaCenterAPI"

    const/4 v5, 0x0

    if-ne p1, v1, :cond_4

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/f;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    move-object p1, v5

    :goto_1
    if-nez p1, :cond_1

    new-array p0, v3, [Ljava/lang/Object;

    const-string p1, ">> OpenAPIService getServicePool is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    :goto_2
    invoke-static {v4, p0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_1
    :try_start_1
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    iget-object v6, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->b:Ljava/lang/String;

    invoke-interface {p1, v0, v1, v6, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;->getService(IILjava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v5
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_3
    if-nez v5, :cond_2

    new-array p0, v3, [Ljava/lang/Object;

    const-string p1, ">> OpenAPIService mediacenter binder is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_2
    invoke-static {v5}, Lecarx/xsf/mediacenter/IMediaCenterSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/IMediaCenterSvc;

    move-result-object p1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    instance-of v0, v0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz v0, :cond_3

    iget-object p0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    check-cast p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_3
    return-void

    :cond_4
    sget-object v6, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    const-string v7, ">> EASFrameworkService is NULL <<"

    if-ne p1, v6, :cond_7

    if-ne v0, v6, :cond_7

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/f;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    :try_start_2
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    move-result-object v5
    :try_end_2
    .catch Landroid/os/DeadObjectException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_4

    :catch_2
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    :goto_4
    if-nez v5, :cond_5

    new-array p0, v3, [Ljava/lang/Object;

    invoke-static {v7, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_5
    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-eqz p1, :cond_6

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    instance-of p1, p1, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz p1, :cond_6

    iget-object p0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    check-cast p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {p0, v5}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_6
    return-void

    :cond_7
    if-ne p1, v6, :cond_a

    if-ne v0, v1, :cond_a

    invoke-static {v1}, Lcom/ecarx/eas/sdk/mediacenter/f;->a(Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;)Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    :try_start_3
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    move-result-object p1
    :try_end_3
    .catch Landroid/os/DeadObjectException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_5

    :catch_3
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    move-object p1, v5

    :goto_5
    if-nez p1, :cond_8

    new-array p0, v3, [Ljava/lang/Object;

    invoke-static {v7, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_8
    :try_start_4
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    iget-object v6, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->b:Ljava/lang/String;

    invoke-interface {p1, v0, v1, v6, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->getService(IILjava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v5
    :try_end_4
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_4} :catch_4

    goto :goto_6

    :catch_4
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_6
    if-nez v5, :cond_9

    new-array p0, v3, [Ljava/lang/Object;

    const-string p1, ">> EASFrameworkService mediacenter binder is NULL <<"

    invoke-static {p1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_9
    invoke-static {v5}, Lecarx/xsf/mediacenter/IMediaCenterSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/IMediaCenterSvc;

    move-result-object p1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-eqz v0, :cond_a

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    instance-of v0, v0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    if-eqz v0, :cond_a

    iget-object p0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    check-cast p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;

    invoke-virtual {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    :cond_a
    return-void
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final abandonPlayFocus(Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->abandonPlayFocus(Ljava/lang/Object;)V

    return-void
.end method

.method public final asyncSendVrChannelResult(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Ljava/lang/String;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->asyncSendVrChannelResult(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public final cancelSupportCollectTypes(Ljava/lang/Object;[I)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->cancelSupportCollectTypes(Ljava/lang/Object;[I)Z

    move-result p1

    return p1
.end method

.method public final cancelSupportDownloadTypes(Ljava/lang/Object;[I)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->cancelSupportDownloadTypes(Ljava/lang/Object;[I)Z

    move-result p1

    return p1
.end method

.method public final cancelVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->cancelVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z

    move-result p1

    return p1
.end method

.method public final cancelVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->cancelVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z

    move-result p1

    return p1
.end method

.method public final connect(Ljava/lang/Object;)V
    .locals 0

    return-void
.end method

.method public final declareMediaCenterCapability(Ljava/lang/Object;[I)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->declareMediaCenterCapability(Ljava/lang/Object;[I)V

    return-void
.end method

.method public final declareSupportCollectTypes(Ljava/lang/Object;[I)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->declareSupportCollectTypes(Ljava/lang/Object;[I)Z

    move-result p1

    return p1
.end method

.method public final declareSupportDownloadTypes(Ljava/lang/Object;[I)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->declareSupportDownloadTypes(Ljava/lang/Object;[I)Z

    move-result p1

    return p1
.end method

.method public final declareVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->declareVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z

    move-result p1

    return p1
.end method

.method public final declareVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->declareVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z

    move-result p1

    return p1
.end method

.method public final getECarXAPIBaseVERSION_INT()I
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPI"

    const-string v1, ">> please wait for mediacenter init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, -0x1

    return v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getECarXAPIBaseVERSION_INT()I

    move-result v0

    return v0
.end method

.method public final getMediaControlClientApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPI"

    const-string v1, ">> please wait for mediacenter init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getMediaControlClientApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;

    move-result-object v0

    return-object v0
.end method

.method public final getMediaControllerApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPI"

    const-string v1, ">> please wait for mediacenter init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getMediaControllerApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;

    move-result-object v0

    return-object v0
.end method

.method public final getRecoveryMediaList(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getRecoveryMediaList(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object p1

    return-object p1
.end method

.method public final getRecoveryMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getRecoveryMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object p1

    return-object p1
.end method

.method public final getVrLocalRadioApi()Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPI"

    const-string v1, ">> please wait for mediacenter init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getVrLocalRadioApi()Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;

    move-result-object v0

    return-object v0
.end method

.method public final getVrMusicApi()Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPI"

    const-string v1, ">> please wait for mediacenter init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getVrMusicApi()Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;

    move-result-object v0

    return-object v0
.end method

.method public final getVrNewsApi()Lcom/ecarx/eas/sdk/vr/news/VrNewsCtrlAPI;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string v0, "MediaCenterAPI"

    const-string v1, ">> please wait for mediacenter init success!!! <<"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    return-object v0

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->getVrNewsApi()Lcom/ecarx/eas/sdk/vr/news/VrNewsCtrlAPI;

    move-result-object v0

    return-object v0
.end method

.method public final init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;)V
    .locals 3

    invoke-super {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;->init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;)V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->c:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->b:Ljava/lang/String;

    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object v0

    const-string v1, "mediacenter"

    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/g$2;

    invoke-direct {v2, p0}, Lcom/ecarx/eas/sdk/mediacenter/g$2;-><init>(Lcom/ecarx/eas/sdk/mediacenter/g;)V

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)V
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public final onMusicRecoveryComplete(Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->onMusicRecoveryComplete(Ljava/lang/Object;)V

    return-void
.end method

.method public final queryCurrentFocusClient(Ljava/lang/Object;)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->queryCurrentFocusClient(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public final register(Landroid/os/Binder;)Ljava/lang/Object;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final registerMusic(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Ljava/lang/Object;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;Ljava/lang/String;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final registerMusicRecoveryIntent(Ljava/lang/Object;ILandroid/content/Intent;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->registerMusicRecoveryIntent(Ljava/lang/Object;ILandroid/content/Intent;)Z

    move-result p1

    return p1
.end method

.method public final registerMusicWithZoneId(ILjava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->registerMusicWithZoneId(ILjava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final registerNews(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Ljava/lang/Object;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final registerNews(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->registerNews(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final registerVideo(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Ljava/lang/Object;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final registerVideo(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->registerVideo(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final release()V
    .locals 0

    invoke-super {p0}, Lcom/ecarx/eas/framework/sdk/ECarXAPIBase;->release()V

    return-void
.end method

.method public final requestPlay(Ljava/lang/Object;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->requestPlay(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final sendVrTtsActionResult(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->sendVrTtsActionResult(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z

    move-result p1

    return p1
.end method

.method public final setMusicRecoveryCallback(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->setMusicRecoveryCallback(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V

    return-void
.end method

.method public final unRegisterMusicRecoveryIntent(Ljava/lang/Object;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->unRegisterMusicRecoveryIntent(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final unregister(Ljava/lang/Object;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string v0, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->unregister(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final updateCollectMsg(Ljava/lang/Object;IILjava/lang/String;ILjava/lang/String;)V
    .locals 7

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    move v5, p5

    move-object v6, p6

    invoke-interface/range {v0 .. v6}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCollectMsg(Ljava/lang/Object;IILjava/lang/String;ILjava/lang/String;)V

    return-void
.end method

.method public final updateCollectMsg(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCollectMsg(Ljava/lang/Object;ILjava/lang/String;)V

    return-void
.end method

.method public final updateCurrentLyric(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCurrentLyric(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public final updateCurrentPlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCurrentPlaylist(Ljava/lang/Object;ILjava/util/List;)V

    return-void
.end method

.method public final updateCurrentProgress(Ljava/lang/Object;J)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCurrentProgress(Ljava/lang/Object;J)V

    return-void
.end method

.method public final updateCurrentRecommendInfo(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCurrentRecommendInfo(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z

    move-result p1

    return p1
.end method

.method public final updateCurrentSourceType(Ljava/lang/Object;I)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateCurrentSourceType(Ljava/lang/Object;I)V

    return-void
.end method

.method public final updateErrorMsg(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2, p3}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateErrorMsg(Ljava/lang/Object;ILjava/lang/String;)V

    return-void
.end method

.method public final updateErrorStateAndPendingIntent(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)V
    .locals 6

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    move-object v1, p1

    move v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    invoke-interface/range {v0 .. v5}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateErrorStateAndPendingIntent(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)V

    return-void
.end method

.method public final updateMediaContent(Ljava/lang/Object;Ljava/util/List;)Z
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;",
            ">;)Z"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateMediaContent(Ljava/lang/Object;Ljava/util/List;)Z

    move-result p1

    return p1
.end method

.method public final updateMediaContentTypeList(Ljava/lang/Object;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateMediaContentTypeList(Ljava/lang/Object;Ljava/util/List;)V

    return-void
.end method

.method public final updateMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V

    return-void
.end method

.method public final updateMediaSourceTypeList(Ljava/lang/Object;[I)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateMediaSourceTypeList(Ljava/lang/Object;[I)Z

    move-result p1

    return p1
.end method

.method public final updateMultiMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateMultiMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z

    move-result p1

    return p1
.end method

.method public final updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)Z

    move-result p1

    return p1
.end method

.method public final updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)Z

    move-result p1

    return p1
.end method

.method public final updatePlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;",
            ">;)V"
        }
    .end annotation

    return-void
.end method

.method public final updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)Z

    move-result p1

    return p1
.end method

.method public final updateZoneId(Ljava/lang/Object;I)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    if-nez v0, :cond_0

    const-string p1, "MediaCenterAPI"

    const-string p2, ">> please wait for mediacenter init success!!! <<"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/g;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_g_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/g;->a:Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;

    invoke-interface {v0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;->updateZoneId(Ljava/lang/Object;I)V

    return-void
.end method
