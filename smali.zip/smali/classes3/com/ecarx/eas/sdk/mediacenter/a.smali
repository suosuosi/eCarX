.class public final Lcom/ecarx/eas/sdk/mediacenter/a;
.super Lcom/ecarx/eas/framework/sdk/common/internal/IApi;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/IApi<",
        "Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;",
        ">;",
        "Lcom/ecarx/eas/sdk/mediacenter/IMediaCenterAPI;"
    }
.end annotation


# static fields
.field private static k:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/sdk/mediacenter/a;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Landroid/content/Context;

.field private b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

.field private c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

.field private d:Lcom/ecarx/eas/xsf/mediacenter/IExCallback;

.field private e:Lcom/ecarx/eas/sdk/mediacenter/a/i;

.field private f:Lcom/ecarx/eas/sdk/mediacenter/a/j;

.field private g:Lcom/ecarx/eas/sdk/mediacenter/a/k;

.field private h:[B

.field private i:Lcom/ecarx/eas/sdk/mediacenter/b;

.field private j:Lcom/ecarx/eas/sdk/mediacenter/j;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/a$1;

    invoke-direct {v0}, Lcom/ecarx/eas/sdk/mediacenter/a$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/sdk/mediacenter/a;->k:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;-><init>()V

    const/4 v0, 0x0

    new-array v0, v0, [B

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->h:[B

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->W:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;
    .locals 8

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p2, "NoParam"

    :cond_1
    new-instance v0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    const-string v3, "mediacenter"

    const-string v4, "MediaCenterAPI"

    invoke-virtual {p2}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    iget-object v7, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->h:[B

    move-object v2, v0

    move-object v5, p1

    invoke-direct/range {v2 .. v7}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;

    move-result-object p1

    if-eqz p1, :cond_2

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mRetMsg:Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mBinder:Landroid/os/IBinder;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_2
    return-object v1
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/mediacenter/a;Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object p0

    return-object p0
.end method

.method private a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/a$3;

    invoke-direct {v0, p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a$3;-><init>(Lcom/ecarx/eas/sdk/mediacenter/a;Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)V

    return-object v0
.end method

.method static synthetic a(Lcom/ecarx/eas/sdk/mediacenter/a;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object p0

    return-object p0
.end method

.method private a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/a$4;

    invoke-direct {v0, p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a$4;-><init>(Lcom/ecarx/eas/sdk/mediacenter/a;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V

    return-object v0
.end method

.method public static a()Lcom/ecarx/eas/sdk/mediacenter/a;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/sdk/mediacenter/a;->k:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/sdk/mediacenter/a;

    return-object v0
.end method

.method private static a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;
    .locals 2

    :try_start_0
    invoke-interface {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->call(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;

    move-result-object p0

    iget p1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mCode:I

    const/16 v0, 0xc8

    if-eq p1, v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "sendMsg fail:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mCode:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ","

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mMsg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;
    .locals 1

    :try_start_0
    invoke-interface {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->asyncBinderCall(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;

    move-result-object p0

    iget p1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mCode:I

    const/16 p2, 0xc8

    if-eq p1, p2, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "sendMsg fail:"

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v0, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mCode:I

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ","

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mMsg:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-object p0

    :catch_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private a(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)V

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerMusic(Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method private a(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/k;

    invoke-direct {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/k;-><init>(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)V

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerNews(Lecarx/xsf/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method private a(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/p;

    invoke-direct {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/p;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)V

    invoke-interface {v0, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerVideo(Lecarx/xsf/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method private static a(Landroid/content/Intent;)Ljava/lang/String;
    .locals 5

    const/4 v0, 0x0

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v2, "state_action"

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "state_package"

    invoke-virtual {p0}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {p0, v3}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_2
    :goto_1
    return-object v0
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;
    .locals 8

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    :try_start_0
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p2, "NoParam"

    :cond_1
    new-instance v0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    const-string v3, "mediacenter"

    const-string v4, "MediaCenterAPI"

    invoke-virtual {p2}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    iget-object v7, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->h:[B

    move-object v2, v0

    move-object v5, p1

    invoke-direct/range {v2 .. v7}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    invoke-static {p1, v0, p3}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;Landroid/os/IBinder;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;

    move-result-object p1

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mRetMsg:Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    if-eqz p1, :cond_3

    array-length p2, p1

    if-gtz p2, :cond_2

    goto :goto_0

    :cond_2
    new-instance p2, Ljava/lang/String;

    invoke-direct {p2, p1}, Ljava/lang/String;-><init>([B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p2

    :catch_0
    :cond_3
    :goto_0
    return-object v1
.end method

.method private static a(Ljava/lang/Object;)V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "verifyToken: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "EasMediaCenterAPIImpl"

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    instance-of p0, p0, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method private a(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)Z
    .locals 7

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaErrorBean;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/session/MediaErrorBean;-><init>()V

    invoke-virtual {v0, p3}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->setErrorState(I)V

    invoke-virtual {v0, p5}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->setPendingIntent(Landroid/app/PendingIntent;)V

    invoke-virtual {v0, p4}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->setErrorMsg(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Lecarx/xsf/mediacenter/session/MediaErrorBean;->setSourceType(I)V

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->d:Lcom/ecarx/eas/xsf/mediacenter/IExCallback;

    const/4 v2, 0x2

    const-string v3, "updateErrorStateAndPendingIntentEx"

    const-string v4, ""

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaErrorBeanIExContent(Lecarx/xsf/mediacenter/session/MediaErrorBean;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    move-result-object v5

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v6

    invoke-interface/range {v1 .. v6}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback;->onExAction(ILjava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/xsf/mediacenter/IExContent;Landroid/os/IBinder;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method private a(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z
    .locals 6

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->d:Lcom/ecarx/eas/xsf/mediacenter/IExCallback;

    const/4 v1, 0x1

    const-string v2, "updateMultiMediaListEx"

    const-string v3, ""

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getMediaListsInfo2IExContent(Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    move-result-object v4

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v5

    invoke-interface/range {v0 .. v5}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback;->onExAction(ILjava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/xsf/mediacenter/IExContent;Landroid/os/IBinder;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method private a(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 2

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v1, "vrChannelInfo"

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getVrChannelInfo2Json(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lorg/json/JSONObject;

    move-result-object p2

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p2

    invoke-virtual {p2}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_0

    :catch_1
    move-exception p2

    invoke-virtual {p2}, Lorg/json/JSONException;->printStackTrace()V

    :goto_0
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    const-string v0, "cancelVrSemanticsCapability"

    invoke-direct {p0, v0, p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method private a(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 6

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    array-length v2, p3

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_0

    aget v5, p3, v4

    invoke-virtual {v1, v5}, Lorg/json/JSONArray;->put(I)Lorg/json/JSONArray;

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    :try_start_0
    const-string p3, "vrChannelInfo"

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getVrChannelInfo2Json(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lorg/json/JSONObject;

    move-result-object p2

    invoke-virtual {v0, p3, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p2, "semanticsTypes"

    invoke-virtual {v0, p2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p2

    invoke-virtual {p2}, Landroid/os/RemoteException;->printStackTrace()V

    goto :goto_1

    :catch_1
    move-exception p2

    invoke-virtual {p2}, Lorg/json/JSONException;->printStackTrace()V

    :goto_1
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    const-string p3, "declareVrSemanticsCapability"

    invoke-direct {p0, p3, p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-virtual {p2, p4}, Lcom/ecarx/eas/sdk/mediacenter/j;->a(Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)V

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    return v3
.end method

.method private a(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z
    .locals 2

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v1, "msg"

    invoke-virtual {v0, v1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p3, "hintId"

    invoke-virtual {v0, p3, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p2

    invoke-virtual {p2}, Lorg/json/JSONException;->printStackTrace()V

    :goto_0
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    const-string p3, "sendVrTtsActionResult"

    invoke-direct {p0, p3, p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-virtual {p2, p4}, Lcom/ecarx/eas/sdk/mediacenter/j;->a(Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)V

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$002(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final abandonPlayFocus(Ljava/lang/Object;)V
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "abandonPlayFocus unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    const-string v0, "abandonPlayFocus"

    const-string v1, ""

    invoke-direct {p0, v0, v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    return-void
.end method

.method public final asyncSendVrChannelResult(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Ljava/lang/String;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->wrap(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;

    move-result-object p2

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->asyncSendVrChannelResult(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "asyncSendVrChannelResult, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final cancelSupportCollectTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelSupportCollectTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final cancelSupportDownloadTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelSupportDownloadTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final cancelVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->wrap(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->cancelVrChannelCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "cancelVrChannelCapability, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final cancelVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z
    .locals 2

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v1, "declareVrSemanticsCapability"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v1, :cond_0

    const-string v1, "unbind media center service"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Z

    move-result p1

    return p1
.end method

.method public final connect(Ljava/lang/Object;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public final declareMediaCenterCapability(Ljava/lang/Object;[I)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareMediaCenterCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final declareSupportCollectTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareSupportCollectTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final declareSupportDownloadTypes(Ljava/lang/Object;[I)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareSupportDownloadTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final declareVrChannelCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;->wrap(Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;)Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;

    move-result-object p2

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a/a/a;

    invoke-direct {v1, p3}, Lcom/ecarx/eas/sdk/mediacenter/a/a/a;-><init>(Lcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)V

    invoke-interface {v0, p1, p2, v1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->declareVrChannelCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;Lecarx/xsf/mediacenter/vr/channel/IVrChannelObserver;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "declareVrChannelCapability, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final declareVrSemanticsCapability(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z
    .locals 2

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v1, "declareVrSemanticsCapability"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v1, :cond_0

    const-string v1, "unbind media center service"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;Lcom/ecarx/eas/sdk/vr/channel/VrChannelInfo;[ILcom/ecarx/eas/sdk/vr/channel/VrChannelDataListener;)Z

    move-result p1

    return p1
.end method

.method public final getECarXAPIBaseVERSION_INT()I
    .locals 1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/n;->a()I

    move-result v0

    return v0
.end method

.method public final getMediaControlClientApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v2, "unbind media center service"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a()Lcom/ecarx/eas/sdk/mediacenter/control/a;

    move-result-object v0

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-interface {v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->getMediaControlClientApi()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a(Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;)Lcom/ecarx/eas/sdk/mediacenter/control/a;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v1
.end method

.method public final getMediaControllerApi()Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v2, "unbind media center service"

    invoke-static {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a()Lcom/ecarx/eas/sdk/mediacenter/control/c;

    move-result-object v0

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-interface {v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->getMediaControllerApi()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/control/c;->a(Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;)Lcom/ecarx/eas/sdk/mediacenter/control/c;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    return-object v1
.end method

.method public final getRecoveryMediaList(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->getRecoveryMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "getRecoveryMediaList, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final getRecoveryMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->getRecoveryMusicPlaybackInfo(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "getRecoveryMusicPlaybackInfo, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final getVrLocalRadioApi()Lcom/ecarx/eas/sdk/vr/radio/VrLocalRadioCtrlAPI;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->e:Lcom/ecarx/eas/sdk/mediacenter/a/i;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getVrMusicApi()Lcom/ecarx/eas/sdk/vr/music/VrMusicCtrlAPI;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->f:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final getVrNewsApi()Lcom/ecarx/eas/sdk/vr/news/VrNewsCtrlAPI;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->g:Lcom/ecarx/eas/sdk/mediacenter/a/k;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final synthetic init(Landroid/os/IInterface;)V
    .locals 2

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    invoke-super {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->init(Landroid/os/IInterface;)V

    invoke-static {}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    move-result-object p1

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getAppContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->a:Landroid/content/Context;

    const-string p1, "getMainBinder"

    const-string v0, ""

    invoke-direct {p0, p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object p1

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    invoke-static {p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/IMediaCenterSvc;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v1

    :goto_0
    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string p1, "getExBinder"

    invoke-direct {p0, p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-static {p1}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback$Stub;->asInterface(Landroid/os/IBinder;)Lcom/ecarx/eas/xsf/mediacenter/IExCallback;

    move-result-object v1

    :cond_1
    iput-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->d:Lcom/ecarx/eas/xsf/mediacenter/IExCallback;

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-eqz p1, :cond_2

    :try_start_0
    invoke-interface {p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->getStateBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    move-result-object p1

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_1
    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/i;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->e:Lcom/ecarx/eas/sdk/mediacenter/a/i;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/i;->a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/j;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->f:Lcom/ecarx/eas/sdk/mediacenter/a/j;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/j;->a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/sdk/mediacenter/a/k;->a(Landroid/content/Context;)Lcom/ecarx/eas/sdk/mediacenter/a/k;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->g:Lcom/ecarx/eas/sdk/mediacenter/a/k;

    invoke-virtual {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a/k;->a(Lecarx/xsf/mediacenter/IMediaCenterSvc;)V

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/b;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/b;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, " InitialImpl OK"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    return-void
.end method

.method public final onMusicRecoveryComplete(Ljava/lang/Object;)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->onMusicRecoveryComplete(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "registerMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final queryCurrentFocusClient(Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string v1, "EasMediaCenterAPIImpl"

    if-eqz v0, :cond_0

    :try_start_0
    const-string v0, "queryCurrentFocusClient"

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->queryCurrentFocusClient(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const-string p1, "queryCurrentFocusClient, but unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final register(Landroid/os/Binder;)Ljava/lang/Object;
    .locals 1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Not implementation"

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final synthetic registerMusic(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Ljava/lang/Object;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lcom/ecarx/eas/sdk/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1

    return-object p1
.end method

.method public final registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    const-string v2, "EasMediaCenterAPIImpl"

    if-nez v0, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "svc: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInMusic(Ljava/lang/String;Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p2

    const/4 v0, 0x0

    invoke-virtual {p0, p2, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->updateZoneId(Ljava/lang/Object;I)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "token: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, "registerEx"

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    invoke-virtual {v2}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback$Stub;->asBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-direct {p0, v0, p1, v2}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    const-string v0, "MusicClient"

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-virtual {p1, v0, v2}, Lcom/ecarx/eas/sdk/mediacenter/b;->a(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/b$a;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p2

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final registerMusic(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;Ljava/lang/String;)Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    const-string v2, "EasMediaCenterAPIImpl"

    if-nez v0, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "svc: "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)V

    iput-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const-string v0, "packageName"

    invoke-virtual {p2, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "mediaSessionPackageName"

    invoke-virtual {p2, v0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception p3

    :try_start_2
    invoke-virtual {p3}, Ljava/lang/Exception;->printStackTrace()V

    :goto_0
    const-string p3, "registerMediasessionEx"

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback$Stub;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-direct {p0, p3, p2, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    iget-object p3, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-interface {p2, p1, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInMusic(Ljava/lang/String;Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p2

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v0, "token: "

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-static {v2, p3}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-string p3, "registerEx"

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback$Stub;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-direct {p0, p3, p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    const-string p3, "MusicClient"

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-virtual {p1, p3, v0}, Lcom/ecarx/eas/sdk/mediacenter/b;->a(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/b$a;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    return-object p2

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Exception: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1
.end method

.method public final registerMusicRecoveryIntent(Ljava/lang/Object;ILandroid/content/Intent;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p3}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Landroid/content/Intent;)Ljava/lang/String;

    move-result-object p3

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->registerMusicRecoveryIntent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return p1

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "registerMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final registerMusicWithZoneId(ILjava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)Ljava/lang/Object;
    .locals 4

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v1, "registerMusicWithZoneId"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v2

    :cond_0
    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "svc: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-direct {v1, p3}, Lcom/ecarx/eas/sdk/mediacenter/j;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicClient;)V

    iput-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    iget-object p3, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    invoke-interface {p3, p2, v1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInMusic(Ljava/lang/String;Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p3

    invoke-virtual {p0, p3, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->updateZoneId(Ljava/lang/Object;I)V

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "token: "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const-string p1, "registerEx"

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    invoke-virtual {v1}, Lcom/ecarx/eas/xsf/mediacenter/IExCallback$Stub;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-direct {p0, p1, p2, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    iget-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->i:Lcom/ecarx/eas/sdk/mediacenter/b;

    const-string p2, "MusicClient"

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->j:Lcom/ecarx/eas/sdk/mediacenter/j;

    invoke-virtual {p1, p2, v1}, Lcom/ecarx/eas/sdk/mediacenter/b;->a(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/b$a;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p3

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Exception: "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v2
.end method

.method public final synthetic registerNews(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Ljava/lang/Object;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lcom/ecarx/eas/sdk/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1

    return-object p1
.end method

.method public final registerNews(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/k;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/k;-><init>(Lcom/ecarx/eas/sdk/mediacenter/NewsClient;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInNews(Ljava/lang/String;Lecarx/xsf/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method public final synthetic registerVideo(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Ljava/lang/Object;
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-direct {p0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Lcom/ecarx/eas/sdk/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1

    return-object p1
.end method

.method public final registerVideo(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/p;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/p;-><init>(Lcom/ecarx/eas/sdk/mediacenter/VideoClient;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->registerInVideo(Ljava/lang/String;Lecarx/xsf/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-object v1
.end method

.method public final requestPlay(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->requestPlay(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final sendVrTtsActionResult(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z
    .locals 2

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v1, "SendVrTtsActionResult"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v1, :cond_0

    const-string v1, "unbind media center service"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/sdk/vr/channel/VrTtsResultListener;)Z

    move-result p1

    return p1
.end method

.method public final setMusicRecoveryCallback(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    new-instance v1, Lcom/ecarx/eas/sdk/mediacenter/a$2;

    invoke-direct {v1, p0, p2}, Lcom/ecarx/eas/sdk/mediacenter/a$2;-><init>(Lcom/ecarx/eas/sdk/mediacenter/a;Lcom/ecarx/eas/sdk/mediacenter/IMusicRecoveryCallback;)V

    invoke-interface {v0, p1, v1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->setMusicRecoveryCallback(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/staterecover/IMusicRecoveryListener;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "registerMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final unRegisterMusicRecoveryIntent(Ljava/lang/Object;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->c:Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;

    if-eqz v0, :cond_0

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/staterecover/IStateRecoverApiSvc;->unRegisterMusicRecoveryIntent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return p1

    :cond_0
    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "unRegisterMusicRecoveryIntent, but unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final unregister(Ljava/lang/Object;)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string v0, "unbind media center service"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    const/4 v1, 0x1

    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->unregister(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateCollectMsg(Ljava/lang/Object;IILjava/lang/String;ILjava/lang/String;)V
    .locals 9

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string v1, "EasMediaCenterAPIImpl"

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "updateCollectMsg type = "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "operation = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " uuid = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " resultCode = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " message = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    move-object v3, p1

    check-cast v3, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move v4, p2

    move v5, p3

    move-object v6, p4

    move v7, p5

    move-object v8, p6

    invoke-interface/range {v2 .. v8}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCollectMsgByUUID(Lecarx/xsf/mediacenter/IMediaCenterClientToken;IILjava/lang/String;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "updateCollectMsg, but unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final updateCollectMsg(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 3

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const-string v1, "EasMediaCenterAPIImpl"

    if-eqz v0, :cond_0

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "updateCollectMsg resultCode = "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " message = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCollectMsg(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void

    :cond_0
    const-string p1, "updateCollectMsg, but unbind media center service"

    invoke-static {v1, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/ecarx/eas/sdk/mediacenter/exception/a;

    invoke-direct {p1}, Lcom/ecarx/eas/sdk/mediacenter/exception/a;-><init>()V

    throw p1
.end method

.method public final updateCurrentLyric(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentLyric(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateCurrentPlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;)V"
        }
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p3}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object p3

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updatePlaylist(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/util/List;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateCurrentProgress(Ljava/lang/Object;J)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentProgress(Lecarx/xsf/mediacenter/IMediaCenterClientToken;J)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateCurrentRecommendInfo(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)Z
    .locals 3

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/o;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/o;-><init>(Lcom/ecarx/eas/sdk/mediacenter/RecommendInfo;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentRecommendInfo(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IRecommend;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateCurrentSourceType(Ljava/lang/Object;I)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateCurrentSourceType(Lecarx/xsf/mediacenter/IMediaCenterClientToken;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateErrorMsg(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateErrorMsg(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final updateErrorStateAndPendingIntent(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)V
    .locals 6

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    move-object v1, p1

    check-cast v1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    move-object v0, p0

    move v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    invoke-direct/range {v0 .. v5}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;IILjava/lang/String;Landroid/app/PendingIntent;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public final updateMediaContent(Ljava/lang/Object;Ljava/util/List;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/ContentInfo;",
            ">;)Z"
        }
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->convertToIContent(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaContent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/util/List;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return v1
.end method

.method public final updateMediaContentTypeList(Ljava/lang/Object;Ljava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaContentTypeList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/util/List;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public final updateMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)V
    .locals 5

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    move-object v1, p1

    check-cast v1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-virtual {p2}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getSourceType()I

    move-result v2

    invoke-virtual {p2}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaListType()I

    move-result v3

    invoke-virtual {p2}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;->getMediaList()Ljava/util/List;

    move-result-object v4

    invoke-static {v4}, Lcom/ecarx/eas/sdk/mediacenter/d;->b(Ljava/util/List;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v0, v1, v2, v3, v4}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;IILjava/util/List;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p2}, Lcom/ecarx/eas/sdk/mediacenter/CommercialInfoHelper;->getIMediaList(Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;)Lecarx/xsf/mediacenter/IMediaList;

    move-result-object p2

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaPlayList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMediaList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method public final updateMediaSourceTypeList(Ljava/lang/Object;[I)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {v0, p1, p2}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMediaSourceTypeList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_0
    const/4 p1, 0x1

    return p1
.end method

.method public final updateMultiMediaList(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z
    .locals 2

    const-string v0, "EasMediaCenterAPIImpl"

    const-string v1, "updateMultiMediaList"

    invoke-static {v0, v1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->d:Lcom/ecarx/eas/xsf/mediacenter/IExCallback;

    if-nez v1, :cond_0

    const-string p1, "unbind media center service"

    invoke-static {v0, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MediaListsInfo;)Z

    move-result p1

    return p1
.end method

.method public final updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)Z
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/m;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/m;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IMusicPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMusicPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateMusicPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)Z
    .locals 2

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/m;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/m;-><init>(Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateMusicPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1
.end method

.method public final updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)Z
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/l;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/l;-><init>(Lcom/ecarx/eas/sdk/mediacenter/INewsPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateNewsPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/INewsPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updateNewsPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/l;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/l;-><init>(Lcom/ecarx/eas/sdk/mediacenter/NewsPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateNewsPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/INewsPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updatePlaylist(Ljava/lang/Object;ILjava/util/List;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "I",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/IMediaInfo;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-static {p3}, Lcom/ecarx/eas/sdk/mediacenter/d;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p3

    invoke-interface {v0, p1, p2, p3}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updatePlaylist(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/util/List;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method

.method public final updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)Z
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/q;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/q;-><init>(Lcom/ecarx/eas/sdk/mediacenter/IVideoPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateVideoPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IVideoPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updateVideoPlaybackState(Ljava/lang/Object;Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)Z
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    if-nez v0, :cond_0

    const-string p1, "EasMediaCenterAPIImpl"

    const-string p2, "unbind media center service"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 p1, 0x0

    return p1

    :cond_0
    :try_start_0
    new-instance v0, Lcom/ecarx/eas/sdk/mediacenter/q;

    invoke-direct {v0, p2}, Lcom/ecarx/eas/sdk/mediacenter/q;-><init>(Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;)V

    iget-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/a;->b:Lecarx/xsf/mediacenter/IMediaCenterSvc;

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p2, p1, v0}, Lecarx/xsf/mediacenter/IMediaCenterSvc;->updateVideoPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IVideoPlaybackInfo;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public final updateZoneId(Ljava/lang/Object;I)V
    .locals 1

    invoke-static {p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/IApi;->mService:Landroid/os/IInterface;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    check-cast p1, Lecarx/xsf/mediacenter/IMediaCenterClientToken;

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    const-string v0, "updateZoneId"

    invoke-direct {p0, v0, p2, p1}, Lcom/ecarx/eas/sdk/mediacenter/a;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;)Ljava/lang/String;

    return-void
.end method
