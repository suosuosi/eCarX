.class public final Lcom/ecarx/eas/sdk/mediacenter/control/a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControlClientAPI;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/sdk/mediacenter/control/a$a;
    }
.end annotation


# instance fields
.field private a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(B)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/control/a;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static a()Lcom/ecarx/eas/sdk/mediacenter/control/a;
    .locals 1

    invoke-static {}, Lcom/ecarx/eas/sdk/mediacenter/control/a$a;->a()Lcom/ecarx/eas/sdk/mediacenter/control/a;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a(Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;)Lcom/ecarx/eas/sdk/mediacenter/control/a;
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    return-object p0
.end method

.method public final register(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControlClientAPIImpl"

    const-string p2, "Please setApiSvc first"

    invoke-static {p1, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :cond_0
    :try_start_0
    new-instance v2, Lcom/ecarx/eas/sdk/mediacenter/control/b;

    invoke-direct {v2, p2}, Lcom/ecarx/eas/sdk/mediacenter/control/b;-><init>(Lcom/ecarx/eas/sdk/mediacenter/control/MediaControlClient;)V

    invoke-interface {v0, p1, v2}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;->register(Ljava/lang/String;Lecarx/xsf/mediacenter/control/IMediaControlClient;)Lecarx/xsf/mediacenter/control/IMediaControlClientToken;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final requestControlled(Ljava/lang/Object;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControlClientAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControlClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;->requestControlled(Lecarx/xsf/mediacenter/control/IMediaControlClientToken;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method

.method public final unregister(Ljava/lang/Object;)Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/control/a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string p1, "ControlClientAPIImpl"

    const-string v0, "Please setApiSvc first"

    invoke-static {p1, v0}, Lcom/ecarx/eas/sdk/mediacenter/control/a;->INVOKESTATIC_com_ecarx_eas_sdk_mediacenter_control_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_0
    :try_start_0
    check-cast p1, Lecarx/xsf/mediacenter/control/IMediaControlClientToken;

    invoke-interface {v0, p1}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;->unregister(Lecarx/xsf/mediacenter/control/IMediaControlClientToken;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return v1
.end method
