.class public abstract Lcom/ecarx/eas/sdk/mediacenter/exception/MediaCenterException;
.super Ljava/lang/Exception;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    return-void
.end method
