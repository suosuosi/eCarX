.class public Lcom/ecarx/eas/sdk/mediacenter/a/c;
.super Lecarx/xsf/mediacenter/vr/IMusicIntentObserver$Stub;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lecarx/xsf/mediacenter/vr/IMusicIntentObserver$Stub;-><init>()V

    return-void
.end method


# virtual methods
.method public handleCtrlApp(I)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public handleCtrlMediaClient(II)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public handlePlayMusic(Lecarx/xsf/mediacenter/vr/QMusicResult;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public handleSearchMusic(Lecarx/xsf/mediacenter/vr/QMusicResult;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method
