.class final Lcom/ecarx/eas/sdk/mediacenter/e$4;
.super Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V
    .locals 0

    iput-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MusicPlaybackInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public final getAlbum()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getAlbum()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getAppIcon()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getAppIcon()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getAppName()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getAppName()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getArtist()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getArtist()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getArtwork()Landroid/net/Uri;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getArtwork()Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getCurrentLyricSentence()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getCurrentLyricSentence()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getDuration()J
    .locals 2

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getDuration()J

    move-result-wide v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-wide v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public final getLaunchIntent()Landroid/app/PendingIntent;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLaunchIntent()Landroid/app/PendingIntent;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getLoopMode()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLoopMode()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final getLyric()Landroid/net/Uri;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLyric()Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getLyricContent()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getLyricContent()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getMediaPath()Landroid/net/Uri;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getMediaPath()Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getNextArtwork()Landroid/net/Uri;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getNextArtwork()Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPackageName()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPackageName()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPlaybackStatus()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlaybackStatus()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final getPlayerIntent()Landroid/app/PendingIntent;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayerIntent()Landroid/app/PendingIntent;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPlayingItemPositionInQueue()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayingItemPositionInQueue()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final getPlayingMediaListId()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayingMediaListId()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getPlayingMediaListType()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPlayingMediaListType()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, -0x1

    return v0
.end method

.method public final getPreviousArtwork()Landroid/net/Uri;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getPreviousArtwork()Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getRadioFrequency()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getRadioFrequency()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getRadioMode()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getRadioMode()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final getRadioStationName()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getRadioStationName()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getSourceType()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getSourceType()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getTitle()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getUuid()Ljava/lang/String;
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getUuid()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getVip()I
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->getVip()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final isCollected()Z
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isCollected()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final isDownloaded()Z
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isDownloaded()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final isSupportCollect()Z
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isSupportCollect()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final isSupportDownload()Z
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isSupportDownload()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final isSupportLoopModeSwitch()Z
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isSupportLoopModeSwitch()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public final isSupportVrCtrlPlayStatus()Z
    .locals 1

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$4;->a:Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    invoke-interface {v0}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo;->isSupportVrCtrlPlayStatus()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method
