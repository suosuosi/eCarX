.class public Lcom/ecarx/eas/sdk/mediacenter/RecoveryIntentType;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final INTENT_TYPE_BROADCAST:I = 0x1

.field public static final INTENT_TYPE_SERVICE:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
