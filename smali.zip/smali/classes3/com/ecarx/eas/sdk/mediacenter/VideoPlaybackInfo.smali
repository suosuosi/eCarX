.class public Lcom/ecarx/eas/sdk/mediacenter/VideoPlaybackInfo;
.super Lcom/ecarx/eas/sdk/mediacenter/AbstractVideoPlaybackInfo;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/AbstractVideoPlaybackInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public getPlaybackStatus()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isCollected()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isDownloaded()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isSupportCollect()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isSupportDownload()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public isSupportVrCtrlPlayStatus()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method
