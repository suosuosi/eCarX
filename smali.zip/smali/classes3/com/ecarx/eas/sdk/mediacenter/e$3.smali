.class final Lcom/ecarx/eas/sdk/mediacenter/e$3;
.super Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ecarx/eas/sdk/mediacenter/e;->a(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/sdk/mediacenter/e;Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)V
    .locals 0

    iput-object p2, p0, Lcom/ecarx/eas/sdk/mediacenter/e$3;->a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    invoke-direct {p0}, Lcom/ecarx/eas/sdk/mediacenter/MediaListInfo;-><init>()V

    return-void
.end method


# virtual methods
.method public final getMediaList()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/MediaInfo;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$3;->a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;->getMediaList()Ljava/util/List;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0

    :cond_1
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lecarx/xsf/mediacenter/IMedia;

    new-instance v3, Lcom/ecarx/eas/sdk/mediacenter/e$3$1;

    invoke-direct {v3, p0, v2}, Lcom/ecarx/eas/sdk/mediacenter/e$3$1;-><init>(Lcom/ecarx/eas/sdk/mediacenter/e$3;Lecarx/xsf/mediacenter/IMedia;)V

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    return-object v1
.end method

.method public final getMediaListId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$3;->a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;->getMediaListId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final getMediaListType()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$3;->a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;->getMediaListType()I

    move-result v0

    return v0
.end method

.method public final getSourceType()I
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$3;->a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;->getSourceType()I

    move-result v0

    return v0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/sdk/mediacenter/e$3;->a:Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;->getTitle()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
