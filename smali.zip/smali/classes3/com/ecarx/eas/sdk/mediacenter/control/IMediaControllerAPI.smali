.class public interface abstract Lcom/ecarx/eas/sdk/mediacenter/control/IMediaControllerAPI;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract getMediaContentTypeList(Ljava/lang/Object;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getMediaList(Ljava/lang/Object;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/List<",
            "Lcom/ecarx/eas/sdk/mediacenter/control/bean/Media;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getMusicPlaybackInfo(Ljava/lang/Object;)Lcom/ecarx/eas/sdk/mediacenter/control/bean/MusicPlaybackInfo;
.end method

.method public abstract getSourceType(Ljava/lang/Object;)I
.end method

.method public abstract playCtlPlay(Ljava/lang/Object;ILjava/lang/String;)Z
.end method

.method public abstract playCtrlPause(Ljava/lang/Object;)Z
.end method

.method public abstract playCtrlPause(Ljava/lang/Object;I)Z
.end method

.method public abstract playCtrlPlay(Ljava/lang/Object;)Z
.end method

.method public abstract playCtrlPlayByContent(Ljava/lang/Object;ILjava/lang/String;)Z
.end method

.method public abstract playCtrlPlayByMediaID(Ljava/lang/Object;ILjava/lang/String;)Z
.end method

.method public abstract register(Ljava/lang/String;Lcom/ecarx/eas/sdk/mediacenter/control/MediaController;)Ljava/lang/Object;
.end method

.method public abstract requestControl(Ljava/lang/Object;)Z
.end method

.method public abstract unregister(Ljava/lang/Object;)Z
.end method
