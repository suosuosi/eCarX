.class Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient$1_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$000(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$100(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method

.method public final a(Ljava/lang/String;)V
    .locals 3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "onServiceConnected() service = "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "EASFramework"

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient$1_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v2, 0x5

    invoke-virtual {v0, v2, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iput-object p1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method

.method public final b()V
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v2, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .locals 2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iput-object p1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method

.method public final c()V
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    invoke-static {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method
