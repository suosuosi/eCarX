.class public interface abstract Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract onCall(Lcom/ecarx/sdk/openapi/msg/EASFrameworkRemoteCallbackMessage;)V
.end method
