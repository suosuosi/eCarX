.class final Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;
.super Lcom/ecarx/eas/framework/sdk/common/internal/remote/a;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/a;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->a(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->b(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->a(Ljava/lang/String;)V

    return-void
.end method

.method public final a(Ljava/lang/String;I)V
    .locals 0

    iget-object p2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-static {p2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->c(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    move-result-object p2

    if-nez p2, :cond_0

    return-void

    :cond_0
    iget-object p2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-static {p2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->d(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    move-result-object p2

    invoke-interface {p2, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->b(Ljava/lang/String;)V

    return-void
.end method
