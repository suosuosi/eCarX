.class public final Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;,
        Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;,
        Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;
    }
.end annotation


# static fields
.field private static final MAX_CONNECT_TWICE:I = 0x1e

.field private static final RECONNECT_DELAY:I = 0x3e8

.field private static final STATUS_BINDED_SUCCESS:I = 0x1

.field private static final STATUS_INITING:I = 0x0

.field private static final STATUS_START:I = -0x1

.field private static gProxy:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;",
            ">;"
        }
    .end annotation
.end field

.field private static mCallbacks:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mConnectionCallbacks:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private volatile mContext:Landroid/content/Context;

.field private final mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/common/internal/a<",
            "*>;"
        }
    .end annotation
.end field

.field private mEASFrameworkIntent:Landroid/content/Intent;

.field private final mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

.field private mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

.field private mOpenAPIIntent:Landroid/content/Intent;

.field private mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

.field private volatile mType:I

.field private mUserUnLockedReceiver:Landroid/content/BroadcastReceiver;

.field private volatile mVersion:I

.field private final noticeH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCallbacks:Ljava/util/Map;

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$1;

    invoke-direct {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$1;-><init>()V

    sput-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->gProxy:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method private constructor <init>()V
    .locals 4
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Landroid/content/Intent;

    const-string v2, "ecarx.intent.action.OpenAPIService"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "com.ecarx.sdk.openapi"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.ecarx.easframework.intent.action.EASFRAMEWORK"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASFrameworkIntent:Landroid/content/Intent;

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$2;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$2;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mUserUnLockedReceiver:Landroid/content/BroadcastReceiver;

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$3;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$3;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    new-instance v0, Landroid/os/HandlerThread;

    const-string v2, "EASFrameworkClientBg"

    const/16 v3, 0xa

    invoke-direct {v0, v2, v3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    new-instance v2, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v2, p0, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;Landroid/os/Looper;)V

    iput-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    const-string v0, "EASFramework"

    const-string v2, "EASFrameworkApiClient()"

    invoke-static {v0, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Landroid/os/HandlerThread;

    const-string v2, "EASFrameworkClientNotice"

    invoke-direct {v0, v2, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    new-instance v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;Landroid/os/Looper;)V

    iput-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->noticeH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    return-void
.end method

.method synthetic constructor <init>(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$1;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKEVIRTUAL_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_sysoptimizer_ReceiverRegisterLancet_registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    .locals 1

    :try_start_0
    invoke-virtual {p0, p1, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-static {}, Lcom/bytedance/sysoptimizer/ReceiverRegisterCrashOptimizer;->fixedOpen()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1, p2}, Lcom/bytedance/sysoptimizer/ReceiverRegisterCrashOptimizer;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :cond_0
    throw p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$002(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method static synthetic access$100(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    return-object p0
.end method

.method static synthetic access$1000(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onServiceConnected(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1100(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onServiceDisconnected(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$200(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    return-object p0
.end method

.method static synthetic access$300(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/a;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    return-object p0
.end method

.method static synthetic access$400(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)Ljava/util/concurrent/atomic/AtomicInteger;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    return-object p0
.end method

.method static synthetic access$500(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->noticeH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    return-object p0
.end method

.method static synthetic access$600(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)Z
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->connectService()Z

    move-result p0

    return p0
.end method

.method static synthetic access$700(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onServiceConnected()V

    return-void
.end method

.method static synthetic access$800(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onServiceDisconnected()V

    return-void
.end method

.method static synthetic access$900(Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onBindingDied()V

    return-void
.end method

.method private connectService()Z
    .locals 10

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_1

    return v2

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASFrameworkIntent:Landroid/content/Intent;

    invoke-virtual {v0, v3}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;->findService(Landroid/content/Intent;)Landroid/content/pm/ServiceInfo;

    move-result-object v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->k()V

    :cond_2
    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/d;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-direct {v0, v1, v2, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/d;-><init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V

    :goto_0
    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b()Z

    move-result v0

    return v0

    :cond_3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x18

    const-wide/16 v4, 0x3e8

    const/16 v6, 0x1e

    const/4 v7, 0x2

    const-string v8, ">> package=%s, action=%s service not found!!!<<"

    const-string v9, "EASFramework"

    if-ge v0, v3, :cond_7

    new-array v0, v7, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASFrameworkIntent:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v1

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASFrameworkIntent:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    invoke-static {v8, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    invoke-virtual {v0, v3}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;->findService(Landroid/content/Intent;)Landroid/content/pm/ServiceInfo;

    move-result-object v0

    if-nez v0, :cond_5

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    if-le v0, v6, :cond_4

    new-array v0, v7, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v1

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    invoke-static {v8, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_4
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    return v1

    :cond_5
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->k()V

    :cond_6
    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/h;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-direct {v0, v1, v2, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/h;-><init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V

    goto :goto_0

    :cond_7
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    const-string v3, "user"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/UserManager;

    invoke-virtual {v0}, Landroid/os/UserManager;->isUserUnlocked()Z

    move-result v0

    if-nez v0, :cond_8

    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.intent.action.USER_UNLOCKED"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x3e8

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->setPriority(I)V

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mUserUnLockedReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mUserUnLockedReceiver:Landroid/content/BroadcastReceiver;

    invoke-static {v1, v3, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKEVIRTUAL_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_sysoptimizer_ReceiverRegisterLancet_registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return v2

    :cond_8
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    invoke-virtual {v0, v3}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;->findService(Landroid/content/Intent;)Landroid/content/pm/ServiceInfo;

    move-result-object v0

    if-nez v0, :cond_a

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    if-le v0, v6, :cond_9

    new-array v0, v7, [Ljava/lang/Object;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v1

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mOpenAPIIntent:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    invoke-static {v8, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_9
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    return v1

    :cond_a
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->k()V

    :cond_b
    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/h;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-direct {v0, v1, v2, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/h;-><init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V

    goto/16 :goto_0
.end method

.method private create(Landroid/content/Context;)V
    .locals 2

    const-class v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    if-eqz v1, :cond_0

    monitor-exit v0

    return-void

    :cond_0
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    goto :goto_0

    :cond_1
    iput-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    :goto_0
    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    invoke-direct {p1, v1}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    monitor-exit v0

    return-void

    :cond_2
    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string v1, "parameter Context must not NULL"

    invoke-direct {p1, v1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public static getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;
    .locals 2

    const-class v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->gProxy:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v1}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private initConnectEASFrameworkSpecifyService(Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)Z
    .locals 6
    .param p2    # Ljava/lang/String;
        .annotation build Lcom/ecarx/eas/sdk/IServiceManager$ServiceName;
        .end annotation
    .end param

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/d;

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    if-nez v0, :cond_0

    return v1

    :cond_0
    const/4 v2, 0x1

    :try_start_1
    new-array v3, v2, [Ljava/lang/String;

    aput-object p2, v3, v1

    invoke-interface {v0, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->a([Ljava/lang/String;)V

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->getAvailableEASServices()Ljava/util/List;

    move-result-object v3
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_2

    const-string v4, "EASFramework"

    if-nez v3, :cond_1

    new-array p1, v1, [Ljava/lang/Object;

    const-string p2, "getAvailableEASServices() is NULL!!!"

    invoke-static {p2, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_1
    invoke-interface {v3, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    new-array v3, v2, [Ljava/lang/Object;

    aput-object p2, v3, v1

    const-string v5, "getAvailableEASServices() not Contain  %s!!!"

    invoke-static {v5, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    :try_start_2
    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->getAvailableServices()Ljava/util/List;

    move-result-object v3
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_0

    :catch_0
    move-exception v5

    invoke-virtual {v5}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_0
    if-eqz v3, :cond_2

    invoke-interface {v3, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    return v1

    :cond_2
    invoke-virtual {p0, p2, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;

    move-result-object v0

    new-instance v3, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v3, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    if-eqz p3, :cond_5

    if-eqz v0, :cond_4

    iget-object v5, v0, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    if-eqz v5, :cond_4

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    goto :goto_2

    :cond_3
    iget-object v5, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v5}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v5

    invoke-interface {p3, p2, v5, v0, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;Z)Z

    move-result p3

    invoke-virtual {v3, p3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object p3, v0, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->name:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_5

    iget-object p3, v0, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_1
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;

    invoke-direct {p0, v0, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->printLogVersionInfo(Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;Ljava/lang/String;)V

    goto :goto_1

    :cond_4
    :goto_2
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    invoke-interface {p3, p2, v0, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z

    move-result p3

    invoke-virtual {v3, p3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_5
    :try_start_3
    const-string p3, ">> onAPIReady(%s, %s) <<"

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    aput-object p2, v0, v1

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    aput-object p2, v0, v2

    invoke-static {p3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v4, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p2

    invoke-interface {p1, p2}, Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;->onAPIReady(Z)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto :goto_3

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    const-string p2, "1Notify Module API [%s] is Fail,  because Module API interanl error!!!"

    invoke-static {v4, p2, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_3
    return v2

    :catch_2
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1

    :catch_3
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return v1

    :catch_4
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/NullPointerException;->printStackTrace()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return v1

    :catch_5
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return v1
.end method

.method private initConnectOpenAPISpecifyService(Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)Z
    .locals 5
    .param p2    # Ljava/lang/String;
        .annotation build Lcom/ecarx/eas/sdk/IServiceManager$ServiceName;
        .end annotation
    .end param

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/h;

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-nez v0, :cond_0

    return v1

    :cond_0
    :try_start_1
    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;->getAvailableServices()Ljava/util/List;

    move-result-object v0
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    const-string v2, "EASFramework"

    if-nez v0, :cond_1

    new-array p1, v1, [Ljava/lang/Object;

    const-string p2, "getAvailableServices() is NULL!!!"

    invoke-static {p2, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return v1

    :cond_1
    invoke-interface {v0, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    if-nez v0, :cond_2

    new-array v0, v3, [Ljava/lang/Object;

    aput-object p2, v0, v1

    const-string v4, "getAvailableServices() not Contain  %s!!!"

    invoke-static {v4, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    if-eqz p3, :cond_3

    iget-object v4, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v4}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v4

    invoke-interface {p3, p2, v4, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z

    move-result p3

    invoke-virtual {v0, p3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_3
    :try_start_2
    const-string p3, ">> onAPIReady(%s, %s) <<"

    const/4 v4, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    aput-object p2, v4, v1

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    aput-object p2, v4, v3

    invoke-static {p3, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-static {v2, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p2

    invoke-interface {p1, p2}, Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;->onAPIReady(Z)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    const-string p2, "Notify Module API [%s] is Fail,  because Module API interanl error!!!"

    invoke-static {v2, p2, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    return v3

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v1

    :catch_2
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return v1

    :catch_3
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/NullPointerException;->printStackTrace()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return v1

    :catch_4
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return v1
.end method

.method private noticeClient(Ljava/lang/String;Z)V
    .locals 7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "EASFramework"

    if-nez v1, :cond_2

    new-array v1, v3, [Ljava/lang/Object;

    aput-object p1, v1, v2

    const-string v2, ">> Moudle [%s] \'s ECarXApiClient.Callback is NULL!!! <<"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_2
    :try_start_0
    const-string v5, ">> onAPIReady(%s, %s) <<"

    const/4 v6, 0x2

    new-array v6, v6, [Ljava/lang/Object;

    aput-object p1, v6, v2

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    aput-object v2, v6, v3

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-interface {v1, p2}, Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;->onAPIReady(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    const-string v2, "4Notify Module API [%s] is Fail,  because Module API interanl error!!!"

    invoke-static {v4, v2, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :cond_3
    return-void
.end method

.method private onBindingDied()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onServiceDisconnected()V

    return-void
.end method

.method private onEASFrameworkServiceConnected(Lcom/ecarx/eas/framework/sdk/common/internal/d;)V
    .locals 10

    :try_start_0
    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object p1

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3

    if-nez p1, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    :try_start_1
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    new-array v2, v0, [Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    invoke-interface {p1, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->a([Ljava/lang/String;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_0
    const/4 v1, 0x0

    :try_start_2
    invoke-interface {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->getAvailableEASServices()Ljava/util/List;

    move-result-object v2
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception v2

    invoke-virtual {v2}, Landroid/os/RemoteException;->printStackTrace()V

    move-object v2, v1

    :goto_1
    if-eqz v2, :cond_1

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2

    :cond_1
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    :cond_2
    :try_start_3
    invoke-interface {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->getAvailableServices()Ljava/util/List;

    move-result-object v1
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_2

    :catch_2
    move-exception v3

    invoke-virtual {v3}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_2
    if-eqz v1, :cond_4

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_4

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_3
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_4
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_5
    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "ServiceName="

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "EASFramework"

    invoke-static {v6, v5}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-interface {v2, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_6

    const-string v3, "\u8be5\u670d\u52a1\u8fd8\u672a\u542f\u52a8"

    invoke-static {v6, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_4

    :cond_6
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    if-eqz v3, :cond_5

    invoke-virtual {p0, v4, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;

    move-result-object v5

    new-instance v7, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v7, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/4 v8, 0x1

    if-eqz v5, :cond_8

    iget-object v9, v5, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    if-eqz v9, :cond_8

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_7

    goto :goto_6

    :cond_7
    iget-object v9, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v9}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v9

    invoke-interface {v3, v4, v9, v5, v8}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;Z)Z

    move-result v3

    invoke-virtual {v7, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v3, v5, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->name:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9

    iget-object v3, v5, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_9

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;

    invoke-direct {p0, v5, v4}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->printLogVersionInfo(Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;Ljava/lang/String;)V

    goto :goto_5

    :cond_8
    :goto_6
    const-string v5, "VersionInfo is NULL"

    invoke-static {v6, v5}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v5, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v5}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v5

    invoke-interface {v3, v4, v5, v8}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z

    move-result v3

    invoke-virtual {v7, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_9
    new-array v3, v8, [Ljava/lang/Object;

    aput-object v4, v3, v0

    const-string v5, ">> Moudle [%s] \'s noticeClient V4 <<"

    invoke-static {v5, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    invoke-direct {p0, v4, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->noticeClient(Ljava/lang/String;Z)V

    goto/16 :goto_4

    :cond_a
    return-void

    :catch_3
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void

    :catch_4
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    return-void
.end method

.method private onOpenAPIServiceConnected(Lcom/ecarx/eas/framework/sdk/common/internal/h;)V
    .locals 7

    :try_start_0
    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object p1

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez p1, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    :try_start_1
    invoke-interface {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;->getAvailableServices()Ljava/util/List;

    move-result-object v0
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_0
    if-eqz v0, :cond_3

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_2

    :cond_1
    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_2
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    if-eqz v1, :cond_2

    new-instance v3, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x0

    invoke-direct {v3, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iget-object v5, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v5}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v5

    const/4 v6, 0x1

    invoke-interface {v1, v2, v5, v6}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z

    move-result v1

    invoke-virtual {v3, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    new-array v1, v6, [Ljava/lang/Object;

    aput-object v2, v1, v4

    const-string v4, ">> Moudle [%s] \'s noticeClient V3  <<"

    invoke-static {v4, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v4, "EASFramework"

    invoke-static {v4, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    invoke-direct {p0, v2, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->noticeClient(Ljava/lang/String;Z)V

    goto :goto_1

    :catch_1
    :cond_3
    :goto_2
    return-void

    :catch_2
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    return-void
.end method

.method private onServiceConnected()V
    .locals 6

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c()Z

    move-result v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    if-nez v0, :cond_2

    return-void

    :cond_2
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    const/4 v2, 0x0

    if-eqz v1, :cond_5

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v3, 0x0

    :try_start_0
    const-string v4, "com.ecarx.sdk.openapi"

    const/16 v5, 0x80

    invoke-virtual {v1, v4, v5}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Landroid/content/pm/PackageManager$NameNotFoundException;->printStackTrace()V

    move-object v1, v3

    :goto_0
    if-eqz v1, :cond_3

    iget-object v3, v1, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    :cond_3
    if-eqz v3, :cond_4

    const-string v1, "com.ecarx.sdk.openapi.version"

    invoke-virtual {v3, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-virtual {v3, v1, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mVersion:I

    :cond_4
    if-eqz v3, :cond_5

    const-string v1, "com.ecarx.sdk.openapi.type"

    invoke-virtual {v3, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-virtual {v3, v1, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mType:I

    :cond_5
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->l()V

    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-ne v1, v0, :cond_6

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/h;

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onOpenAPIServiceConnected(Lcom/ecarx/eas/framework/sdk/common/internal/h;)V

    return-void

    :cond_6
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-ne v1, v0, :cond_7

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/d;

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->onEASFrameworkServiceConnected(Lcom/ecarx/eas/framework/sdk/common/internal/d;)V

    return-void

    :cond_7
    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Enum;->toString()Ljava/lang/String;

    move-result-object v0

    aput-object v0, v1, v2

    const-string v0, ">> \u5f02\u5e38\u7684ClientType = %s <<"

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "EASFramework"

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private onServiceConnected(Ljava/lang/String;)V
    .locals 19

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    iget-object v0, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    if-eqz v0, :cond_d

    invoke-static/range {p1 .. p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_1

    goto/16 :goto_6

    :cond_1
    sget-object v3, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    return-void

    :cond_2
    sget-object v3, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    if-nez v3, :cond_3

    return-void

    :cond_3
    new-instance v4, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x0

    invoke-direct {v4, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sget-object v6, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    const/4 v7, 0x0

    if-ne v0, v6, :cond_4

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    move-object v2, v0

    invoke-virtual {v2}, Landroid/os/DeadObjectException;->printStackTrace()V

    return-void

    :cond_4
    move-object v0, v7

    :goto_0
    if-nez v0, :cond_5

    return-void

    :cond_5
    iget v6, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mType:I

    const/4 v8, 0x2

    const-string v9, "EASFramework"

    const/4 v10, 0x1

    if-ne v6, v10, :cond_6

    iget v6, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mVersion:I

    if-gez v6, :cond_7

    :cond_6
    iget v6, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mType:I

    if-nez v6, :cond_9

    iget v6, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mVersion:I

    if-le v6, v8, :cond_9

    :cond_7
    new-instance v6, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/StrMsg;

    invoke-direct {v6}, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/StrMsg;-><init>()V

    iput-object v2, v6, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/StrMsg;->param:Ljava/lang/String;

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v11

    invoke-virtual {v6, v11, v5}, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/AutoSafeParcelable;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-virtual {v11}, Landroid/os/Parcel;->marshall()[B

    move-result-object v16

    new-instance v6, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    new-array v15, v5, [B

    const-string v13, "eascore"

    const-string v14, "master"

    const-string v17, "getEasServiceInfo"

    move-object v12, v6

    move-object/from16 v18, v15

    move-object/from16 v15, v17

    move-object/from16 v17, v18

    invoke-direct/range {v12 .. v17}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    :try_start_1
    invoke-interface {v0, v6}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->call(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;

    move-result-object v0

    iget v6, v0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mCode:I

    const/16 v12, 0xc8

    if-ne v6, v12, :cond_8

    iget-object v6, v0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mRetMsg:Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    if-eqz v6, :cond_8

    iget v13, v6, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    if-ne v13, v12, :cond_8

    iget-object v6, v6, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    if-eqz v6, :cond_8

    invoke-virtual {v11}, Landroid/os/Parcel;->recycle()V

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v11

    iget-object v0, v0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mRetMsg:Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    iget-object v0, v0, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    array-length v6, v0

    invoke-virtual {v11, v0, v5, v6}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {v11, v5}, Landroid/os/Parcel;->setDataPosition(I)V

    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v0, v11}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v7, v0

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    :catch_1
    move-exception v0

    :try_start_2
    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-static {v9, v6, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_8
    :goto_1
    invoke-virtual {v11}, Landroid/os/Parcel;->recycle()V

    goto :goto_3

    :goto_2
    invoke-virtual {v11}, Landroid/os/Parcel;->recycle()V

    throw v0

    :cond_9
    :goto_3
    if-eqz v7, :cond_b

    iget-object v0, v7, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    if-eqz v0, :cond_b

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a

    goto :goto_5

    :cond_a
    iget-object v0, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    invoke-interface {v3, v2, v0, v7, v10}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;Z)Z

    move-result v0

    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v0, v7, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->name:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    iget-object v0, v7, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->versionInfos:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;

    invoke-direct {v1, v3, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->printLogVersionInfo(Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;Ljava/lang/String;)V

    goto :goto_4

    :cond_b
    :goto_5
    const-string v0, "VersionInfo is NULL"

    invoke-static {v9, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    invoke-interface {v3, v2, v0, v10}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z

    move-result v0

    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_c
    new-array v0, v8, [Ljava/lang/Object;

    aput-object v2, v0, v5

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v10

    const-string v3, ">> onServiceConnected(String serviceName) onAPIReady(%s, %s) <<"

    invoke-static {v3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    new-array v0, v10, [Ljava/lang/Object;

    aput-object v2, v0, v5

    const-string v3, ">> Moudle [%s] \'s noticeClient start <<"

    invoke-static {v3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    invoke-direct {v1, v2, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->noticeClient(Ljava/lang/String;Z)V

    :cond_d
    :goto_6
    return-void
.end method

.method private onServiceDisconnected()V
    .locals 6

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    if-eqz v2, :cond_2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_2

    :try_start_0
    invoke-interface {v2, v4, v0, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v2

    invoke-virtual {v2}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_0

    :cond_3
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    if-eqz v0, :cond_4

    const-string v0, "EASFramework"

    const-string v1, "hasMessages(H.SERVICE_CONNECT_TODO)"

    invoke-static {v0, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_4
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method

.method private onServiceDisconnected(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return-void

    :cond_2
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;

    if-nez v1, :cond_3

    return-void

    :cond_3
    const/4 v2, 0x0

    :try_start_0
    invoke-interface {v1, p1, v0, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;Z)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_4
    :goto_0
    return-void
.end method

.method private printLogVersionInfo(Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;Ljava/lang/String;)V
    .locals 2

    if-eqz p1, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "service name \uff1a "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "\n OpenAPI Version=4.6.6(29095f1)"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "\n type="

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;->type:I

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "\n service Version : "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p2, p1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;->versionCode:I

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "\n service VersionName : "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/VersionInfo;->versionName:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\n EAS core Version : "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->geCoreServiceVersionCode()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "EASFramework"

    invoke-static {p2, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void
.end method


# virtual methods
.method public final geCoreServiceVersionCode()Ljava/lang/String;
    .locals 8

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    const-string v1, "-1"

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    const-string v0, "content://com.ecarx.sdk.openapi.contentprovider/core_service_version_code"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const/4 v0, 0x0

    :try_start_0
    const-string v4, "id"

    filled-new-array {v4}, [Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, 0x0

    invoke-interface {v0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    if-eqz v0, :cond_2

    invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z

    move-result v2

    if-nez v2, :cond_2

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    :cond_2
    return-object v1

    :catchall_0
    move-exception v1

    if-eqz v0, :cond_3

    invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z

    move-result v2

    if-nez v2, :cond_3

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    :cond_3
    throw v1

    :catch_0
    if-eqz v0, :cond_4

    invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z

    move-result v2

    if-nez v2, :cond_4

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    :cond_4
    return-object v1
.end method

.method public final getAppContext()Landroid/content/Context;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public final getEASServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e()Z

    move-result v0

    if-eqz v0, :cond_1

    return-object v1

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_2

    return-object v1

    :cond_2
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    sget-object v2, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-eq v0, v2, :cond_3

    return-object v1

    :cond_3
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/d;

    :try_start_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final getServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e()Z

    move-result v0

    if-eqz v0, :cond_1

    return-object v1

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_2

    return-object v1

    :cond_2
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v0

    sget-object v2, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-eq v0, v2, :cond_3

    return-object v1

    :cond_3
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/h;

    :try_start_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;
    .locals 9

    const/4 v0, 0x0

    if-nez p2, :cond_0

    return-object v0

    :cond_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    return-object v0

    :cond_1
    iget v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mType:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_2

    iget v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mVersion:I

    if-gtz v1, :cond_3

    :cond_2
    iget v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mType:I

    if-nez v1, :cond_5

    iget v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mVersion:I

    const/4 v2, 0x2

    if-le v1, v2, :cond_5

    :cond_3
    new-instance v1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/StrMsg;

    invoke-direct {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/StrMsg;-><init>()V

    iput-object p1, v1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/StrMsg;->param:Ljava/lang/String;

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object p1

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/AutoSafeParcelable;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-virtual {p1}, Landroid/os/Parcel;->marshall()[B

    move-result-object v7

    new-instance v1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;

    new-array v8, v2, [B

    const-string v4, "eascore"

    const-string v5, "master"

    const-string v6, "getEasServiceInfo"

    move-object v3, v1

    invoke-direct/range {v3 .. v8}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[B[B)V

    :try_start_0
    invoke-interface {p2, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;->call(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessage;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;

    move-result-object p2

    iget v1, p2, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mCode:I

    const/16 v3, 0xc8

    if-ne v1, v3, :cond_4

    iget-object v1, p2, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mRetMsg:Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    if-eqz v1, :cond_4

    iget v4, v1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mCode:I

    if-ne v4, v3, :cond_4

    iget-object v1, v1, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    if-eqz v1, :cond_4

    invoke-virtual {p1}, Landroid/os/Parcel;->recycle()V

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object p1

    iget-object p2, p2, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessage;->mRetMsg:Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;

    iget-object p2, p2, Lcom/ecarx/sdk/openapi/msg/SupportServiceRetMessage;->mData:[B

    array-length v1, p2

    invoke-virtual {p1, p2, v2, v1}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    sget-object p2, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {p2, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/ServiceVersionInfo;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, p2

    :cond_4
    :goto_0
    invoke-virtual {p1}, Landroid/os/Parcel;->recycle()V

    goto :goto_2

    :catchall_0
    move-exception p2

    goto :goto_1

    :catch_0
    move-exception p2

    :try_start_1
    invoke-virtual {p2}, Landroid/os/RemoteException;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :goto_1
    invoke-virtual {p1}, Landroid/os/Parcel;->recycle()V

    throw p2

    :cond_5
    :goto_2
    return-object v0
.end method

.method public final getVersion()I
    .locals 1

    iget v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mVersion:I

    return v0
.end method

.method public final init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)V
    .locals 3
    .param p3    # Ljava/lang/String;
        .annotation build Lcom/ecarx/eas/sdk/IServiceManager$ServiceName;
        .end annotation
    .end param

    :try_start_0
    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->create(Landroid/content/Context;)V
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    const/4 v0, 0x0

    if-eqz p1, :cond_6

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_2

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result p1

    if-eqz p1, :cond_1

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1
    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$4;->a:[I

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget p1, p1, v1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_3

    const/4 v2, 0x2

    if-eq p1, v2, :cond_2

    move p1, v0

    goto :goto_0

    :cond_2
    invoke-direct {p0, p2, p3, p4}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->initConnectEASFrameworkSpecifyService(Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)Z

    move-result p1

    goto :goto_0

    :cond_3
    invoke-direct {p0, p2, p3, p4}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->initConnectOpenAPISpecifyService(Lcom/ecarx/eas/sdk/ECarXApiClient$Callback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$IServiceConnectionCallback;)Z

    move-result p1

    :goto_0
    iget-object p2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {p2}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    move-result-object p2

    sget-object p3, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    if-ne p2, p3, :cond_4

    new-array p2, v1, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object p3

    aput-object p3, p2, v0

    const-string p3, "initConnectOpenAPISpecifyService() = %s"

    invoke-static {p3, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    goto :goto_1

    :cond_4
    new-array p2, v1, [Ljava/lang/Object;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object p3

    aput-object p3, p2, v0

    const-string p3, "initConnectEASFrameworkSpecifyService() = %s"

    invoke-static {p3, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    :goto_1
    const-string p3, "EASFramework"

    if-nez p1, :cond_5

    invoke-static {p3, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_5
    invoke-static {p3, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_EASFrameworkApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_6
    :goto_2
    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->hasMessages(I)Z

    move-result p1

    if-eqz p1, :cond_7

    return-void

    :cond_7
    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$a;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public final isEASFrameworkServiceConnected()Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient;->mEASClient:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c()Z

    move-result v0

    return v0
.end method
