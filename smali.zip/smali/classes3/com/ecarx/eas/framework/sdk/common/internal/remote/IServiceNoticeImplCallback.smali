.class public interface abstract Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;Z)Z
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method
