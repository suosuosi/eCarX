.class public final Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;
    }
.end annotation


# static fields
.field private static gProxy:Lcom/ecarx/eas/framework/sdk/Singleton;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/ecarx/eas/framework/sdk/Singleton<",
            "Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;",
            ">;"
        }
    .end annotation
.end field

.field private static mCallbacks:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static mConnectionCallbacks:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private volatile mContext:Landroid/content/Context;

.field private final mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

.field private mEASFrameworkIntent:Landroid/content/Intent;

.field private final mH:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

.field private mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

.field private mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

.field private remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCallbacks:Ljava/util/Map;

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$2;

    invoke-direct {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$2;-><init>()V

    sput-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->gProxy:Lcom/ecarx/eas/framework/sdk/Singleton;

    return-void
.end method

.method private constructor <init>()V
    .locals 3
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.ecarx.easframework.intent.action.EASFRAMEWORKREMOTE"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "com.ecarx.sdk.openapi"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mEASFrameworkIntent:Landroid/content/Intent;

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "EASFrameworkClientRemoteBg"

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0}, Landroid/os/HandlerThread;->start()V

    new-instance v1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;Landroid/os/Looper;)V

    iput-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    return-void
.end method

.method synthetic constructor <init>(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$1;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1, p2}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->I:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    return-object p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$002(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$003(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    .locals 0

    invoke-static {p0, p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-result p0

    return p0
.end method

.method static synthetic access$100(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Ljava/util/concurrent/atomic/AtomicInteger;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    return-object p0
.end method

.method static synthetic access$200(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mH:Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient$a;

    return-object p0
.end method

.method static synthetic access$400(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->onServiceConnected()V

    return-void
.end method

.method static synthetic access$500(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->onServiceDisconnected()V

    return-void
.end method

.method static synthetic access$600(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;)V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->onBindingDied()V

    return-void
.end method

.method static synthetic access$700(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->onServiceConnected(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$800(Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->onServiceDisconnected(Ljava/lang/String;)V

    return-void
.end method

.method private connectService()Z
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    return v0

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mEASFrameworkIntent:Landroid/content/Intent;

    invoke-virtual {v0, v2}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;->findService(Landroid/content/Intent;)Landroid/content/pm/ServiceInfo;

    move-result-object v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->k()V

    :cond_2
    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mNotifity:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-direct {v0, v1, v2, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;-><init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCurrentServiceTwice:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b()Z

    move-result v0

    return v0

    :cond_3
    const-string v0, "EASFramework"

    const-string v2, "CoreService version is low"

    invoke-static {v0, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v1
.end method

.method private create(Landroid/content/Context;)V
    .locals 2

    const-class v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mContext:Landroid/content/Context;

    if-eqz v1, :cond_0

    monitor-exit v0

    return-void

    :cond_0
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    if-nez v1, :cond_1

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mContext:Landroid/content/Context;

    goto :goto_0

    :cond_1
    iput-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mContext:Landroid/content/Context;

    :goto_0
    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mContext:Landroid/content/Context;

    invoke-direct {p1, v1}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mPackageWrapper:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    monitor-exit v0

    return-void

    :cond_2
    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string v1, "parameter Context must not NULL"

    invoke-direct {p1, v1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception p1

    monitor-exit v0

    throw p1
.end method

.method public static getInstance()Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;
    .locals 2

    const-class v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->gProxy:Lcom/ecarx/eas/framework/sdk/Singleton;

    invoke-virtual {v1}, Lcom/ecarx/eas/framework/sdk/Singleton;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;
    .locals 9

    const/4 v0, 0x0

    if-eqz p2, :cond_2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_2

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    new-instance v8, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;

    const/4 v7, 0x0

    const-string v3, "eascore"

    const-string v4, "master"

    const-string v5, "getRemoteServiceInfo"

    move-object v2, v8

    move-object v6, p1

    invoke-direct/range {v2 .. v7}, Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    invoke-interface {p2, v8, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->asyncCall(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;

    move-result-object p1

    iget p2, p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mCode:I

    const/16 v2, 0xc8

    if-ne p2, v2, :cond_1

    iget-object p1, p1, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mResult:[B

    if-eqz p1, :cond_1

    array-length p2, p1

    const/4 v2, 0x0

    invoke-virtual {v1, p1, v2, p2}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {v1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {p1, v1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, p1

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :catch_0
    move-exception p1

    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_1
    :goto_0
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    return-object v0

    :goto_1
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    throw p1

    :cond_2
    :goto_2
    return-object v0
.end method

.method private initConnectRemoteService(Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;)Z
    .locals 6
    .param p2    # Ljava/lang/String;
        .annotation build Lcom/ecarx/eas/sdk/IServiceManager$ServiceName;
        .end annotation
    .end param

    const/4 v0, 0x0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v1, :cond_0

    return v0

    :cond_0
    const/4 v2, 0x1

    :try_start_1
    new-array v3, v2, [Ljava/lang/String;

    aput-object p2, v3, v0

    invoke-interface {v1, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->a([Ljava/lang/String;)V

    invoke-interface {v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->getRemoteServices()Ljava/util/List;

    move-result-object v3
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    const-string v4, "EASFramework"

    if-eqz v3, :cond_4

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    invoke-direct {p0, p2, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;

    move-result-object v1

    invoke-interface {p3, p2, v1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;Z)Z

    move-result p3

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, ">> Moudle ["

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "] sdk 215 init result "

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p2, "]<<"

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {v4, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz p1, :cond_3

    if-nez v1, :cond_2

    const-string p2, "not found service"

    invoke-interface {p1, v0, p2}, Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;->onAPIReady(ZLjava/lang/String;)V

    goto :goto_0

    :cond_2
    const-string p2, ""

    invoke-interface {p1, v2, p2}, Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;->onAPIReady(ZLjava/lang/String;)V

    :cond_3
    :goto_0
    return v2

    :cond_4
    :goto_1
    const-string p1, "RemoteServices is NULL!!!"

    invoke-static {v4, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return v0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/RemoteException;->printStackTrace()V

    return v0

    :catch_1
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->connectService()Z

    return v0

    :catch_2
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/NullPointerException;->printStackTrace()V

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->connectService()Z

    return v0

    :catch_3
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->connectService()Z

    return v0
.end method

.method private noticeClient(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;)V
    .locals 7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v4, "EASFramework"

    if-nez v1, :cond_2

    new-array v1, v3, [Ljava/lang/Object;

    aput-object p1, v1, v2

    const-string v2, ">> Moudle [%s] \'s ECarXApiClient.Callback is NULL!!! <<"

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_2
    if-nez p2, :cond_3

    :try_start_0
    const-string v5, ">> onAPIReady(false , %s) <<"

    new-array v3, v3, [Ljava/lang/Object;

    aput-object p1, v3, v2

    invoke-static {v5, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v4, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    const-string v3, "not found service2"

    invoke-interface {v1, v2, v3}, Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;->onAPIReady(ZLjava/lang/String;)V

    goto :goto_0

    :cond_3
    const-string v5, ">> onAPIReady(true, %s)  <<"

    new-array v6, v3, [Ljava/lang/Object;

    aput-object p1, v6, v2

    invoke-static {v5, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    const-string v2, ""

    invoke-interface {v1, v3, v2}, Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;->onAPIReady(ZLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    const-string v2, "4Notify Module API [%s] is Fail,  because Module API interanl error!!!"

    invoke-static {v4, v2, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :cond_4
    return-void
.end method

.method private onBindingDied()V
    .locals 0

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->onServiceDisconnected()V

    return-void
.end method

.method private onServiceConnected()V
    .locals 9

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c()Z

    move-result v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->l()V

    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-nez v0, :cond_2

    return-void

    :cond_2
    :try_start_1
    sget-object v1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->a([Ljava/lang/String;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_0
    const/4 v1, 0x0

    :try_start_2
    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->getRemoteServices()Ljava/util/List;

    move-result-object v1
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception v2

    invoke-virtual {v2}, Landroid/os/RemoteException;->printStackTrace()V

    :goto_1
    const-string v2, "EASFramework"

    if-eqz v1, :cond_7

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_3

    goto :goto_3

    :cond_3
    sget-object v3, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_4
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "ServiceName="

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-interface {v1, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    const-string v4, "service is not start"

    invoke-static {v2, v4}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2

    :cond_5
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;

    if-eqz v4, :cond_4

    invoke-direct {p0, v5, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;

    move-result-object v6

    const/4 v7, 0x1

    invoke-interface {v4, v5, v6, v7}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;Z)Z

    move-result v4

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, ">> Moudle ["

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "] sdk 374 init result "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v4, "]<<"

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-direct {p0, v5, v6}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->noticeClient(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;)V

    goto :goto_2

    :cond_6
    return-void

    :cond_7
    :goto_3
    const-string v0, "Not Found service"

    invoke-static {v2, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :catch_2
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-void

    :catch_3
    move-exception v0

    invoke-virtual {v0}, Landroid/os/DeadObjectException;->printStackTrace()V

    return-void
.end method

.method private onServiceConnected(Ljava/lang/String;)V
    .locals 5

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    const-string v1, "EASFramework"

    if-eqz v0, :cond_4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string p1, "mConnectionCallbacks containsKey == false "

    invoke-static {v1, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_1
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;

    if-nez v0, :cond_2

    return-void

    :cond_2
    :try_start_0
    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v2}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v2

    check-cast v2, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v2, :cond_3

    const-string p1, " ieasFrameworkService == null"

    invoke-static {v1, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_3
    invoke-direct {p0, p1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->getServiceVersionInfo(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;)Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;

    move-result-object v2

    const/4 v3, 0x1

    invoke-interface {v0, p1, v2, v3}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;Z)Z

    move-result v0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, ">> Moudle ["

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "] sdk 444 init result "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v0, "]<<"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-direct {p0, p1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->noticeClient(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;)V

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Landroid/os/DeadObjectException;->printStackTrace()V

    return-void

    :cond_4
    :goto_0
    const-string p1, "onServiceConnected remoteClient == null || serviceName is empty"

    invoke-static {v1, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private onServiceDisconnected()V
    .locals 5

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;

    if-eqz v1, :cond_1

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_1

    const/4 v3, 0x0

    const/4 v4, 0x0

    :try_start_0
    invoke-interface {v1, v2, v3, v4}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;Z)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_3

    return-void

    :cond_3
    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->connectService()Z

    return-void
.end method

.method private onServiceDisconnected(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-eqz v0, :cond_3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;

    if-nez v0, :cond_2

    return-void

    :cond_2
    const/4 v1, 0x0

    const/4 v2, 0x0

    :try_start_0
    invoke-interface {v0, p1, v1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;->onConnected(Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/safeparcel/RemoteDevicesInfo;Z)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void

    :cond_3
    :goto_0
    const-string p1, "EASFramework"

    const-string v0, "onServiceDisconnected remoteClient == null || serviceName is empty"

    invoke-static {p1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_remote_EASFrameworkRemoteApiClient_com_bytedance_auto_lite_lancet_LogLancet_i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method


# virtual methods
.method public final getAppContext()Landroid/content/Context;
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public final getRemoteServiceManager()Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e()Z

    move-result v0

    if-eqz v0, :cond_1

    return-object v1

    :cond_1
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result v0

    if-eqz v0, :cond_2

    return-object v1

    :cond_2
    :try_start_0
    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-object v1
.end method

.method public final init(Landroid/content/Context;Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;)V
    .locals 0
    .param p3    # Ljava/lang/String;
        .annotation build Lcom/ecarx/eas/sdk/IServiceManager$ServiceName;
        .end annotation
    .end param

    :try_start_0
    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->create(Landroid/content/Context;)V
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d()Z

    move-result p1

    if-eqz p1, :cond_1

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_1
    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct {p0, p2, p3, p4}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->initConnectRemoteService(Lcom/ecarx/eas/sdk/ECarXApiClient$RemoteCallback;Ljava/lang/String;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IServiceNoticeImplCallback;)Z

    return-void

    :cond_2
    :goto_0
    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mCallbacks:Ljava/util/Map;

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->mConnectionCallbacks:Ljava/util/Map;

    invoke-interface {p1, p3, p4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->connectService()Z

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    return-void
.end method

.method public final isEASFrameworkRemoteServiceConnected()Z
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/EASFrameworkRemoteApiClient;->remoteClient:Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method
