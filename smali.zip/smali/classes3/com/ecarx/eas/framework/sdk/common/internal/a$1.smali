.class final Lcom/ecarx/eas/framework/sdk/common/internal/a$1;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ecarx/eas/framework/sdk/common/internal/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private synthetic a:Lcom/ecarx/eas/framework/sdk/common/internal/a;


# direct methods
.method constructor <init>(Lcom/ecarx/eas/framework/sdk/common/internal/a;)V
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->D:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$001(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 3

    const-string v0, "EASFrameworkClient"

    const-string v1, "<<<<<<onBindingDied>>>>>> "

    invoke-static {v0, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "onBindingDied ComponentName = "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p1

    const/4 v0, 0x5

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object p1

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;Landroid/os/IInterface;)Landroid/os/IInterface;

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->i()V

    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "<<<<<<onServiceConnected>>>>>> hashCode "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "EASFrameworkClient"

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "onServiceConnected ComponentName = "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p1

    const/4 v0, 0x5

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;Landroid/os/IInterface;)Landroid/os/IInterface;

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->g()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object p1

    const/4 p2, 0x2

    invoke-virtual {p1, p2}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 3

    const-string v0, "EASFrameworkClient"

    const-string v1, "<<<<<<onServiceDisconnected>>>>>> "

    invoke-static {v0, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "onServiceDisconnected ComponentName = "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a$1_com_bytedance_auto_lite_lancet_LogLancet_d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p1

    const/4 v0, 0x5

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object p1

    const/4 v0, 0x3

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Lcom/ecarx/eas/framework/sdk/common/internal/a;Landroid/os/IInterface;)Landroid/os/IInterface;

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-virtual {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->h()V

    iget-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;->a:Lcom/ecarx/eas/framework/sdk/common/internal/a;

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b(Lcom/ecarx/eas/framework/sdk/common/internal/a;)V

    return-void
.end method
