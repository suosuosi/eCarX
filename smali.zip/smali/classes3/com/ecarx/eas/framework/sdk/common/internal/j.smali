.class final Lcom/ecarx/eas/framework/sdk/common/internal/j;
.super Landroid/os/Binder;
.source ""

# interfaces
.implements Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/framework/sdk/common/internal/j$a;
    }
.end annotation


# static fields
.field static a:Ljava/lang/String; = "com.ecarx.sdk.openapi.IServicePool"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/j;->a:Ljava/lang/String;

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    if-eqz v1, :cond_1

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    return-object v0

    :cond_1
    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/j$a;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/j$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method


# virtual methods
.method public final addRemoteServiceCallback(Lcom/ecarx/eas/framework/sdk/common/internal/g;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public final asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method

.method public final getAvailableServices()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    return-object v0
.end method

.method public final getService(IILjava/lang/String;Ljava/lang/String;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final removeRemoteServiceCallback(Lcom/ecarx/eas/framework/sdk/common/internal/g;)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method
