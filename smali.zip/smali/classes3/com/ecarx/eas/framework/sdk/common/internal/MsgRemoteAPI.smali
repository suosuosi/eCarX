.class public abstract Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getBool([B)Z
    .locals 2

    if-eqz p0, :cond_0

    array-length v0, p0

    if-lez v0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/openapi/protobuf/ECARXCommon$BoolMsg;->parseFrom([B)Lcom/ecarx/openapi/protobuf/ECARXCommon$BoolMsg;

    move-result-object p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/proto/InvalidProtocolBufferNanoException; {:try_start_0 .. :try_end_0} :catch_0

    iget-boolean p0, p0, Lcom/ecarx/openapi/protobuf/ECARXCommon$BoolMsg;->value:Z

    return p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    invoke-virtual {p0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    const-string v0, "data is null\uff01\uff01\uff01"

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static getDouble([B)D
    .locals 2

    if-eqz p0, :cond_0

    array-length v0, p0

    if-lez v0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/openapi/protobuf/ECARXCommon$DoubleMsg;->parseFrom([B)Lcom/ecarx/openapi/protobuf/ECARXCommon$DoubleMsg;

    move-result-object p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/proto/InvalidProtocolBufferNanoException; {:try_start_0 .. :try_end_0} :catch_0

    iget-wide v0, p0, Lcom/ecarx/openapi/protobuf/ECARXCommon$DoubleMsg;->value:D

    return-wide v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    invoke-virtual {p0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    const-string v0, "data is null\uff01\uff01\uff01"

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;
    .locals 1

    const/16 v0, 0x1f5

    if-eq p0, v0, :cond_3

    const/16 v0, 0x1f6

    if-eq p0, v0, :cond_2

    const/16 v0, 0x258

    if-eq p0, v0, :cond_1

    const/16 v0, 0x259

    if-eq p0, v0, :cond_0

    packed-switch p0, :pswitch_data_0

    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/UnknownException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/UnknownException;-><init>(Ljava/lang/String;)V

    return-object p0

    :pswitch_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/NotFoundException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/NotFoundException;-><init>(Ljava/lang/String;)V

    return-object p0

    :pswitch_1
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    return-object p0

    :pswitch_2
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/NotSupportedException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/NotSupportedException;-><init>(Ljava/lang/String;)V

    return-object p0

    :pswitch_3
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/UnAuthorizedException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/UnAuthorizedException;-><init>(Ljava/lang/String;)V

    return-object p0

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/a;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/a;-><init>(Ljava/lang/String;)V

    return-object p0

    :cond_1
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;)V

    return-object p0

    :cond_2
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/SupportServerErrorException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/SupportServerErrorException;-><init>(Ljava/lang/String;)V

    return-object p0

    :cond_3
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/NotExistSupportServerException;

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/NotExistSupportServerException;-><init>(Ljava/lang/String;)V

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x191
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static getInt([B)I
    .locals 2

    if-eqz p0, :cond_0

    array-length v0, p0

    if-lez v0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;->parseFrom([B)Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;

    move-result-object p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/proto/InvalidProtocolBufferNanoException; {:try_start_0 .. :try_end_0} :catch_0

    iget p0, p0, Lcom/ecarx/openapi/protobuf/ECARXCommon$IntMsg;->value:I

    return p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    invoke-virtual {p0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    const-string v0, "data is null\uff01\uff01\uff01"

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static getLong([B)J
    .locals 2

    if-eqz p0, :cond_0

    array-length v0, p0

    if-lez v0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/openapi/protobuf/ECARXCommon$LongMsg;->parseFrom([B)Lcom/ecarx/openapi/protobuf/ECARXCommon$LongMsg;

    move-result-object p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/proto/InvalidProtocolBufferNanoException; {:try_start_0 .. :try_end_0} :catch_0

    iget-wide v0, p0, Lcom/ecarx/openapi/protobuf/ECARXCommon$LongMsg;->value:J

    return-wide v0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    invoke-virtual {p0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    const-string v0, "data is null\uff01\uff01\uff01"

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static getString([B)Ljava/lang/String;
    .locals 2

    if-eqz p0, :cond_0

    array-length v0, p0

    if-lez v0, :cond_0

    :try_start_0
    invoke-static {p0}, Lcom/ecarx/openapi/protobuf/ECARXCommon$StringMsg;->parseFrom([B)Lcom/ecarx/openapi/protobuf/ECARXCommon$StringMsg;

    move-result-object p0
    :try_end_0
    .catch Lcom/ecarx/eas/framework/sdk/proto/InvalidProtocolBufferNanoException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object p0, p0, Lcom/ecarx/openapi/protobuf/ECARXCommon$StringMsg;->value:Ljava/lang/String;

    return-object p0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/io/IOException;->printStackTrace()V

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    invoke-virtual {p0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;

    const-string v0, "data is null\uff01\uff01\uff01"

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/exception/ProtoBufException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static sendMsgAndCallback(Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)V
    .locals 0

    if-eqz p0, :cond_4

    if-eqz p1, :cond_3

    if-eqz p2, :cond_2

    :try_start_0
    invoke-interface {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->asyncCall(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;

    move-result-object p0

    if-eqz p0, :cond_1

    iget p1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mCode:I

    const/16 p2, 0xc8

    if-ne p1, p2, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mMsg:Ljava/lang/String;

    invoke-static {p1, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;->getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;

    move-result-object p0

    throw p0

    :cond_1
    const/16 p0, 0x1f6

    const-string p1, "Service\u5f02\u5e38"

    invoke-static {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;->getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;

    move-result-object p0

    throw p0

    :cond_2
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "IEASFrameworkCallbackRemote is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "EASFrameworkMessageRemote is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "IEASFrameworkRemoteService is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/exception/a;

    invoke-virtual {p0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public static sendMsgRegisterListener(Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)Ljava/lang/String;
    .locals 0

    if-eqz p0, :cond_5

    if-eqz p1, :cond_4

    if-eqz p2, :cond_3

    :try_start_0
    invoke-interface {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->registerListener(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;

    move-result-object p0

    if-eqz p0, :cond_2

    iget p1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mCode:I

    const/16 p2, 0xc8

    if-ne p1, p2, :cond_1

    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mResult:[B

    if-eqz p0, :cond_0

    array-length p1, p0

    if-eqz p1, :cond_0

    new-instance p1, Ljava/lang/String;

    invoke-direct {p1, p0}, Ljava/lang/String;-><init>([B)V

    return-object p1

    :cond_0
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/a;

    const-string p1, "mResult is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/a;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mMsg:Ljava/lang/String;

    invoke-static {p1, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;->getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;

    move-result-object p0

    throw p0

    :cond_2
    const/16 p0, 0x1f6

    const-string p1, "Service\u5f02\u5e38"

    invoke-static {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;->getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;

    move-result-object p0

    throw p0

    :cond_3
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "IEASFrameworkCallbackRemote is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "EASFrameworkMessageRemote is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_5
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "IEASFrameworkRemoteService is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/exception/a;

    invoke-virtual {p0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public static sendMsgUnregisterListener(Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Ljava/lang/String;)V
    .locals 1

    if-eqz p0, :cond_4

    if-eqz p1, :cond_3

    :try_start_0
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-interface {p0, p1, p2}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->unregisterListener(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Ljava/lang/String;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;

    move-result-object p0

    if-eqz p0, :cond_1

    iget p1, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mCode:I

    const/16 p2, 0xc8

    if-ne p1, p2, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;->mMsg:Ljava/lang/String;

    invoke-static {p1, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;->getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;

    move-result-object p0

    throw p0

    :cond_1
    const/16 p0, 0x1f6

    const-string p1, "Service\u5f02\u5e38"

    invoke-static {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/MsgRemoteAPI;->getException(ILjava/lang/String;)Lcom/ecarx/eas/framework/sdk/common/exception/EASFrameworkException;

    move-result-object p0

    throw p0

    :cond_2
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "token is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "EASFrameworkMessageRemote is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p0, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;

    const-string p1, "IEASFrameworkRemoteService is null"

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/exception/IllegalArgumentEASException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/exception/a;

    invoke-virtual {p0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2, p0}, Lcom/ecarx/eas/framework/sdk/common/exception/a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method
