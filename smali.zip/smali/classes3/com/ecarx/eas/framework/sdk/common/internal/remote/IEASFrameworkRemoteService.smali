.class public interface abstract Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract a([Ljava/lang/String;)V
.end method

.method public abstract a(Lcom/ecarx/eas/framework/sdk/common/internal/remote/d;)Z
.end method

.method public abstract asyncCall(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract getRemoteServices()Ljava/util/List;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end method

.method public abstract registerListener(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkCallbackRemote;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method

.method public abstract unregisterListener(Lcom/ecarx/sdk/openapi/msg/EASFrameworkMessageRemote;Ljava/lang/String;)Lcom/ecarx/sdk/openapi/msg/EASFrameworkRetMessageRemote;
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation
.end method
