.class final Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;
.super Lcom/ecarx/eas/framework/sdk/common/internal/a;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/a<",
        "Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;",
        ">;"
    }
.end annotation


# instance fields
.field private b:Lcom/ecarx/eas/framework/sdk/common/internal/remote/d;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lcom/ecarx/eas/framework/sdk/common/internal/a;-><init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V

    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;

    invoke-direct {p1, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b$1;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)V

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->b:Lcom/ecarx/eas/framework/sdk/common/internal/remote/d;

    return-void
.end method

.method static synthetic a(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    return-object p0
.end method

.method static synthetic b(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    return-object p0
.end method

.method static synthetic c(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    return-object p0
.end method

.method static synthetic d(Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;)Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    return-object p0
.end method


# virtual methods
.method protected final bridge synthetic a(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 0

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/c;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;

    move-result-object p1

    return-object p1
.end method

.method protected final a()Ljava/lang/String;
    .locals 1

    const-string v0, "com.ecarx.easframework.intent.action.EASFRAMEWORKREMOTE"

    return-object v0
.end method

.method protected final g()V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->a()V

    return-void
.end method

.method protected final h()V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->b()V

    return-void
.end method

.method protected final i()V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->c()V

    return-void
.end method

.method public final j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->EASFramework:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    return-object v0
.end method

.method protected final l()V
    .locals 2

    :try_start_0
    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/remote/b;->b:Lcom/ecarx/eas/framework/sdk/common/internal/remote/d;

    invoke-interface {v0, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/remote/IEASFrameworkRemoteService;->a(Lcom/ecarx/eas/framework/sdk/common/internal/remote/d;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-void

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method
