.class final Lcom/ecarx/eas/framework/sdk/common/internal/e;
.super Landroid/os/Binder;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ecarx/eas/framework/sdk/common/internal/e$a;
    }
.end annotation


# static fields
.field static a:Ljava/lang/String; = "com.ecarx.eas.framework.sdk.IEASFrameworkService"


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/e;->a:Ljava/lang/String;

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    if-eqz v1, :cond_1

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkService;

    return-object v0

    :cond_1
    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/e$a;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/e$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method


# virtual methods
.method public final asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method
