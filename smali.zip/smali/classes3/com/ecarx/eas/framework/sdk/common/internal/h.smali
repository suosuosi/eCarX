.class Lcom/ecarx/eas/framework/sdk/common/internal/h;
.super Lcom/ecarx/eas/framework/sdk/common/internal/a;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/ecarx/eas/framework/sdk/common/internal/a<",
        "Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;",
        ">;"
    }
.end annotation


# instance fields
.field private b:Lcom/ecarx/eas/framework/sdk/common/internal/c;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lcom/ecarx/eas/framework/sdk/common/internal/a;-><init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V

    new-instance p1, Lcom/ecarx/eas/framework/sdk/common/internal/h$1;

    invoke-direct {p1, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/h$1;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/h;)V

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/h;->b:Lcom/ecarx/eas/framework/sdk/common/internal/c;

    return-void
.end method


# virtual methods
.method protected final bridge synthetic a(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 0

    invoke-static {p1}, Lcom/ecarx/eas/framework/sdk/common/internal/j;->a(Landroid/os/IBinder;)Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    move-result-object p1

    return-object p1
.end method

.method protected final a()Ljava/lang/String;
    .locals 1

    const-string v0, "ecarx.intent.action.OpenAPIService"

    return-object v0
.end method

.method protected final g()V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->a()V

    return-void
.end method

.method protected final h()V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->b()V

    return-void
.end method

.method protected final i()V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    invoke-interface {v0}, Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;->c()V

    return-void
.end method

.method public final j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;
    .locals 1

    sget-object v0, Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;->OpenAPI:Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;

    return-object v0
.end method

.method protected final l()V
    .locals 2

    :try_start_0
    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/h;->b:Lcom/ecarx/eas/framework/sdk/common/internal/c;

    invoke-interface {v0, v1}, Lcom/ecarx/eas/framework/sdk/common/internal/IServicePool;->addRemoteServiceCallback(Lcom/ecarx/eas/framework/sdk/common/internal/g;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    return-void

    :catch_1
    move-exception v0

    invoke-virtual {v0}, Landroid/os/RemoteException;->printStackTrace()V

    return-void
.end method
