.class public abstract Lcom/ecarx/eas/framework/sdk/common/internal/a;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T::",
        "Landroid/os/IInterface;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field protected volatile a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

.field private volatile b:Landroid/content/Context;

.field private final c:Ljava/lang/Object;

.field private d:Ljava/util/concurrent/atomic/AtomicInteger;

.field private e:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

.field private volatile f:Landroid/os/IInterface;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field private g:Landroid/content/ServiceConnection;

.field private h:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;

    invoke-direct {v0, p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a$1;-><init>(Lcom/ecarx/eas/framework/sdk/common/internal/a;)V

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->g:Landroid/content/ServiceConnection;

    const-string v0, "Context must not be null"

    invoke-static {p1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/i;->a(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/Context;

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c:Ljava/lang/Object;

    const-string p1, "wrapper must not be null"

    invoke-static {p2, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/i;->a(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iput-object p3, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    new-instance p1, Landroid/os/HandlerThread;

    const-string p2, "BaseEASFrameworkClient"

    const/16 p3, 0xa

    invoke-direct {p1, p2, p3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    invoke-virtual {p1}, Landroid/os/HandlerThread;->start()V

    new-instance p2, Landroid/os/Handler;

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-direct {p2, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->h:Landroid/os/Handler;

    return-void
.end method

.method public static INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I
    .locals 1

    sget-object v0, Lcom/bytedance/auto/lite/serviceapi/config/log/Level;->E:Lcom/bytedance/auto/lite/serviceapi/config/log/Level;

    invoke-static {v0, p0, p1}, Lcom/bytedance/auto/lite/lancet/LogLancet;->printLog(Lcom/bytedance/auto/lite/serviceapi/config/log/Level;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic a(Lcom/ecarx/eas/framework/sdk/common/internal/a;Landroid/os/IInterface;)Landroid/os/IInterface;
    .locals 0

    iput-object p1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f:Landroid/os/IInterface;

    return-object p1
.end method

.method static synthetic a(Lcom/ecarx/eas/framework/sdk/common/internal/a;)Ljava/util/concurrent/atomic/AtomicInteger;
    .locals 0

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    return-object p0
.end method

.method private a(Landroid/content/Intent;)Z
    .locals 13

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "connect system service start context>>>:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    invoke-static {v1}, Lcom/ecarx/eas/framework/sdk/common/wrappers/a;->a(Landroid/content/Context;)Z

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "EASFrameworkClient"

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    invoke-static {v0}, Lcom/ecarx/eas/framework/sdk/common/wrappers/a;->a(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    :try_start_0
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const-string v4, "bindServiceAsUser"

    const/16 v5, 0x18

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-lt v2, v5, :cond_0

    :try_start_1
    new-array v11, v3, [Ljava/lang/Class;

    const-class v12, Landroid/content/Intent;

    aput-object v12, v11, v8

    const-class v12, Landroid/content/ServiceConnection;

    aput-object v12, v11, v10

    sget-object v12, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v12, v11, v7

    const-class v12, Landroid/os/Handler;

    aput-object v12, v11, v6

    const-class v12, Landroid/os/UserHandle;

    aput-object v12, v11, v9

    invoke-virtual {v0, v4, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    goto :goto_0

    :cond_0
    new-array v11, v9, [Ljava/lang/Class;

    const-class v12, Landroid/content/Intent;

    aput-object v12, v11, v8

    const-class v12, Landroid/content/ServiceConnection;

    aput-object v12, v11, v10

    sget-object v12, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v12, v11, v7

    const-class v12, Landroid/os/UserHandle;

    aput-object v12, v11, v6

    invoke-virtual {v0, v4, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    :goto_0
    if-eqz v0, :cond_2

    if-lt v2, v5, :cond_1

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    new-array v3, v3, [Ljava/lang/Object;

    aput-object p1, v3, v8

    iget-object v4, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->g:Landroid/content/ServiceConnection;

    aput-object v4, v3, v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v7

    iget-object v4, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->h:Landroid/os/Handler;

    aput-object v4, v3, v6

    invoke-static {}, Landroid/os/Process;->myUserHandle()Landroid/os/UserHandle;

    move-result-object v4

    aput-object v4, v3, v9

    invoke-virtual {v0, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    :cond_1
    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    new-array v3, v9, [Ljava/lang/Object;

    aput-object p1, v3, v8

    iget-object v4, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->g:Landroid/content/ServiceConnection;

    aput-object v4, v3, v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v3, v7

    invoke-static {}, Landroid/os/Process;->myUserHandle()Landroid/os/UserHandle;

    move-result-object v4

    aput-object v4, v3, v6

    invoke-virtual {v0, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_1
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "connect system service result >>>:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p1

    return p1

    :cond_2
    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b(Landroid/content/Intent;)Z

    move-result p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return p1

    :catch_0
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "connect system service fail >>>:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b(Landroid/content/Intent;)Z

    move-result p1

    return p1

    :cond_3
    invoke-direct {p0, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b(Landroid/content/Intent;)Z

    move-result p1

    return p1
.end method

.method static synthetic access$000(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic b(Lcom/ecarx/eas/framework/sdk/common/internal/a;)V
    .locals 1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    iget-object p0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->g:Landroid/content/ServiceConnection;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    return-void
.end method

.method private b(Landroid/content/Intent;)Z
    .locals 4

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->g:Landroid/content/ServiceConnection;

    const/4 v2, 0x1

    invoke-virtual {v0, p1, v1, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    if-nez v0, :cond_1

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {p1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/ComponentName;->flattenToShortString()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v3, "com.ecarx.sdk.openapi"

    invoke-direct {p1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "/"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    aput-object p1, v1, v2

    const-string p1, ">> %s is permission <<"

    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "EASFrameworkClient"

    invoke-static {v1, p1}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return v0
.end method


# virtual methods
.method protected abstract a(Landroid/os/IBinder;)Landroid/os/IInterface;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/IBinder;",
            ")TT;"
        }
    .end annotation
.end method

.method protected abstract a()Ljava/lang/String;
.end method

.method public final b()Z
    .locals 5

    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "com.ecarx.sdk.openapi"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    iget-object v2, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    invoke-virtual {v2, v0}, Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;->findService(Landroid/content/Intent;)Landroid/content/pm/ServiceInfo;

    move-result-object v2

    const/4 v3, 0x1

    if-nez v2, :cond_0

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    const-string v1, ">> package=%s, action=%s service not found!!!<<"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "EASFrameworkClient"

    invoke-static {v1, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->INVOKESTATIC_com_ecarx_eas_framework_sdk_common_internal_a_com_bytedance_auto_lite_lancet_LogLancet_e(Ljava/lang/String;Ljava/lang/String;)I

    return v2

    :cond_0
    new-instance v1, Landroid/content/ComponentName;

    iget-object v4, v2, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-direct {v1, v4, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    invoke-direct {p0, v0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a(Landroid/content/Intent;)Z

    move-result v0

    return v0
.end method

.method public final c()Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public final d()Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public final e()Z
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v1, 0x5

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    return v0

    :cond_1
    :goto_0
    const/4 v0, 0x1

    return v0
.end method

.method public final f()Landroid/os/IInterface;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v1

    const/4 v2, 0x4

    if-eq v1, v2, :cond_3

    invoke-virtual {p0}, Lcom/ecarx/eas/framework/sdk/common/internal/a;->c()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f:Landroid/os/IInterface;

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    const-string v2, "Client is connected but service is null"

    if-eqz v1, :cond_1

    iget-object v1, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->f:Landroid/os/IInterface;

    monitor-exit v0

    return-object v1

    :cond_1
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_2
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Not connected. Call connect() and wait for onConnected() to be called!"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_3
    new-instance v1, Landroid/os/DeadObjectException;

    invoke-direct {v1}, Landroid/os/DeadObjectException;-><init>()V

    throw v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method protected abstract g()V
.end method

.method protected abstract h()V
.end method

.method protected abstract i()V
.end method

.method public abstract j()Lcom/ecarx/eas/framework/sdk/common/internal/ClientType;
.end method

.method public final k()V
    .locals 2

    iget-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->d:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->h:Landroid/os/Handler;

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->a:Lcom/ecarx/eas/framework/sdk/common/internal/EASFrameworkApiClient$b;

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->e:Lcom/ecarx/eas/framework/sdk/common/wrappers/PackageManagerWrapper;

    iput-object v0, p0, Lcom/ecarx/eas/framework/sdk/common/internal/a;->b:Landroid/content/Context;

    return-void
.end method

.method protected abstract l()V
.end method
