.class public abstract Lcom/ecarx/eas/framework/sdk/common/internal/Constant;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getMsgToCode(I)Ljava/lang/String;
    .locals 1
    .annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
    .end annotation

    const/16 v0, 0xc8

    if-eq p0, v0, :cond_0

    packed-switch p0, :pswitch_data_0

    packed-switch p0, :pswitch_data_1

    const-string p0, ""

    goto :goto_0

    :pswitch_0
    const-string p0, "Service\u521d\u59cb\u5316\u4e2d"

    goto :goto_0

    :pswitch_1
    const-string p0, "Service\u5f02\u5e38"

    goto :goto_0

    :pswitch_2
    const-string p0, "Service\u4e0d\u5b58\u5728"

    goto :goto_0

    :pswitch_3
    const-string p0, "\u975e\u6cd5\u53c2\u6570"

    goto :goto_0

    :pswitch_4
    const-string p0, "\u4e0d\u652f\u6301\u8be5API"

    goto :goto_0

    :pswitch_5
    const-string p0, "\u6ca1\u6709\u6743\u9650"

    goto :goto_0

    :cond_0
    const-string p0, "\u64cd\u4f5c\u6210\u529f"

    :goto_0
    return-object p0

    :pswitch_data_0
    .packed-switch 0x191
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_4
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1f5
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
