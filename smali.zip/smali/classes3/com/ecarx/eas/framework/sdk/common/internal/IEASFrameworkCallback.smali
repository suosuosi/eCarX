.class public interface abstract Lcom/ecarx/eas/framework/sdk/common/internal/IEASFrameworkCallback;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# virtual methods
.method public abstract onCall(Lcom/ecarx/sdk/openapi/msg/EASFrameworkCallbackMessage;)V
.end method
