.class public Lecarx/xsf/mediacenter/IMediaLists;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lecarx/xsf/mediacenter/IMediaLists;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private mediaLists:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMediaList;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lecarx/xsf/mediacenter/IMediaLists$1;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/IMediaLists$1;-><init>()V

    sput-object v0, Lecarx/xsf/mediacenter/IMediaLists;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lecarx/xsf/mediacenter/IMediaList;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/IMediaLists;->mediaLists:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getMediaLists()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMediaList;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lecarx/xsf/mediacenter/IMediaLists;->mediaLists:Ljava/util/List;

    return-object v0
.end method

.method public setMediaLists(Ljava/util/List;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMediaList;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lecarx/xsf/mediacenter/IMediaLists;->mediaLists:Ljava/util/List;

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    iget-object p2, p0, Lecarx/xsf/mediacenter/IMediaLists;->mediaLists:Ljava/util/List;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    return-void
.end method
