.class public interface abstract Lecarx/xsf/mediacenter/IMediaCenterWidgetApiSvc;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/IMediaCenterWidgetApiSvc$Stub;
    }
.end annotation


# virtual methods
.method public abstract ctrlPauseMediaList(I)V
.end method

.method public abstract ctrlPlayMediaList(I)V
.end method

.method public abstract getContentList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IContent;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getExData(ILjava/lang/String;Ljava/lang/String;Lcom/ecarx/eas/xsf/mediacenter/IExContent;Landroid/os/IBinder;)Lcom/ecarx/eas/xsf/mediacenter/IExContent;
.end method

.method public abstract getMediaListSourceType()I
.end method

.method public abstract getMediaListType()I
.end method

.method public abstract getMultiMediaList([I)Lecarx/xsf/mediacenter/IMediaLists;
.end method

.method public abstract getMusicPlaybackInfo()Lecarx/xsf/mediacenter/IMusicPlaybackInfo;
.end method

.method public abstract getPlayList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;"
        }
    .end annotation
.end method

.method public abstract playCtrlCancelRecommend()I
.end method

.method public abstract playCtrlCollect(IZ)I
.end method

.method public abstract playCtrlNext()I
.end method

.method public abstract playCtrlPause()I
.end method

.method public abstract playCtrlPlay()I
.end method

.method public abstract playCtrlPlayRecommend()I
.end method

.method public abstract playCtrlPrevious()I
.end method

.method public abstract selectListMediaPlay(IILjava/lang/String;)I
.end method

.method public abstract selectMediaPlay(ILjava/lang/String;)I
.end method

.method public abstract setWidgetApiSvc(Lecarx/xsf/widget/IWidgetApiSvc;)V
.end method
