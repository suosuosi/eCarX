.class final Lecarx/xsf/mediacenter/IMediaCenterClientToken$Stub$a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lecarx/xsf/mediacenter/IMediaCenterClientToken;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/IMediaCenterClientToken$Stub;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# static fields
.field public static a:Lecarx/xsf/mediacenter/IMediaCenterClientToken;


# instance fields
.field private b:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lecarx/xsf/mediacenter/IMediaCenterClientToken$Stub$a;->b:Landroid/os/IBinder;

    return-void
.end method


# virtual methods
.method public final asBinder()Landroid/os/IBinder;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/IMediaCenterClientToken$Stub$a;->b:Landroid/os/IBinder;

    return-object v0
.end method
