.class public interface abstract Lecarx/xsf/mediacenter/IAllPlaybackInfo;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/IAllPlaybackInfo$Stub;
    }
.end annotation


# virtual methods
.method public abstract getClientType()I
.end method

.method public abstract getMusicPlaybackInfo()Lecarx/xsf/mediacenter/IMusicPlaybackInfo;
.end method

.method public abstract getNewsPlaybackInfo()Lecarx/xsf/mediacenter/INewsPlaybackInfo;
.end method

.method public abstract getVideoPlaybackInfo()Lecarx/xsf/mediacenter/IVideoPlaybackInfo;
.end method
