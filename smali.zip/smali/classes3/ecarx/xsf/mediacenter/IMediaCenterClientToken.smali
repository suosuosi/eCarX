.class public interface abstract Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/IMediaCenterClientToken$Stub;
    }
.end annotation
