.class public interface abstract Lecarx/xsf/mediacenter/IVideoPlaybackInfo;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/IVideoPlaybackInfo$Stub;
    }
.end annotation


# virtual methods
.method public abstract getPlaybackStatus()I
.end method

.method public abstract isCollected()Z
.end method

.method public abstract isDownloaded()Z
.end method

.method public abstract isSupportCollect()Z
.end method

.method public abstract isSupportDownload()Z
.end method

.method public abstract isSupportVrCtrlPlayStatus()Z
.end method
