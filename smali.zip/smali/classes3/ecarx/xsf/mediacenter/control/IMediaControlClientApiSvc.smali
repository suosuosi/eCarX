.class public interface abstract Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub;
    }
.end annotation


# virtual methods
.method public abstract register(Ljava/lang/String;Lecarx/xsf/mediacenter/control/IMediaControlClient;)Lecarx/xsf/mediacenter/control/IMediaControlClientToken;
.end method

.method public abstract requestControlled(Lecarx/xsf/mediacenter/control/IMediaControlClientToken;)Z
.end method

.method public abstract unregister(Lecarx/xsf/mediacenter/control/IMediaControlClientToken;)Z
.end method
