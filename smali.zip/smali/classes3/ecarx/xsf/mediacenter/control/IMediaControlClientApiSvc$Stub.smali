.class public abstract Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub;
.super Landroid/os/Binder;
.source ""

# interfaces
.implements Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub$a;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "ecarx.xsf.mediacenter.control.IMediaControlClientApiSvc"

.field static final TRANSACTION_register:I = 0x1

.field static final TRANSACTION_requestControlled:I = 0x3

.field static final TRANSACTION_unregister:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const-string v0, "ecarx.xsf.mediacenter.control.IMediaControlClientApiSvc"

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "ecarx.xsf.mediacenter.control.IMediaControlClientApiSvc"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    if-eqz v1, :cond_1

    check-cast v0, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    return-object v0

    :cond_1
    new-instance v0, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub$a;

    invoke-direct {v0, p0}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method

.method public static getDefaultImpl()Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;
    .locals 1

    sget-object v0, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    return-object v0
.end method

.method public static setDefaultImpl(Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;)Z
    .locals 1

    sget-object v0, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    if-nez v0, :cond_0

    if-eqz p0, :cond_0

    sput-object p0, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    const/4 v0, 0x1

    const-string v1, "ecarx.xsf.mediacenter.control.IMediaControlClientApiSvc"

    if-eq p1, v0, :cond_3

    const/4 v2, 0x2

    if-eq p1, v2, :cond_2

    const/4 v2, 0x3

    if-eq p1, v2, :cond_1

    const v2, 0x5f4e5446

    if-eq p1, v2, :cond_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    :cond_0
    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v0

    :cond_1
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControlClientToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControlClientToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;->requestControlled(Lecarx/xsf/mediacenter/control/IMediaControlClientToken;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v0

    :cond_2
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControlClientToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControlClientToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;->unregister(Lecarx/xsf/mediacenter/control/IMediaControlClientToken;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v0

    :cond_3
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p2

    invoke-static {p2}, Lecarx/xsf/mediacenter/control/IMediaControlClient$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControlClient;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaControlClientApiSvc;->register(Ljava/lang/String;Lecarx/xsf/mediacenter/control/IMediaControlClient;)Lecarx/xsf/mediacenter/control/IMediaControlClientToken;

    move-result-object p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    if-eqz p1, :cond_4

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    goto :goto_0

    :cond_4
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    return v0
.end method
