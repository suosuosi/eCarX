.class public interface abstract Lecarx/xsf/mediacenter/control/IMediaControllerToken;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;
    }
.end annotation
