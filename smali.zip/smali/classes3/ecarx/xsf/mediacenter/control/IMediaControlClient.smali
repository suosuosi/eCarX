.class public interface abstract Lecarx/xsf/mediacenter/control/IMediaControlClient;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaControlClient$Stub;
    }
.end annotation


# virtual methods
.method public abstract getMediaContentTypeList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;"
        }
    .end annotation
.end method

.method public abstract onControlledChanged(Ljava/lang/String;)V
.end method

.method public abstract onPause(I)Z
.end method

.method public abstract onPauseNow()Z
.end method

.method public abstract onPlay(ILjava/lang/String;)Z
.end method

.method public abstract onPlayByContent(ILjava/lang/String;)Z
.end method

.method public abstract onPlayByMediaId(ILjava/lang/String;)Z
.end method

.method public abstract onResumeNow()Z
.end method
