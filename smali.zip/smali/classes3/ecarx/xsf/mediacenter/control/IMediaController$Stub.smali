.class public abstract Lecarx/xsf/mediacenter/control/IMediaController$Stub;
.super Landroid/os/Binder;
.source ""

# interfaces
.implements Lecarx/xsf/mediacenter/control/IMediaController;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/control/IMediaController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaController$Stub$a;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "ecarx.xsf.mediacenter.control.IMediaController"

.field static final TRANSACTION_onControllerChanged:I = 0x1

.field static final TRANSACTION_updateCurrentProgress:I = 0x5

.field static final TRANSACTION_updateErrorMsg:I = 0x4

.field static final TRANSACTION_updateMediaContentTypeList:I = 0x6

.field static final TRANSACTION_updatePlaybackInfo:I = 0x3

.field static final TRANSACTION_updatePlaylist:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const-string v0, "ecarx.xsf.mediacenter.control.IMediaController"

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaController;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "ecarx.xsf.mediacenter.control.IMediaController"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lecarx/xsf/mediacenter/control/IMediaController;

    if-eqz v1, :cond_1

    check-cast v0, Lecarx/xsf/mediacenter/control/IMediaController;

    return-object v0

    :cond_1
    new-instance v0, Lecarx/xsf/mediacenter/control/IMediaController$Stub$a;

    invoke-direct {v0, p0}, Lecarx/xsf/mediacenter/control/IMediaController$Stub$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method

.method public static getDefaultImpl()Lecarx/xsf/mediacenter/control/IMediaController;
    .locals 1

    sget-object v0, Lecarx/xsf/mediacenter/control/IMediaController$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaController;

    return-object v0
.end method

.method public static setDefaultImpl(Lecarx/xsf/mediacenter/control/IMediaController;)Z
    .locals 1

    sget-object v0, Lecarx/xsf/mediacenter/control/IMediaController$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaController;

    if-nez v0, :cond_0

    if-eqz p0, :cond_0

    sput-object p0, Lecarx/xsf/mediacenter/control/IMediaController$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaController;

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    const v0, 0x5f4e5446

    const/4 v1, 0x1

    const-string v2, "ecarx.xsf.mediacenter.control.IMediaController"

    if-eq p1, v0, :cond_0

    packed-switch p1, :pswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    :pswitch_0
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    sget-object p1, Lecarx/xsf/mediacenter/bean/IMediaContentType;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, p1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaController;->updateMediaContentTypeList(Ljava/util/List;)V

    :goto_0
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_1
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readLong()J

    move-result-wide p1

    invoke-interface {p0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaController;->updateCurrentProgress(J)V

    goto :goto_0

    :pswitch_2
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaController;->updateErrorMsg(ILjava/lang/String;)V

    goto :goto_0

    :pswitch_3
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/IMusicPlaybackInfo$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaController;->updatePlaybackInfo(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V

    goto :goto_0

    :pswitch_4
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    sget-object p4, Lecarx/xsf/mediacenter/IMedia;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p2, p4}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaController;->updatePlaylist(ILjava/util/List;)V

    goto :goto_0

    :pswitch_5
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaController;->onControllerChanged(Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p3, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
