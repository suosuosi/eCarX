.class public interface abstract Lecarx/xsf/mediacenter/control/IMediaController;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaController$Stub;
    }
.end annotation


# virtual methods
.method public abstract onControllerChanged(Ljava/lang/String;)V
.end method

.method public abstract updateCurrentProgress(J)V
.end method

.method public abstract updateErrorMsg(ILjava/lang/String;)V
.end method

.method public abstract updateMediaContentTypeList(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract updatePlaybackInfo(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V
.end method

.method public abstract updatePlaylist(ILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)V"
        }
    .end annotation
.end method
