.class public abstract Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub;
.super Landroid/os/Binder;
.source ""

# interfaces
.implements Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub$a;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "ecarx.xsf.mediacenter.control.IMediaControllerApiSvc"

.field static final TRANSACTION_getMediaContentTypeList:I = 0x4

.field static final TRANSACTION_getMediaList:I = 0xc

.field static final TRANSACTION_getMusicPlaybackInfo:I = 0xd

.field static final TRANSACTION_getSourceType:I = 0xb

.field static final TRANSACTION_pause:I = 0x9

.field static final TRANSACTION_play:I = 0xa

.field static final TRANSACTION_playCtlPlay:I = 0x5

.field static final TRANSACTION_playCtrlPause:I = 0x7

.field static final TRANSACTION_playCtrlPlayByContent:I = 0x6

.field static final TRANSACTION_register:I = 0x1

.field static final TRANSACTION_requestControl:I = 0x3

.field static final TRANSACTION_resume:I = 0x8

.field static final TRANSACTION_unregister:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const-string v0, "ecarx.xsf.mediacenter.control.IMediaControllerApiSvc"

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "ecarx.xsf.mediacenter.control.IMediaControllerApiSvc"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    if-eqz v1, :cond_1

    check-cast v0, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    return-object v0

    :cond_1
    new-instance v0, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub$a;

    invoke-direct {v0, p0}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub$a;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method

.method public static getDefaultImpl()Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;
    .locals 1

    sget-object v0, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    return-object v0
.end method

.method public static setDefaultImpl(Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;)Z
    .locals 1

    sget-object v0, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    if-nez v0, :cond_0

    if-eqz p0, :cond_0

    sput-object p0, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub$a;->a:Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    const v0, 0x5f4e5446

    const/4 v1, 0x1

    const-string v2, "ecarx.xsf.mediacenter.control.IMediaControllerApiSvc"

    if-eq p1, v0, :cond_2

    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    :pswitch_0
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getMusicPlaybackInfo(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Lecarx/xsf/mediacenter/IMusicPlaybackInfo;

    move-result-object p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    if-eqz p1, :cond_0

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    :cond_0
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    return v1

    :pswitch_1
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getMediaList(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    return v1

    :pswitch_2
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getSourceType(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)I

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_3
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p4

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p4, p2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->play(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_4
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->pause(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_5
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->resume(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_6
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p2

    invoke-interface {p0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->playCtrlPause(Lecarx/xsf/mediacenter/control/IMediaControllerToken;I)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_7
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p4

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p4, p2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->playCtrlPlayByContent(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_8
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p4

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p4, p2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->playCtlPlay(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_9
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->getMediaContentTypeList(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    return v1

    :pswitch_a
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->requestControl(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_b
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Lecarx/xsf/mediacenter/control/IMediaControllerToken$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-interface {p0, p1}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->unregister(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z

    move-result p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_c
    invoke-virtual {p2, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p2

    invoke-static {p2}, Lecarx/xsf/mediacenter/control/IMediaController$Stub;->asInterface(Landroid/os/IBinder;)Lecarx/xsf/mediacenter/control/IMediaController;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;->register(Ljava/lang/String;Lecarx/xsf/mediacenter/control/IMediaController;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;

    move-result-object p1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    if-eqz p1, :cond_1

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    :cond_1
    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    return v1

    :cond_2
    invoke-virtual {p3, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
