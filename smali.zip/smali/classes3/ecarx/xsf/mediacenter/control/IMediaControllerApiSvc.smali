.class public interface abstract Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/control/IMediaControllerApiSvc$Stub;
    }
.end annotation


# virtual methods
.method public abstract getMediaContentTypeList(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/control/IMediaControllerToken;",
            ")",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getMediaList(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/control/IMediaControllerToken;",
            ")",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getMusicPlaybackInfo(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Lecarx/xsf/mediacenter/IMusicPlaybackInfo;
.end method

.method public abstract getSourceType(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)I
.end method

.method public abstract pause(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z
.end method

.method public abstract play(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z
.end method

.method public abstract playCtlPlay(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z
.end method

.method public abstract playCtrlPause(Lecarx/xsf/mediacenter/control/IMediaControllerToken;I)Z
.end method

.method public abstract playCtrlPlayByContent(Lecarx/xsf/mediacenter/control/IMediaControllerToken;ILjava/lang/String;)Z
.end method

.method public abstract register(Ljava/lang/String;Lecarx/xsf/mediacenter/control/IMediaController;)Lecarx/xsf/mediacenter/control/IMediaControllerToken;
.end method

.method public abstract requestControl(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z
.end method

.method public abstract resume(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z
.end method

.method public abstract unregister(Lecarx/xsf/mediacenter/control/IMediaControllerToken;)Z
.end method
