.class public interface abstract Lecarx/xsf/mediacenter/IMediaCenterSvc;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/IMediaCenterSvc$Stub;
    }
.end annotation


# virtual methods
.method public abstract asyncSendVrChannelResult(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;Ljava/lang/String;)Z
.end method

.method public abstract cancelMusicCtrlCapabilityDeclaration(Lecarx/xsf/mediacenter/vr/IMusicIntentObserver;)Z
.end method

.method public abstract cancelNewsCtrlCapabilityDeclaration(Lecarx/xsf/mediacenter/vr/INewsIntentObserver;)Z
.end method

.method public abstract cancelRadioCtrlCapabilityDeclaration(Lecarx/xsf/mediacenter/vr/IRadioIntentObserver;)Z
.end method

.method public abstract cancelSupportCollectTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z
.end method

.method public abstract cancelSupportDownloadTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z
.end method

.method public abstract cancelVrChannelCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;)Z
.end method

.method public abstract declareMediaCenterCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)V
.end method

.method public abstract declareMusicCtrlCapability([ILecarx/xsf/mediacenter/vr/IMusicIntentObserver;)Z
.end method

.method public abstract declareNewsCtrlCapability(Lecarx/xsf/mediacenter/vr/INewsIntentObserver;)Z
.end method

.method public abstract declareRadioCtrlCapability([ILecarx/xsf/mediacenter/vr/IRadioIntentObserver;)Z
.end method

.method public abstract declareSupportCollectTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z
.end method

.method public abstract declareSupportDownloadTypes(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)Z
.end method

.method public abstract declareVrChannelCapability(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/vr/channel/IVrChannelInfo;Lecarx/xsf/mediacenter/vr/channel/IVrChannelObserver;)Z
.end method

.method public abstract declareVrCtrlPriority(Ljava/lang/String;ILecarx/xsf/mediacenter/vr/IMusicIntentObserver;Lecarx/xsf/mediacenter/vr/IRadioIntentObserver;Lecarx/xsf/mediacenter/vr/INewsIntentObserver;)V
.end method

.method public abstract getMediaControlClientApi()Landroid/os/IBinder;
.end method

.method public abstract getMediaControllerApi()Landroid/os/IBinder;
.end method

.method public abstract getStateBinder()Landroid/os/IBinder;
.end method

.method public abstract queryCurrentFocusClient(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Ljava/lang/String;
.end method

.method public abstract registerInMusic(Ljava/lang/String;Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.end method

.method public abstract registerInNews(Ljava/lang/String;Lecarx/xsf/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.end method

.method public abstract registerInVideo(Ljava/lang/String;Lecarx/xsf/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.end method

.method public abstract registerMusic(Lecarx/xsf/mediacenter/IMusicClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.end method

.method public abstract registerNews(Lecarx/xsf/mediacenter/INewsClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.end method

.method public abstract registerVideo(Lecarx/xsf/mediacenter/IVideoClient;)Lecarx/xsf/mediacenter/IMediaCenterClientToken;
.end method

.method public abstract requestPlay(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z
.end method

.method public abstract unregister(Lecarx/xsf/mediacenter/IMediaCenterClientToken;)Z
.end method

.method public abstract updateCollectMsg(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)V
.end method

.method public abstract updateCollectMsgByUUID(Lecarx/xsf/mediacenter/IMediaCenterClientToken;IILjava/lang/String;ILjava/lang/String;)V
.end method

.method public abstract updateCurrentLyric(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/lang/String;)V
.end method

.method public abstract updateCurrentProgress(Lecarx/xsf/mediacenter/IMediaCenterClientToken;J)V
.end method

.method public abstract updateCurrentRecommendInfo(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IRecommend;)Z
.end method

.method public abstract updateCurrentSourceType(Lecarx/xsf/mediacenter/IMediaCenterClientToken;I)V
.end method

.method public abstract updateErrorMsg(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/lang/String;)V
.end method

.method public abstract updateMediaContent(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/util/List;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/IMediaCenterClientToken;",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IContent;",
            ">;)Z"
        }
    .end annotation
.end method

.method public abstract updateMediaContentTypeList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/IMediaCenterClientToken;",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/bean/IMediaContentType;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract updateMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;IILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/IMediaCenterClientToken;",
            "II",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract updateMediaPlayList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMediaList;)V
.end method

.method public abstract updateMediaSourceTypeList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;[I)V
.end method

.method public abstract updateMultiMediaList(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMediaLists;)Z
.end method

.method public abstract updateMusicPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)Z
.end method

.method public abstract updateNewsPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/INewsPlaybackInfo;)Z
.end method

.method public abstract updatePlaylist(Lecarx/xsf/mediacenter/IMediaCenterClientToken;ILjava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lecarx/xsf/mediacenter/IMediaCenterClientToken;",
            "I",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/IMedia;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract updateVideoPlaybackState(Lecarx/xsf/mediacenter/IMediaCenterClientToken;Lecarx/xsf/mediacenter/IVideoPlaybackInfo;)Z
.end method
