.class public interface abstract Lecarx/xsf/mediacenter/staterecover/IMusicRecoveryListener;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/staterecover/IMusicRecoveryListener$Stub;
    }
.end annotation


# virtual methods
.method public abstract onGetMediaList(Lecarx/xsf/mediacenter/staterecover/IRecoveryMediaMetaInfo;)V
.end method

.method public abstract onGetMusicPlaybackInfo(Lecarx/xsf/mediacenter/IMusicPlaybackInfo;)V
.end method
