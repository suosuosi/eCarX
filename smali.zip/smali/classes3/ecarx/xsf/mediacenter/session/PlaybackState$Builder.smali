.class public final Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/PlaybackState;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private errorCode:I

.field private errorMessage:Ljava/lang/String;

.field private itemId:Ljava/lang/String;

.field private loopMode:I

.field private queueId:Ljava/lang/String;

.field private radioMode:I

.field private state:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lecarx/xsf/mediacenter/session/PlaybackState;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$700(Lecarx/xsf/mediacenter/session/PlaybackState;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->state:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$800(Lecarx/xsf/mediacenter/session/PlaybackState;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->loopMode:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$900(Lecarx/xsf/mediacenter/session/PlaybackState;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->radioMode:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$1000(Lecarx/xsf/mediacenter/session/PlaybackState;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->queueId:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$1100(Lecarx/xsf/mediacenter/session/PlaybackState;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->itemId:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$1200(Lecarx/xsf/mediacenter/session/PlaybackState;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->errorCode:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState;->access$1300(Lecarx/xsf/mediacenter/session/PlaybackState;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->errorMessage:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->state:I

    return p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->loopMode:I

    return p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->radioMode:I

    return p0
.end method

.method static synthetic access$300(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->queueId:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$400(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->itemId:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$500(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->errorCode:I

    return p0
.end method

.method static synthetic access$600(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->errorMessage:Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public final build()Lecarx/xsf/mediacenter/session/PlaybackState;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/PlaybackState;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/PlaybackState;-><init>(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;Lecarx/xsf/mediacenter/session/PlaybackState$1;)V

    return-object v0
.end method

.method public final errorCode(I)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->errorCode:I

    return-object p0
.end method

.method public final errorMessage(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->errorMessage:Ljava/lang/String;

    return-object p0
.end method

.method public final itemId(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->itemId:Ljava/lang/String;

    return-object p0
.end method

.method public final loopMode(I)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->loopMode:I

    return-object p0
.end method

.method public final queueId(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->queueId:Ljava/lang/String;

    return-object p0
.end method

.method public final radioMode(I)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->radioMode:I

    return-object p0
.end method

.method public final state(I)Lecarx/xsf/mediacenter/session/PlaybackState$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->state:I

    return-object p0
.end method
