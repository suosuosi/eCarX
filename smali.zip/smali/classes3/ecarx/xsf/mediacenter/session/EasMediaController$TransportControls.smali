.class public interface abstract Lecarx/xsf/mediacenter/session/EasMediaController$TransportControls;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/EasMediaController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "TransportControls"
.end annotation


# virtual methods
.method public abstract download(Ljava/lang/String;Ljava/lang/String;Z)V
.end method

.method public abstract favorite(Ljava/lang/String;Ljava/lang/String;Z)V
.end method

.method public abstract select(Ljava/lang/String;Ljava/lang/String;Z)V
.end method

.method public abstract selectFrom(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
.end method

.method public abstract setLoopMode(I)V
.end method

.method public abstract setMediaQuality(I)V
.end method

.method public abstract setMediaSource(I)V
.end method

.method public abstract setMediaSource(Ljava/lang/String;I)V
.end method

.method public abstract setMediaSource(Ljava/lang/String;Ljava/lang/String;I)V
.end method

.method public abstract transportControl(ILandroid/os/Bundle;)V
.end method
