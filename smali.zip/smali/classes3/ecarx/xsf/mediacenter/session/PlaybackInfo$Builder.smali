.class public final Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/PlaybackInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private appName:Ljava/lang/String;

.field private iconUri:Landroid/net/Uri;

.field private initialProgress:J

.field private launchIntent:Landroid/app/PendingIntent;

.field private mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

.field private pkgName:Ljava/lang/String;

.field private playerIntent:Landroid/app/PendingIntent;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lecarx/xsf/mediacenter/session/PlaybackInfo;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;->access$700(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->pkgName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;->access$800(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->iconUri:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;->access$900(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->appName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;->access$1000(Lecarx/xsf/mediacenter/session/PlaybackInfo;)J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->initialProgress:J

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;->access$1100(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Lecarx/xsf/mediacenter/session/MediaItem;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->pkgName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->iconUri:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->appName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$300(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Landroid/app/PendingIntent;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->launchIntent:Landroid/app/PendingIntent;

    return-object p0
.end method

.method static synthetic access$400(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Landroid/app/PendingIntent;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->playerIntent:Landroid/app/PendingIntent;

    return-object p0
.end method

.method static synthetic access$500(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->initialProgress:J

    return-wide v0
.end method

.method static synthetic access$600(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Lecarx/xsf/mediacenter/session/MediaItem;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-object p0
.end method


# virtual methods
.method public final appName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->appName:Ljava/lang/String;

    return-object p0
.end method

.method public final build()Lecarx/xsf/mediacenter/session/PlaybackInfo;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/PlaybackInfo;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;-><init>(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;Lecarx/xsf/mediacenter/session/PlaybackInfo$1;)V

    return-object v0
.end method

.method public final iconUri(Landroid/net/Uri;)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->iconUri:Landroid/net/Uri;

    return-object p0
.end method

.method public final initialProgress(J)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-wide p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->initialProgress:J

    return-object p0
.end method

.method public final launchIntent(Landroid/app/PendingIntent;)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->launchIntent:Landroid/app/PendingIntent;

    return-object p0
.end method

.method public final mediaItem(Lecarx/xsf/mediacenter/session/MediaItem;)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-object p0
.end method

.method public final pkgName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->pkgName:Ljava/lang/String;

    return-object p0
.end method

.method public final playerIntent(Landroid/app/PendingIntent;)Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->playerIntent:Landroid/app/PendingIntent;

    return-object p0
.end method
