.class public final Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/MediaQueue;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private cover:Landroid/net/Uri;

.field private id:Ljava/lang/String;

.field private pkgName:Ljava/lang/String;

.field private queue:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/MediaItem;",
            ">;"
        }
    .end annotation
.end field

.field private queueIntent:Landroid/app/PendingIntent;

.field private queueType:I

.field private title:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lecarx/xsf/mediacenter/session/MediaQueue;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue;->access$700(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->id:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue;->access$800(Lecarx/xsf/mediacenter/session/MediaQueue;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queueType:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue;->access$900(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->title:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue;->access$1000(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->pkgName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue;->access$1100(Lecarx/xsf/mediacenter/session/MediaQueue;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->cover:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue;->access$1200(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queue:Ljava/util/List;

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->id:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queueType:I

    return p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->title:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$300(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->cover:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$400(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Landroid/app/PendingIntent;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queueIntent:Landroid/app/PendingIntent;

    return-object p0
.end method

.method static synthetic access$500(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queue:Ljava/util/List;

    return-object p0
.end method

.method static synthetic access$600(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->pkgName:Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public final build()Lecarx/xsf/mediacenter/session/MediaQueue;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaQueue;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/MediaQueue;-><init>(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;Lecarx/xsf/mediacenter/session/MediaQueue$1;)V

    return-object v0
.end method

.method public final cover(Landroid/net/Uri;)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->cover:Landroid/net/Uri;

    return-object p0
.end method

.method public final id(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->id:Ljava/lang/String;

    return-object p0
.end method

.method public final pkgName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->pkgName:Ljava/lang/String;

    return-object p0
.end method

.method public final queue(Ljava/util/List;)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/MediaItem;",
            ">;)",
            "Lecarx/xsf/mediacenter/session/MediaQueue$Builder;"
        }
    .end annotation

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queue:Ljava/util/List;

    return-object p0
.end method

.method public final queueIntent(Landroid/app/PendingIntent;)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queueIntent:Landroid/app/PendingIntent;

    return-object p0
.end method

.method public final queueType(I)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->queueType:I

    return-object p0
.end method

.method public final title(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaQueue$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->title:Ljava/lang/String;

    return-object p0
.end method
