.class public interface abstract Lecarx/xsf/mediacenter/session/proto/nano/Mediabean;
.super Ljava/lang/Object;
.source ""
