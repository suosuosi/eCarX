.class public Lecarx/xsf/mediacenter/session/PlaybackInfo;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lecarx/xsf/mediacenter/session/PlaybackInfo;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private appName:Ljava/lang/String;

.field private iconUri:Landroid/net/Uri;

.field private initialProgress:J

.field private launchIntent:Landroid/app/PendingIntent;

.field private mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

.field private pkgName:Ljava/lang/String;

.field private playerIntent:Landroid/app/PendingIntent;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lecarx/xsf/mediacenter/session/PlaybackInfo$1;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/session/PlaybackInfo$1;-><init>()V

    sput-object v0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    const-class v0, Landroid/app/PendingIntent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->launchIntent:Landroid/app/PendingIntent;

    const-class v0, Landroid/app/PendingIntent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->playerIntent:Landroid/app/PendingIntent;

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    const-class v0, Lecarx/xsf/mediacenter/session/MediaItem;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Lecarx/xsf/mediacenter/session/MediaItem;

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-void
.end method

.method private constructor <init>(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$000(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$100(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$200(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$300(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->launchIntent:Landroid/app/PendingIntent;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$400(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->playerIntent:Landroid/app/PendingIntent;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$500(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;->access$600(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)Lecarx/xsf/mediacenter/session/MediaItem;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;Lecarx/xsf/mediacenter/session/PlaybackInfo$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/PlaybackInfo;-><init>(Lecarx/xsf/mediacenter/session/PlaybackInfo$Builder;)V

    return-void
.end method

.method static synthetic access$1000(Lecarx/xsf/mediacenter/session/PlaybackInfo;)J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    return-wide v0
.end method

.method static synthetic access$1100(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Lecarx/xsf/mediacenter/session/MediaItem;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-object p0
.end method

.method static synthetic access$700(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$800(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$900(Lecarx/xsf/mediacenter/session/PlaybackInfo;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getAppName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    return-object v0
.end method

.method public getIconUri()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    return-object v0
.end method

.method public getInitialProgress()J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    return-wide v0
.end method

.method public getLaunchIntent()Landroid/app/PendingIntent;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->launchIntent:Landroid/app/PendingIntent;

    return-object v0
.end method

.method public getMediaItem()Lecarx/xsf/mediacenter/session/MediaItem;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-object v0
.end method

.method public getPkgName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    return-object v0
.end method

.method public getPlayerIntent()Landroid/app/PendingIntent;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->playerIntent:Landroid/app/PendingIntent;

    return-object v0
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 2

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    const-class v0, Landroid/app/PendingIntent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->launchIntent:Landroid/app/PendingIntent;

    const-class v0, Landroid/app/PendingIntent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->playerIntent:Landroid/app/PendingIntent;

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    const-class v0, Lecarx/xsf/mediacenter/session/MediaItem;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Lecarx/xsf/mediacenter/session/MediaItem;

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "PlaybackInfo{pkgName=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", iconUri="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", appName=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v1, ", launchIntent="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->launchIntent:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", playerIntent="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->playerIntent:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", initialProgress="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", mediaItem="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->pkgName:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->iconUri:Landroid/net/Uri;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->appName:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->launchIntent:Landroid/app/PendingIntent;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->playerIntent:Landroid/app/PendingIntent;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->initialProgress:J

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackInfo;->mediaItem:Lecarx/xsf/mediacenter/session/MediaItem;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    return-void
.end method
