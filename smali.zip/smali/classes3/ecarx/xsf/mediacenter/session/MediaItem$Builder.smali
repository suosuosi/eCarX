.class public final Lecarx/xsf/mediacenter/session/MediaItem$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/MediaItem;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private album:Ljava/lang/String;

.field private artist:Ljava/lang/String;

.field private artwork:Landroid/net/Uri;

.field private artworkPath:Landroid/net/Uri;

.field private dateTime:J

.field private downloadSupported:Z

.field private downloaded:Z

.field private duration:J

.field private favoriteSupported:Z

.field private favorited:Z

.field private id:Ljava/lang/String;

.field private loopModeSupported:Z

.field private lyricContent:Ljava/lang/String;

.field private lyricUri:Landroid/net/Uri;

.field private radioBand:I

.field private radioFrequency:Ljava/lang/String;

.field private radioName:Ljava/lang/String;

.field private sourceType:I

.field private subtitle:Ljava/lang/String;

.field private title:Ljava/lang/String;

.field private vipNeeded:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->id:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->sourceType:I

    return p0
.end method

.method static synthetic access$1000(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->favoriteSupported:Z

    return p0
.end method

.method static synthetic access$1100(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->downloadSupported:Z

    return p0
.end method

.method static synthetic access$1200(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->vipNeeded:Z

    return p0
.end method

.method static synthetic access$1300(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->downloaded:Z

    return p0
.end method

.method static synthetic access$1400(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->favorited:Z

    return p0
.end method

.method static synthetic access$1500(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->radioFrequency:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$1600(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->radioBand:I

    return p0
.end method

.method static synthetic access$1700(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->radioName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$1800(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->dateTime:J

    return-wide v0
.end method

.method static synthetic access$1900(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->artworkPath:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->title:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$2000(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->loopModeSupported:Z

    return p0
.end method

.method static synthetic access$300(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->subtitle:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$400(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->album:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$500(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->artist:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$600(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->artwork:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$700(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->lyricUri:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$800(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->lyricContent:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$900(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->duration:J

    return-wide v0
.end method


# virtual methods
.method public final album(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->album:Ljava/lang/String;

    return-object p0
.end method

.method public final artist(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->artist:Ljava/lang/String;

    return-object p0
.end method

.method public final artwork(Landroid/net/Uri;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->artwork:Landroid/net/Uri;

    return-object p0
.end method

.method public final artworkPath(Landroid/net/Uri;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->artworkPath:Landroid/net/Uri;

    return-object p0
.end method

.method public final build()Lecarx/xsf/mediacenter/session/MediaItem;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaItem;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/MediaItem;-><init>(Lecarx/xsf/mediacenter/session/MediaItem$Builder;Lecarx/xsf/mediacenter/session/MediaItem$1;)V

    return-object v0
.end method

.method public final dateTime(J)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-wide p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->dateTime:J

    return-object p0
.end method

.method public final downloadSupported(Z)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->downloadSupported:Z

    return-object p0
.end method

.method public final downloaded(Z)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->downloaded:Z

    return-object p0
.end method

.method public final duration(J)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-wide p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->duration:J

    return-object p0
.end method

.method public final favoriteSupported(Z)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->favoriteSupported:Z

    return-object p0
.end method

.method public final favorited(Z)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->favorited:Z

    return-object p0
.end method

.method public final id(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->id:Ljava/lang/String;

    return-object p0
.end method

.method public final loopModeSupported(Z)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->loopModeSupported:Z

    return-object p0
.end method

.method public final lyricContent(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->lyricContent:Ljava/lang/String;

    return-object p0
.end method

.method public final lyricUri(Landroid/net/Uri;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->lyricUri:Landroid/net/Uri;

    return-object p0
.end method

.method public final radioBand(I)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->radioBand:I

    return-object p0
.end method

.method public final radioFrequency(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->radioFrequency:Ljava/lang/String;

    return-object p0
.end method

.method public final radioName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->radioName:Ljava/lang/String;

    return-object p0
.end method

.method public final sourceType(I)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->sourceType:I

    return-object p0
.end method

.method public final subtitle(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->subtitle:Ljava/lang/String;

    return-object p0
.end method

.method public final title(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->title:Ljava/lang/String;

    return-object p0
.end method

.method public final vipNeeded(Z)Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->vipNeeded:Z

    return-object p0
.end method
