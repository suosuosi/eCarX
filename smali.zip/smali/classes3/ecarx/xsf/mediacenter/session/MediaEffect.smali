.class public Lecarx/xsf/mediacenter/session/MediaEffect;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/MediaEffect$Builder;
    }
.end annotation


# instance fields
.field effectId:I

.field effectName:Ljava/lang/String;


# direct methods
.method private constructor <init>(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaEffect$Builder;->access$000(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaEffect;->effectId:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaEffect$Builder;->access$100(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaEffect;->effectName:Ljava/lang/String;

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;Lecarx/xsf/mediacenter/session/MediaEffect$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/MediaEffect;-><init>(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;)V

    return-void
.end method


# virtual methods
.method public getEffectId()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaEffect;->effectId:I

    return v0
.end method

.method public getEffectName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaEffect;->effectName:Ljava/lang/String;

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "MediaEffect{effectId="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lecarx/xsf/mediacenter/session/MediaEffect;->effectId:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", effectName=\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaEffect;->effectName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
