.class public interface abstract Lecarx/xsf/mediacenter/session/EasMediaController$Callback;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/EasMediaController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onAppSourceInfoChange(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/AppSourceInfo;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract onControlMediaSourceTypeChangedNotifity(Ljava/lang/String;Ljava/lang/String;I)V
.end method

.method public abstract onCustomAppSourceInfoChange(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/AppSourceInfo;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract onErrorMsgUpdate(Ljava/lang/String;ILjava/lang/String;)V
.end method

.method public abstract onErrorStateUpdateWithPendingIntent(Ljava/lang/String;IILjava/lang/String;Landroid/app/PendingIntent;)V
.end method

.method public abstract onMediaOperateStateChanged(Lecarx/xsf/mediacenter/session/MediaOperateState;)V
.end method

.method public abstract onMediaQueueChanged(Lecarx/xsf/mediacenter/session/MediaQueue;)V
.end method

.method public abstract onMediaQueueListUpdated(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/MediaQueue;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract onMediaSourceTypeChanged(I)V
.end method

.method public abstract onMediaSourceTypeChanged(Ljava/lang/String;I)V
.end method

.method public abstract onMediaSourceTypeListChanged([I)V
.end method

.method public abstract onPlayLyricSentenceUpdated(Ljava/lang/String;)V
.end method

.method public abstract onPlayProgressUpdated(J)V
.end method

.method public abstract onPlaybackInfoChange(Lecarx/xsf/mediacenter/session/PlaybackInfo;)V
.end method

.method public abstract onPlaybackStateChanged(Lecarx/xsf/mediacenter/session/PlaybackState;)V
.end method

.method public abstract onZonesChanged([I)V
.end method
