.class public interface abstract Lecarx/xsf/mediacenter/session/EasMediaController;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/EasMediaController$Callback;,
        Lecarx/xsf/mediacenter/session/EasMediaController$TransportControls;,
        Lecarx/xsf/mediacenter/session/EasMediaController$ControlType;
    }
.end annotation


# static fields
.field public static final CONTROL_TYPE_FASTFORWARD:I = 0x4

.field public static final CONTROL_TYPE_FASTREWIND:I = 0x5

.field public static final CONTROL_TYPE_NEXT:I = 0xa

.field public static final CONTROL_TYPE_PAUSE:I = 0x0

.field public static final CONTROL_TYPE_PLAY:I = 0x1

.field public static final CONTROL_TYPE_PREVIOUS:I = 0x9

.field public static final CONTROL_TYPE_SEEK:I = 0xc

.field public static final EXTRAS_KEY_SEEK:Ljava/lang/String; = "extra_seek"


# virtual methods
.method public abstract getAppSourceConfig()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/AppSourceInfo;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getAppSourceInfo()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/AppSourceInfo;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getCurrentMediaSourceType()I
.end method

.method public abstract getCustomAppSourceInfo()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/AppSourceInfo;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getMediaQueue()Lecarx/xsf/mediacenter/session/MediaQueue;
.end method

.method public abstract getMediaSourceTypeList()[I
.end method

.method public abstract getPlaybackInfo()Lecarx/xsf/mediacenter/session/PlaybackInfo;
.end method

.method public abstract getPlaybackState()Lecarx/xsf/mediacenter/session/PlaybackState;
.end method

.method public abstract getTransportControls()Lecarx/xsf/mediacenter/session/EasMediaController$TransportControls;
.end method

.method public abstract getZones()[I
.end method

.method public abstract registerCallback(Lecarx/xsf/mediacenter/session/EasMediaController$Callback;)Z
.end method

.method public abstract registerCallbackWithZoneId(ILecarx/xsf/mediacenter/session/EasMediaController$Callback;)Z
.end method

.method public abstract setAppSourceConfig(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/AppSourceInfo;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract unregisterCallback(Lecarx/xsf/mediacenter/session/EasMediaController$Callback;)Z
.end method

.method public abstract updateZoneId(I)V
.end method
