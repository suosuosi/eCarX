.class public interface abstract Lecarx/xsf/mediacenter/session/adapter/TypeAdapterFactory;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract create(Ljava/lang/Class;)Lecarx/xsf/mediacenter/session/adapter/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Lecarx/xsf/mediacenter/session/adapter/a<",
            "TT;>;"
        }
    .end annotation
.end method
