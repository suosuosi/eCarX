.class public Lecarx/xsf/mediacenter/session/MediaQueue;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/MediaQueue$Builder;,
        Lecarx/xsf/mediacenter/session/MediaQueue$QueueType;
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lecarx/xsf/mediacenter/session/MediaQueue;",
            ">;"
        }
    .end annotation
.end field

.field public static final QUEUE_TYPE_CONTENT:I = 0x10

.field public static final QUEUE_TYPE_DOWNLOAD:I = 0x16

.field public static final QUEUE_TYPE_FAVORITE:I = 0x15

.field public static final QUEUE_TYPE_PLAYLIST:I = 0x11

.field public static final QUEUE_TYPE_RECOMMEND:I = 0x12

.field public static final QUEUE_TYPE_SCENARIO:I = 0x13

.field public static final QUEUE_TYPE_UNSPECIFIED:I = -0x1

.field public static final QUEUE_TYPE_VIP:I = 0x14


# instance fields
.field private cover:Landroid/net/Uri;

.field private id:Ljava/lang/String;
    .annotation build Lcom/ecarx/eas/sdk/NonNull;
    .end annotation
.end field

.field private pkgName:Ljava/lang/String;

.field private queue:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/MediaItem;",
            ">;"
        }
    .end annotation
.end field

.field private queueIntent:Landroid/app/PendingIntent;

.field private queueType:I

.field private title:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaQueue$1;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/session/MediaQueue$1;-><init>()V

    sput-object v0, Lecarx/xsf/mediacenter/session/MediaQueue;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    const-class v0, Landroid/app/PendingIntent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueIntent:Landroid/app/PendingIntent;

    sget-object v0, Lecarx/xsf/mediacenter/session/MediaItem;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    return-void
.end method

.method private constructor <init>(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$000(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$100(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$200(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$300(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$400(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueIntent:Landroid/app/PendingIntent;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$500(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQueue$Builder;->access$600(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;Lecarx/xsf/mediacenter/session/MediaQueue$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/MediaQueue;-><init>(Lecarx/xsf/mediacenter/session/MediaQueue$Builder;)V

    return-void
.end method

.method static synthetic access$1000(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$1100(Lecarx/xsf/mediacenter/session/MediaQueue;)Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    return-object p0
.end method

.method static synthetic access$1200(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    return-object p0
.end method

.method static synthetic access$700(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$800(Lecarx/xsf/mediacenter/session/MediaQueue;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    return p0
.end method

.method static synthetic access$900(Lecarx/xsf/mediacenter/session/MediaQueue;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getCover()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    return-object v0
.end method

.method public getId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    return-object v0
.end method

.method public getPkgName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    return-object v0
.end method

.method public getQueue()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lecarx/xsf/mediacenter/session/MediaItem;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    return-object v0
.end method

.method public getQueueIntent()Landroid/app/PendingIntent;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueIntent:Landroid/app/PendingIntent;

    return-object v0
.end method

.method public getQueueType()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    return v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    return-object v0
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 1

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    const-class v0, Landroid/app/PendingIntent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/app/PendingIntent;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueIntent:Landroid/app/PendingIntent;

    sget-object v0, Lecarx/xsf/mediacenter/session/MediaItem;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "MediaQueue{id=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", queueType="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", title=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", pkgName=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v1, ", cover="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", queueIntent="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueIntent:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", queue="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->id:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueType:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->title:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->pkgName:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->cover:Landroid/net/Uri;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queueIntent:Landroid/app/PendingIntent;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object p2, p0, Lecarx/xsf/mediacenter/session/MediaQueue;->queue:Ljava/util/List;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    return-void
.end method
