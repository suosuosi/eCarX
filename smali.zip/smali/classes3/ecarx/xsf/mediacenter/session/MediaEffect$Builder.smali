.class public final Lecarx/xsf/mediacenter/session/MediaEffect$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/MediaEffect;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private effectId:I

.field private effectName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaEffect$Builder;->effectId:I

    return p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaEffect$Builder;->effectName:Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public final build()Lecarx/xsf/mediacenter/session/MediaEffect;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaEffect;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/MediaEffect;-><init>(Lecarx/xsf/mediacenter/session/MediaEffect$Builder;Lecarx/xsf/mediacenter/session/MediaEffect$1;)V

    return-object v0
.end method

.method public final effectId(I)Lecarx/xsf/mediacenter/session/MediaEffect$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaEffect$Builder;->effectId:I

    return-object p0
.end method

.method public final effectName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaEffect$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaEffect$Builder;->effectName:Ljava/lang/String;

    return-object p0
.end method
