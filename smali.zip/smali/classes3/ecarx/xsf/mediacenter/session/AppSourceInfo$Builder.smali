.class public final Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/AppSourceInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private appName:Ljava/lang/String;

.field private iconPath:Ljava/lang/String;

.field private iconRes:Landroid/graphics/Bitmap;

.field private isRunning:Z

.field private packageName:Ljava/lang/String;

.field private priorityLevel:I

.field private sourceTypeList:[I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->packageName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->iconPath:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->appName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$300(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)[I
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->sourceTypeList:[I

    return-object p0
.end method

.method static synthetic access$400(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->priorityLevel:I

    return p0
.end method

.method static synthetic access$500(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->isRunning:Z

    return p0
.end method

.method static synthetic access$600(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Landroid/graphics/Bitmap;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->iconRes:Landroid/graphics/Bitmap;

    return-object p0
.end method


# virtual methods
.method public final appName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->appName:Ljava/lang/String;

    return-object p0
.end method

.method public final build()Lecarx/xsf/mediacenter/session/AppSourceInfo;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/AppSourceInfo;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/AppSourceInfo;-><init>(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;Lecarx/xsf/mediacenter/session/AppSourceInfo$1;)V

    return-object v0
.end method

.method public final iconPath(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->iconPath:Ljava/lang/String;

    return-object p0
.end method

.method public final iconRes(Landroid/graphics/Bitmap;)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->iconRes:Landroid/graphics/Bitmap;

    return-object p0
.end method

.method public final isRunning(Z)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->isRunning:Z

    return-object p0
.end method

.method public final packageName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->packageName:Ljava/lang/String;

    return-object p0
.end method

.method public final priorityLevel(I)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->priorityLevel:I

    return-object p0
.end method

.method public final sourceTypeList([I)Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->sourceTypeList:[I

    return-object p0
.end method
