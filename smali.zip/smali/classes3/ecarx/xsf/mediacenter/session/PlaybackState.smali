.class public Lecarx/xsf/mediacenter/session/PlaybackState;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/PlaybackState$Builder;,
        Lecarx/xsf/mediacenter/session/PlaybackState$RadioMode;,
        Lecarx/xsf/mediacenter/session/PlaybackState$LoopMode;,
        Lecarx/xsf/mediacenter/session/PlaybackState$PlayState;
    }
.end annotation


# static fields
.field public static final LOOP_MODE_ALL:I = 0x0

.field public static final LOOP_MODE_SHUFFLE:I = 0x2

.field public static final LOOP_MODE_SINGLE:I = 0x1

.field public static final RADIO_MODE_CAROUSEL:I = 0x1

.field public static final RADIO_MODE_PLAYING:I = 0x0

.field public static final RADIO_MODE_SCAN:I = 0x4

.field public static final RADIO_MODE_SEEK_NEXT:I = 0x3

.field public static final RADIO_MODE_SEEK_PREV:I = 0x2

.field public static final STATE_BUFFERING:I = 0x3

.field public static final STATE_ERROR:I = 0x7

.field public static final STATE_FAST_FORWARDING:I = 0x4

.field public static final STATE_INTERRUPT:I = 0x2

.field public static final STATE_NONE:I = -0x1

.field public static final STATE_PAUSED:I = 0x0

.field public static final STATE_PLAYING:I = 0x1

.field public static final STATE_REWINDING:I = 0x5

.field public static final STATE_SKIPPING_TO_NEXT:I = 0xa

.field public static final STATE_SKIPPING_TO_PREVIOUS:I = 0x9


# instance fields
.field private errorCode:I

.field private errorMessage:Ljava/lang/String;

.field private itemId:Ljava/lang/String;

.field private loopMode:I

.field private queueId:Ljava/lang/String;

.field private radioMode:I

.field private state:I


# direct methods
.method private constructor <init>(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$000(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->state:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$100(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->loopMode:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$200(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->radioMode:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$300(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->queueId:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$400(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->itemId:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$500(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorCode:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->access$600(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorMessage:Ljava/lang/String;

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;Lecarx/xsf/mediacenter/session/PlaybackState$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/PlaybackState;-><init>(Lecarx/xsf/mediacenter/session/PlaybackState$Builder;)V

    return-void
.end method

.method static synthetic access$1000(Lecarx/xsf/mediacenter/session/PlaybackState;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->queueId:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$1100(Lecarx/xsf/mediacenter/session/PlaybackState;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->itemId:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$1200(Lecarx/xsf/mediacenter/session/PlaybackState;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorCode:I

    return p0
.end method

.method static synthetic access$1300(Lecarx/xsf/mediacenter/session/PlaybackState;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorMessage:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$700(Lecarx/xsf/mediacenter/session/PlaybackState;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->state:I

    return p0
.end method

.method static synthetic access$800(Lecarx/xsf/mediacenter/session/PlaybackState;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->loopMode:I

    return p0
.end method

.method static synthetic access$900(Lecarx/xsf/mediacenter/session/PlaybackState;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->radioMode:I

    return p0
.end method

.method public static empty()Lecarx/xsf/mediacenter/session/PlaybackState;
    .locals 1

    new-instance v0, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;-><init>()V

    invoke-virtual {v0}, Lecarx/xsf/mediacenter/session/PlaybackState$Builder;->build()Lecarx/xsf/mediacenter/session/PlaybackState;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public getErrorCode()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorCode:I

    return v0
.end method

.method public getErrorMessage()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorMessage:Ljava/lang/String;

    return-object v0
.end method

.method public getItemId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->itemId:Ljava/lang/String;

    return-object v0
.end method

.method public getLoopMode()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->loopMode:I

    return v0
.end method

.method public getQueueId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->queueId:Ljava/lang/String;

    return-object v0
.end method

.method public getRadioMode()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->radioMode:I

    return v0
.end method

.method public getState()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->state:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "PlaybackState{state="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->state:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", loopMode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->loopMode:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", radioMode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->radioMode:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", queueId=\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->queueId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", itemId=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->itemId:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", errorCode="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorCode:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", errorMessage=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/PlaybackState;->errorMessage:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
