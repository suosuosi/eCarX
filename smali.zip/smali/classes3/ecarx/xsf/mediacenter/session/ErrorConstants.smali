.class public Lecarx/xsf/mediacenter/session/ErrorConstants;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation


# static fields
.field public static final NOT_LOGGED_IN:I = 0xc9

.field public static final NO_CONTENT:I = 0xce

.field public static final NO_DEVICE_CONNECTED:I = 0xcd

.field public static final NO_MEMBER:I = 0xcc

.field public static final NO_NETWORK:I = 0xcb

.field public static final OTHER:I = 0x3e8

.field public static final UNAUTHORIZED:I = 0xca


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
