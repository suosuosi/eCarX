.class public Lecarx/xsf/mediacenter/session/MediaQuality;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/MediaQuality$Builder;
    }
.end annotation


# instance fields
.field active:Z

.field qualityId:I

.field qualityName:Ljava/lang/String;


# direct methods
.method private constructor <init>(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->access$000(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->qualityId:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->access$100(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->qualityName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->access$200(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)Z

    move-result p1

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->active:Z

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;Lecarx/xsf/mediacenter/session/MediaQuality$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/MediaQuality;-><init>(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)V

    return-void
.end method


# virtual methods
.method public getQualityId()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->qualityId:I

    return v0
.end method

.method public getQualityName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->qualityName:Ljava/lang/String;

    return-object v0
.end method

.method public isActive()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->active:Z

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "MediaQuality{qualityId="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->qualityId:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", qualityName=\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->qualityName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v1, ", active="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lecarx/xsf/mediacenter/session/MediaQuality;->active:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
