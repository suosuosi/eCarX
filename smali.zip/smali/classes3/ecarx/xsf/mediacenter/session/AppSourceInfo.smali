.class public Lecarx/xsf/mediacenter/session/AppSourceInfo;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;
    }
.end annotation


# instance fields
.field private appName:Ljava/lang/String;

.field private iconPath:Ljava/lang/String;

.field private iconRes:Landroid/graphics/Bitmap;

.field private isRunning:Z

.field private packageName:Ljava/lang/String;

.field private priorityLevel:I

.field private sourceTypeList:[I


# direct methods
.method private constructor <init>(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$000(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->packageName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$100(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconPath:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$200(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->appName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$300(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)[I

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->sourceTypeList:[I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$400(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->priorityLevel:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$500(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Z

    move-result v0

    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->isRunning:Z

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;->access$600(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconRes:Landroid/graphics/Bitmap;

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;Lecarx/xsf/mediacenter/session/AppSourceInfo$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/AppSourceInfo;-><init>(Lecarx/xsf/mediacenter/session/AppSourceInfo$Builder;)V

    return-void
.end method


# virtual methods
.method public getAppName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->appName:Ljava/lang/String;

    return-object v0
.end method

.method public getIconPath()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconPath:Ljava/lang/String;

    return-object v0
.end method

.method public getIconRes()Landroid/graphics/Bitmap;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconRes:Landroid/graphics/Bitmap;

    return-object v0
.end method

.method public getPackageName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->packageName:Ljava/lang/String;

    return-object v0
.end method

.method public getPriorityLevel()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->priorityLevel:I

    return v0
.end method

.method public getSourceTypeList()[I
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->sourceTypeList:[I

    return-object v0
.end method

.method public isRunning()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->isRunning:Z

    return v0
.end method

.method public setAppName(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->appName:Ljava/lang/String;

    return-void
.end method

.method public setIconPath(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconPath:Ljava/lang/String;

    return-void
.end method

.method public setIconRes(Landroid/graphics/Bitmap;)V
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconRes:Landroid/graphics/Bitmap;

    return-void
.end method

.method public setPackageName(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->packageName:Ljava/lang/String;

    return-void
.end method

.method public setPriorityLevel(I)V
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->priorityLevel:I

    return-void
.end method

.method public setRunning(Z)V
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->isRunning:Z

    return-void
.end method

.method public setSourceTypeList([I)V
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->sourceTypeList:[I

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AppSourceInfo{packageName=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", iconPath=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconPath:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", iconRes="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->iconRes:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", appName=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->appName:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v1, ", sourceTypeList="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->sourceTypeList:[I

    invoke-static {v1}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", priorityLevel="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->priorityLevel:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", isRunning="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lecarx/xsf/mediacenter/session/AppSourceInfo;->isRunning:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
