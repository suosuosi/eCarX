.class public final Lecarx/xsf/mediacenter/session/MediaQuality$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/MediaQuality;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private active:Z

.field private qualityId:I

.field private qualityName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->qualityId:I

    return p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->qualityName:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;)Z
    .locals 0

    iget-boolean p0, p0, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->active:Z

    return p0
.end method


# virtual methods
.method public final active(Z)Lecarx/xsf/mediacenter/session/MediaQuality$Builder;
    .locals 0

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->active:Z

    return-object p0
.end method

.method public final build()Lecarx/xsf/mediacenter/session/MediaQuality;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaQuality;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/MediaQuality;-><init>(Lecarx/xsf/mediacenter/session/MediaQuality$Builder;Lecarx/xsf/mediacenter/session/MediaQuality$1;)V

    return-object v0
.end method

.method public final qualityId(I)Lecarx/xsf/mediacenter/session/MediaQuality$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->qualityId:I

    return-object p0
.end method

.method public final qualityName(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaQuality$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaQuality$Builder;->qualityName:Ljava/lang/String;

    return-object p0
.end method
