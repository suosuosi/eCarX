.class public Lecarx/xsf/mediacenter/session/MediaItem;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/MediaItem$Builder;
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lecarx/xsf/mediacenter/session/MediaItem;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private album:Ljava/lang/String;

.field private artist:Ljava/lang/String;

.field private artwork:Landroid/net/Uri;

.field private artworkPath:Landroid/net/Uri;

.field private dateTime:J

.field private downloadSupported:Z

.field private downloaded:Z

.field private duration:J

.field private favoriteSupported:Z

.field private favorited:Z

.field private id:Ljava/lang/String;

.field private loopModeSupported:Z

.field private lyricContent:Ljava/lang/String;

.field private lyricUri:Landroid/net/Uri;

.field private radioBand:I

.field private radioFrequency:Ljava/lang/String;

.field private radioName:Ljava/lang/String;

.field private sourceType:I

.field private subtitle:Ljava/lang/String;

.field private title:Ljava/lang/String;

.field private vipNeeded:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaItem$1;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/session/MediaItem$1;-><init>()V

    sput-object v0, Lecarx/xsf/mediacenter/session/MediaItem;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->id:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->sourceType:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->title:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->subtitle:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->album:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artist:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artwork:Landroid/net/Uri;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricUri:Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricContent:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->dateTime:J

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->duration:J

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favoriteSupported:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_1

    move v0, v1

    goto :goto_1

    :cond_1
    move v0, v2

    :goto_1
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloadSupported:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_2

    move v0, v1

    goto :goto_2

    :cond_2
    move v0, v2

    :goto_2
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->vipNeeded:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_3

    move v0, v1

    goto :goto_3

    :cond_3
    move v0, v2

    :goto_3
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloaded:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_4

    move v0, v1

    goto :goto_4

    :cond_4
    move v0, v2

    :goto_4
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favorited:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioFrequency:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioBand:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioName:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artworkPath:Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result p1

    if-eqz p1, :cond_5

    goto :goto_5

    :cond_5
    move v1, v2

    :goto_5
    iput-boolean v1, p0, Lecarx/xsf/mediacenter/session/MediaItem;->loopModeSupported:Z

    return-void
.end method

.method private constructor <init>(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$000(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->id:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$100(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->sourceType:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$200(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->title:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$300(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->subtitle:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$400(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->album:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$500(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artist:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$600(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artwork:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$700(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricUri:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$800(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricContent:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$900(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->duration:J

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1000(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z

    move-result v0

    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favoriteSupported:Z

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1100(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z

    move-result v0

    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloadSupported:Z

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1200(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z

    move-result v0

    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->vipNeeded:Z

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1300(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z

    move-result v0

    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloaded:Z

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1400(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z

    move-result v0

    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favorited:Z

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1500(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioFrequency:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1600(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioBand:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1700(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioName:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1800(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->dateTime:J

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$1900(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artworkPath:Landroid/net/Uri;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaItem$Builder;->access$2000(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)Z

    move-result p1

    iput-boolean p1, p0, Lecarx/xsf/mediacenter/session/MediaItem;->loopModeSupported:Z

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/MediaItem$Builder;Lecarx/xsf/mediacenter/session/MediaItem$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/MediaItem;-><init>(Lecarx/xsf/mediacenter/session/MediaItem$Builder;)V

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getAlbum()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->album:Ljava/lang/String;

    return-object v0
.end method

.method public getArtist()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artist:Ljava/lang/String;

    return-object v0
.end method

.method public getArtwork()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artwork:Landroid/net/Uri;

    return-object v0
.end method

.method public getArtworkPath()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artworkPath:Landroid/net/Uri;

    return-object v0
.end method

.method public getDateTime()J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->dateTime:J

    return-wide v0
.end method

.method public getDuration()J
    .locals 2

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->duration:J

    return-wide v0
.end method

.method public getId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->id:Ljava/lang/String;

    return-object v0
.end method

.method public getLyricContent()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricContent:Ljava/lang/String;

    return-object v0
.end method

.method public getLyricUri()Landroid/net/Uri;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricUri:Landroid/net/Uri;

    return-object v0
.end method

.method public getRadioBand()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioBand:I

    return v0
.end method

.method public getRadioFrequency()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioFrequency:Ljava/lang/String;

    return-object v0
.end method

.method public getRadioName()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioName:Ljava/lang/String;

    return-object v0
.end method

.method public getSourceType()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->sourceType:I

    return v0
.end method

.method public getSubtitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->subtitle:Ljava/lang/String;

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->title:Ljava/lang/String;

    return-object v0
.end method

.method public isDownloadSupported()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloadSupported:Z

    return v0
.end method

.method public isDownloaded()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloaded:Z

    return v0
.end method

.method public isFavoriteSupported()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favoriteSupported:Z

    return v0
.end method

.method public isFavorited()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favorited:Z

    return v0
.end method

.method public isLoopModeSupported()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->loopModeSupported:Z

    return v0
.end method

.method public isVipNeeded()Z
    .locals 1

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->vipNeeded:Z

    return v0
.end method

.method public readFromParcel(Landroid/os/Parcel;)V
    .locals 3

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->id:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->sourceType:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->title:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->subtitle:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->album:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artist:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artwork:Landroid/net/Uri;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricUri:Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricContent:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->dateTime:J

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    iput-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->duration:J

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favoriteSupported:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_1

    move v0, v1

    goto :goto_1

    :cond_1
    move v0, v2

    :goto_1
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloadSupported:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_2

    move v0, v1

    goto :goto_2

    :cond_2
    move v0, v2

    :goto_2
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->vipNeeded:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_3

    move v0, v1

    goto :goto_3

    :cond_3
    move v0, v2

    :goto_3
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloaded:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_4

    move v0, v1

    goto :goto_4

    :cond_4
    move v0, v2

    :goto_4
    iput-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favorited:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioFrequency:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioBand:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioName:Ljava/lang/String;

    const-class v0, Landroid/net/Uri;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/net/Uri;

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artworkPath:Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result p1

    if-eqz p1, :cond_5

    goto :goto_5

    :cond_5
    move v1, v2

    :goto_5
    iput-boolean v1, p0, Lecarx/xsf/mediacenter/session/MediaItem;->loopModeSupported:Z

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "MediaItem{id=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaItem;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", sourceType="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->sourceType:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", title=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->title:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", subtitle=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->subtitle:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", album=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->album:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", artist=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artist:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", artwork="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artwork:Landroid/net/Uri;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", lyricUri="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricUri:Landroid/net/Uri;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", lyricContent=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricContent:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", dateTime="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->dateTime:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, ", duration="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->duration:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, ", favoriteSupported="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favoriteSupported:Z

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", downloadSupported="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloadSupported:Z

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", vipNeeded="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->vipNeeded:Z

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", downloaded="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloaded:Z

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", favorited="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favorited:Z

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", radioFrequency=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioFrequency:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", radioBand="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioBand:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", radioName=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioName:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", artworkPath=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artworkPath:Landroid/net/Uri;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v1, ", loopModeSupported="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lecarx/xsf/mediacenter/session/MediaItem;->loopModeSupported:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->id:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->sourceType:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->title:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->subtitle:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->album:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artist:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artwork:Landroid/net/Uri;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricUri:Landroid/net/Uri;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->lyricContent:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->dateTime:J

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    iget-wide v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->duration:J

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favoriteSupported:Z

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByte(B)V

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloadSupported:Z

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByte(B)V

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->vipNeeded:Z

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByte(B)V

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->downloaded:Z

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByte(B)V

    iget-boolean v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->favorited:Z

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByte(B)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioFrequency:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioBand:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->radioName:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaItem;->artworkPath:Landroid/net/Uri;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    iget-boolean p2, p0, Lecarx/xsf/mediacenter/session/MediaItem;->loopModeSupported:Z

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    return-void
.end method
