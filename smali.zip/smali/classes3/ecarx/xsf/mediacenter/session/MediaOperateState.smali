.class public Lecarx/xsf/mediacenter/session/MediaOperateState;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;,
        Lecarx/xsf/mediacenter/session/MediaOperateState$MediaOperate;,
        Lecarx/xsf/mediacenter/session/MediaOperateState$StateScope;
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lecarx/xsf/mediacenter/session/MediaOperateState;",
            ">;"
        }
    .end annotation
.end field

.field public static final OPERATE_DOWNLOAD:I = 0x1

.field public static final OPERATE_FAVORITE:I = 0x2

.field public static final OPERATE_SET_LYRIC:I = 0x3

.field public static final STATE_CANCEL:I = 0x2

.field public static final STATE_FAILURE:I = -0x1

.field public static final STATE_SUCCESS:I = 0x1


# instance fields
.field private mediaId:Ljava/lang/String;

.field private message:Ljava/lang/String;

.field private operate:I

.field private queueId:Ljava/lang/String;

.field private state:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaOperateState$1;

    invoke-direct {v0}, Lecarx/xsf/mediacenter/session/MediaOperateState$1;-><init>()V

    sput-object v0, Lecarx/xsf/mediacenter/session/MediaOperateState;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->queueId:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->mediaId:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->operate:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->state:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->message:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->access$000(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->queueId:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->access$100(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->mediaId:Ljava/lang/String;

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->access$200(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->operate:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->access$300(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)I

    move-result v0

    iput v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->state:I

    invoke-static {p1}, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->access$400(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->message:Ljava/lang/String;

    return-void
.end method

.method synthetic constructor <init>(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;Lecarx/xsf/mediacenter/session/MediaOperateState$1;)V
    .locals 0

    invoke-direct {p0, p1}, Lecarx/xsf/mediacenter/session/MediaOperateState;-><init>(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)V

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public getMediaId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->mediaId:Ljava/lang/String;

    return-object v0
.end method

.method public getMessage()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->message:Ljava/lang/String;

    return-object v0
.end method

.method public getOperate()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->operate:I

    return v0
.end method

.method public getQueueId()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->queueId:Ljava/lang/String;

    return-object v0
.end method

.method public getState()I
    .locals 1

    iget v0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->state:I

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "MediaOperateState{queueId=\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->queueId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", mediaId=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->mediaId:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v2, ", operate="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->operate:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", state="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->state:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", message=\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->message:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    iget-object p2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->queueId:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object p2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->mediaId:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget p2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->operate:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->state:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, Lecarx/xsf/mediacenter/session/MediaOperateState;->message:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return-void
.end method
