.class public final Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation build Lcom/ecarx/eas/framework/sdk/common/annotation/KeepForSdk;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lecarx/xsf/mediacenter/session/MediaOperateState;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private mediaId:Ljava/lang/String;

.field private message:Ljava/lang/String;

.field private operate:I

.field private queueId:Ljava/lang/String;

.field private state:I


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->queueId:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$100(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->mediaId:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic access$200(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->operate:I

    return p0
.end method

.method static synthetic access$300(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)I
    .locals 0

    iget p0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->state:I

    return p0
.end method

.method static synthetic access$400(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->message:Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public final build()Lecarx/xsf/mediacenter/session/MediaOperateState;
    .locals 2

    new-instance v0, Lecarx/xsf/mediacenter/session/MediaOperateState;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lecarx/xsf/mediacenter/session/MediaOperateState;-><init>(Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;Lecarx/xsf/mediacenter/session/MediaOperateState$1;)V

    return-object v0
.end method

.method public final mediaId(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->mediaId:Ljava/lang/String;

    return-object p0
.end method

.method public final message(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->message:Ljava/lang/String;

    return-object p0
.end method

.method public final operate(I)Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->operate:I

    return-object p0
.end method

.method public final queueId(Ljava/lang/String;)Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;
    .locals 0

    iput-object p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->queueId:Ljava/lang/String;

    return-object p0
.end method

.method public final state(I)Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;
    .locals 0

    iput p1, p0, Lecarx/xsf/mediacenter/session/MediaOperateState$Builder;->state:I

    return-object p0
.end method
