.class public interface abstract Lecarx/xsf/mediacenter/INewsClient;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lecarx/xsf/mediacenter/INewsClient$Stub;
    }
.end annotation


# virtual methods
.method public abstract getNewsPlaybackInfo()Lecarx/xsf/mediacenter/INewsPlaybackInfo;
.end method

.method public abstract onCollect(IZ)Z
.end method

.method public abstract onDownload(IZ)Z
.end method

.method public abstract onExit()Z
.end method

.method public abstract onMediaCenterFocusChanged(Ljava/lang/String;)V
.end method

.method public abstract onNext()Z
.end method

.method public abstract onPause()Z
.end method

.method public abstract onPlay()Z
.end method

.method public abstract onPrevious()Z
.end method

.method public abstract onReplay()Z
.end method
